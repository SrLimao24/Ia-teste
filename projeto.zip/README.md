# Ajudante de Tela (etapa 1)

App Android com um botão flutuante (✦). Ao tocar, lê o texto da tela atual e traduz para português.

- Lê o texto direto da estrutura da tela; se achar pouco, tira um print e usa OCR.
- Detecta o idioma e traduz com ML Kit, no próprio aparelho.
- A internet só é usada para baixar o idioma na primeira vez.
- Precisa do Android 11 ou mais novo.

Próximas etapas: digitar no teclado por você e automatizar toques.


## 0.4 — tradução organizada
- A ação Traduzir tela mostra somente o texto que foi identificado como não português e traduzido.
- O resultado é apresentado no formato `Traduzido:` seguido apenas das traduções.
- A análise é feita por trecho para permitir telas que misturam português e outros idiomas.
