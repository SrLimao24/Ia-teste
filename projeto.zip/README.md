# Ajudante de Tela / Lua

App Android com um botão flutuante (✦). Ao tocar, lê o texto da tela atual e traduz para português, permite textos salvos, navegação e o modo **Ensinar Lua**.

## Funcionalidades atuais

- Traduzir tela (árvore de acessibilidade + OCR + ML Kit offline)
- Textos salvos (substitui o conteúdo do campo focado)
- Navegação rápida (Voltar, Início, Recentes, Notificações, Subir, Descer, Print)
- **Ensinar Lua**: grava sequência de ações do usuário como habilidade reutilizável
- **Executar habilidade**: reproduz localmente os passos gravados (sem IA)

## 0.5.3 — Executor de habilidades

- Na lista de Habilidades, cada item agora tem **▶ Executar**.
- A Lua percorre os passos salvos em sequência (atraso de ~900 ms entre eles).
- Matching local:
  - `tap` / `long_press` → procura nó por texto → descrição → classe + bounds aproximados.
  - `type` → tenta focar um campo editável (texto gravado ainda é vazio por design).
- Toque no botão ✦ durante a execução **interrompe** a habilidade.
- Nenhuma IA é chamada. Tudo roda no aparelho.

## 0.5.2 — correção do modo Ensinar Lua

- Substituídos os `AlertDialog` (que crashavam dentro do AccessibilityService) por overlays nativos.
- Atualizado `accessibility_service_config.xml` para receber cliques e texto.
- `digitar()` agora **substitui** o texto do campo em vez de concatenar.

## 0.5.1 — correção de compilação
- Corrigido o import ausente de `EditText`.

## 0.5 — Ensinar Lua
- Adiciona o modo Ensinar Lua no menu flutuante.
- Registra cliques, toques longos e campos de texto durante uma tarefa.
- Não guarda o conteúdo digitado; campos de senha são ignorados.

## Segurança
- Não digita em campos de senha.
- Tudo roda no aparelho (tradução offline após download do modelo).
- Execução pode ser interrompida a qualquer momento tocando no ✦.
