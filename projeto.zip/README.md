# Ajudante de Tela / Lua

App Android com um botão flutuante (✦). Ao tocar, lê o texto da tela atual e traduz para português, permite textos salvos, navegação e o modo **Ensinar Lua**.

## Funcionalidades atuais

- Traduzir tela (árvore de acessibilidade + OCR + ML Kit offline)
- Textos salvos (substitui o conteúdo do campo focado)
- Navegação rápida (Voltar, Início, Recentes, Notificações, Subir, Descer, Print)
- **Ensinar Lua**: grava sequência de ações do usuário como habilidade reutilizável

## 0.5.2 — correção do modo Ensinar Lua

- Substituídos os `AlertDialog` (que crashavam dentro do AccessibilityService) por overlays nativos com `WindowManager` + `TYPE_ACCESSIBILITY_OVERLAY`.
- Atualizado `accessibility_service_config.xml` para receber `typeViewClicked`, `typeViewLongClicked` e `typeViewTextChanged` (antes a Lua não registrava nenhum passo).
- `digitar()` agora **substitui** o texto do campo em vez de concatenar.

## 0.5.1 — correção de compilação
- Corrigido o import ausente de `EditText`.

## 0.5 — Ensinar Lua
- Adiciona o modo Ensinar Lua no menu flutuante.
- Registra cliques, toques longos e campos de texto durante uma tarefa.
- Não guarda o conteúdo digitado; campos de senha são ignorados.
- Ao terminar, o usuário pode salvar a sequência como uma habilidade.

## Segurança
- Não digita em campos de senha.
- Tudo roda no aparelho (tradução offline após download do modelo).
