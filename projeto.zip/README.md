# Lua — Prime Lua (v0.6.0)

Assistente de tela Android com botão flutuante místico (o Olho da Lua).

## Interface (v0.6)

- Botão flutuante = **Olho da Lua** (anel laranja/cyan, brilho, pulso)
- Ao tocar no olho → menu **radial** estilizado ao redor
- Estados visuais:
  - NORMAL → laranja
  - ENSINANDO → cyan/roxo
  - EXECUTANDO → vermelho
  - ABERTO → menu expandido

## Funções

- Traduzir tela
- Textos salvos
- Ensinar Lua + Habilidades + Executor local
- Voltar / Início / Recentes / Notificações / Subir / Descer / Print

Tudo continua funcionando como antes. A mudança desta versão é principalmente visual.
