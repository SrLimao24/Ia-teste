# Ajudante de Tela (etapa 1)

App Android com um botão flutuante (✦). Ao tocar, lê o texto da tela atual e traduz para português.

- Lê o texto direto da estrutura da tela; se achar pouco, tira um print e usa OCR.
- Detecta o idioma e traduz com ML Kit, no próprio aparelho.
- A internet só é usada para baixar o idioma na primeira vez.
- Precisa do Android 11 ou mais novo.

Próximas etapas: digitar no teclado por você e automatizar toques.


## 0.5 — Ensinar Lua
- Adiciona o modo **Ensinar Lua** no menu flutuante.
- Registra cliques, toques longos e campos de texto durante uma tarefa.
- Não guarda o conteúdo digitado; campos de senha são ignorados.
- Ao terminar, o usuário pode salvar a sequência como uma habilidade.
- Adiciona uma tela simples para consultar as habilidades aprendidas.
- A reprodução automática das habilidades fica para a próxima etapa.
