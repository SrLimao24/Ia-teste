# Lua — Prime Lua (v0.7.0)

Assistente de tela Android com o Olho da Lua e conexão com IA.

## Novidade 0.7.0 — Configuração de IA (Grok/xAI)

- Menu radial → **IA**
- Escolher provedor (Grok por enquanto)
- Colar a chave da API (salva só no aparelho)
- **Testar conexão** contra https://api.x.ai/v1
- Arquitetura pronta para OpenAI / Claude / Gemini / local

A chave NUNCA fica no código nem no GitHub.

## Funções anteriores

- Olho flutuante + menu radial
- Campo de comando + confirmação
- Traduzir, Textos, Ensinar, Habilidades, Executor
- Navegação e Print
