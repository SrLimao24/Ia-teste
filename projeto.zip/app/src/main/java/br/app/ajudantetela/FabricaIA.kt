package br.app.ajudantetela

/** Escolhe a implementação correta para o provedor configurado. */
object FabricaIA {
    fun criar(provedor: String): ModeloIA = when (provedor) {
        ConfigIA.PROVEDOR_GEMINI -> GeminiProvedor()
        ConfigIA.PROVEDOR_GROK -> GrokProvedor()
        ConfigIA.PROVEDOR_OPENAI -> OpenAIProvedor()
        else -> GeminiProvedor()
    }

    fun criarAtual(ctx: android.content.Context): ModeloIA =
        criar(ConfigIA.provedor(ctx))
}
