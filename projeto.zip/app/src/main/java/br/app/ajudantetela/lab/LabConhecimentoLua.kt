package br.app.ajudantetela.lab

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Memoria de conhecimentos APROVADOS para a Lua consultar.
 * Escrita so apos "Aprovar e ensinar". Leitura opcional pela Lua.
 */
object LabConhecimentoLua {

    private const val PREFS = "lua_lab_conhecimento_aprovado_v1"
    private const val K = "itens"

    data class Item(
        val id: String,
        val oQueEnsinar: String,
        val quandoUsar: String,
        val comoExecutar: String,
        val oQueEvitar: String,
        val evidencias: String,
        val falhasConhecidas: String,
        val confianca: Int,
        val data: Long,
        val status: String // aprovado
    )

    private fun p(ctx: Context) =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun aprovar(ctx: Context, item: Item) {
        val lista = listar(ctx).toMutableList().filter { it.id != item.id }.toMutableList()
        lista.add(0, item.copy(status = "aprovado"))
        while (lista.size > 40) lista.removeAt(lista.lastIndex)
        salvar(ctx, lista)
    }

    fun listar(ctx: Context): List<Item> {
        val raw = p(ctx).getString(K, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                Item(
                    id = o.optString("id"),
                    oQueEnsinar = o.optString("ensinar"),
                    quandoUsar = o.optString("quando"),
                    comoExecutar = o.optString("como"),
                    oQueEvitar = o.optString("evitar"),
                    evidencias = o.optString("evid"),
                    falhasConhecidas = o.optString("falhas"),
                    confianca = o.optInt("conf"),
                    data = o.optLong("ts"),
                    status = o.optString("st", "aprovado")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun textoParaPromptLua(ctx: Context): String {
        val itens = listar(ctx)
        if (itens.isEmpty()) return ""
        return buildString {
            appendLine("=== CONHECIMENTO APROVADO PELO LAB (usar como guia, nao coordenada fixa) ===")
            itens.take(5).forEach { it ->
                appendLine("- ${it.oQueEnsinar}")
                appendLine("  Quando: ${it.quandoUsar}")
                appendLine("  Como: ${it.comoExecutar}")
                appendLine("  Evitar: ${it.oQueEvitar}")
            }
            appendLine("=== FIM CONHECIMENTO LAB ===")
        }
    }

    private fun salvar(ctx: Context, lista: List<Item>) {
        val arr = JSONArray()
        lista.forEach { it ->
            arr.put(JSONObject().apply {
                put("id", it.id)
                put("ensinar", it.oQueEnsinar)
                put("quando", it.quandoUsar)
                put("como", it.comoExecutar)
                put("evitar", it.oQueEvitar)
                put("evid", it.evidencias)
                put("falhas", it.falhasConhecidas)
                put("conf", it.confianca)
                put("ts", it.data)
                put("st", it.status)
            })
        }
        p(ctx).edit().putString(K, arr.toString()).apply()
    }
}
