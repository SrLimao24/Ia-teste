package br.app.ajudantetela.lab

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

interface LabPesquisaProvedor {
    val nome: String
    fun pesquisar(ctx: Context, query: String, maxResults: Int = 5): List<ResultadoPesquisaWeb>
}

class StubPesquisaProvedor : LabPesquisaProvedor {
    override val nome = "stub"
    override fun pesquisar(ctx: Context, query: String, maxResults: Int): List<ResultadoPesquisaWeb> {
        val motivo = if (!LabConfig.internetPermitida(ctx)) {
            "Internet do Lab bloqueada. Toque em Permitir pesquisa na Web."
        } else {
            "Sem provedor de pesquisa ativo. Configure Tavily ou use modo Web."
        }
        return listOf(
            ResultadoPesquisaWeb(
                query = query,
                titulo = "[sem pesquisa] " + motivo,
                url = "",
                trecho = motivo,
                fonte = "stub"
            )
        )
    }
}

class TavilyPesquisaProvedor : LabPesquisaProvedor {
    override val nome = "tavily"

    override fun pesquisar(ctx: Context, query: String, maxResults: Int): List<ResultadoPesquisaWeb> {
        if (!LabConfig.internetPermitida(ctx)) return StubPesquisaProvedor().pesquisar(ctx, query, maxResults)
        val key = LabConfig.searchApiKey(ctx)
        if (key.isEmpty()) return StubPesquisaProvedor().pesquisar(ctx, query, maxResults)

        val url = URL("https://api.tavily.com/search")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().apply {
            put("api_key", key)
            put("query", query)
            put("max_results", maxResults.coerceIn(1, 10))
            put("include_answer", false)
        }
        OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
        if (code !in 200..299) {
            return listOf(
                ResultadoPesquisaWeb(query, "Erro pesquisa HTTP $code", "", text.take(300), "tavily_error")
            )
        }
        return try {
            val root = JSONObject(text)
            val results = root.optJSONArray("results") ?: return emptyList()
            (0 until results.length()).map { i ->
                val o = results.getJSONObject(i)
                ResultadoPesquisaWeb(
                    query = query,
                    titulo = o.optString("title"),
                    url = o.optString("url"),
                    trecho = o.optString("content").ifEmpty { o.optString("snippet") }.take(500),
                    fonte = "tavily"
                )
            }
        } catch (e: Exception) {
            listOf(ResultadoPesquisaWeb(query, "Erro ao ler resposta", "", e.message.orEmpty(), "tavily_error"))
        }
    }
}

class WebHttpPesquisaProvedor : LabPesquisaProvedor {
    override val nome = "web"

    override fun pesquisar(ctx: Context, query: String, maxResults: Int): List<ResultadoPesquisaWeb> {
        if (!LabConfig.internetPermitida(ctx)) return StubPesquisaProvedor().pesquisar(ctx, query, maxResults)
        return try {
            val q = URLEncoder.encode(query, "UTF-8")
            val url = URL("https://html.duckduckgo.com/html/?q=$q")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 20000
                readTimeout = 30000
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 LunaraLab/1.0"
                )
            }
            val code = conn.responseCode
            val html = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
            if (code !in 200..299) {
                return listOf(
                    ResultadoPesquisaWeb(query, "Erro Web HTTP $code", "", html.take(200), "web_error")
                )
            }
            parseDuckHtml(query, html, maxResults)
        } catch (e: Exception) {
            listOf(
                ResultadoPesquisaWeb(query, "Falha na pesquisa Web", "", e.message.orEmpty(), "web_error")
            )
        }
    }

    private fun parseDuckHtml(query: String, html: String, max: Int): List<ResultadoPesquisaWeb> {
        val out = mutableListOf<ResultadoPesquisaWeb>()
        val linkRe = Regex(
            """class="result__a"[^>]*href="([^"]+)"[^>]*>([^<]+)</a>""",
            RegexOption.IGNORE_CASE
        )
        val snipRe = Regex(
            """class="result__snippet"[^>]*>([\s\S]*?)</""",
            RegexOption.IGNORE_CASE
        )
        val links = linkRe.findAll(html).toList()
        val snips = snipRe.findAll(html).toList()
        for (i in links.indices) {
            if (out.size >= max) break
            val m = links[i]
            val href = m.groupValues[1]
            var title = m.groupValues[2]
            title = title.replace(Regex("<[^>]+>"), "")
            title = title.replace("&amp;", "&")
            title = title.replace("&quot;", "\"")
            title = title.trim()
            var snip = snips.getOrNull(i)?.groupValues?.getOrNull(1).orEmpty()
            snip = snip.replace(Regex("<[^>]+>"), " ")
            snip = snip.replace(Regex("\\s+"), " ").trim().take(400)
            if (title.isBlank()) continue
            out.add(
                ResultadoPesquisaWeb(
                    query = query,
                    titulo = title,
                    url = href,
                    trecho = snip,
                    fonte = "web"
                )
            )
        }
        if (out.isEmpty()) {
            out.add(
                ResultadoPesquisaWeb(
                    query,
                    "Nenhum resultado parseado",
                    "",
                    "A pagina respondeu, mas o formato pode ter mudado.",
                    "web"
                )
            )
        }
        return out
    }
}

object LabPesquisaFabrica {
    fun criar(ctx: Context): LabPesquisaProvedor {
        if (!LabConfig.internetPermitida(ctx)) return StubPesquisaProvedor()
        return when (LabConfig.searchProvider(ctx).lowercase()) {
            "tavily" -> {
                if (LabConfig.temSearchKey(ctx)) TavilyPesquisaProvedor()
                else WebHttpPesquisaProvedor()
            }
            "stub" -> StubPesquisaProvedor()
            else -> WebHttpPesquisaProvedor()
        }
    }
}
