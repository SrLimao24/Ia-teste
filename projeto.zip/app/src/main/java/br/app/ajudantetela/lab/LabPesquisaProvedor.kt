package br.app.ajudantetela.lab

import android.content.Context
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

/**
 * Camada de pesquisa web trocavel (Tavily hoje; outros depois).
 * Sem chave no codigo — usuario configura no Lab.
 */
interface LabPesquisaProvedor {
    val nome: String
    fun pesquisar(ctx: Context, query: String, maxResults: Int = 5): List<ResultadoPesquisaWeb>
}

class StubPesquisaProvedor : LabPesquisaProvedor {
    override val nome = "stub"
    override fun pesquisar(ctx: Context, query: String, maxResults: Int): List<ResultadoPesquisaWeb> {
        return listOf(
            ResultadoPesquisaWeb(
                query = query,
                titulo = "[stub] Configure a API de pesquisa no Lab",
                url = "",
                trecho = "Sem chave de pesquisa. Resultados reais aparecem apos inserir a chave (ex.: Tavily).",
                fonte = "stub"
            )
        )
    }
}

/**
 * Tavily Search API — https://api.tavily.com/search
 * Body JSON: api_key, query, max_results
 */
class TavilyPesquisaProvedor : LabPesquisaProvedor {
    override val nome = "tavily"

    override fun pesquisar(ctx: Context, query: String, maxResults: Int): List<ResultadoPesquisaWeb> {
        val key = LabConfig.searchApiKey(ctx)
        if (key.isEmpty()) return StubPesquisaProvedor().pesquisar(ctx, query, maxResults)

        val url = URL("https://api.tavily.com/search")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
        }
        val body = JSONObject().apply {
            put("api_key", key)
            put("query", query)
            put("max_results", maxResults.coerceIn(1, 10))
            put("include_answer", false)
        }
        OutputStreamWriter(conn.outputStream).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream?.bufferedReader()?.use(BufferedReader::readText).orEmpty()
        if (code !in 200..299) {
            return listOf(
                ResultadoPesquisaWeb(
                    query, "Erro Tavily HTTP $code", "", text.take(300), "tavily_error"
                )
            )
        }
        return try {
            val root = JSONObject(text)
            val results = root.optJSONArray("results") ?: return emptyList()
            (0 until results.length()).map { i ->
                val o = results.getJSONObject(i)
                ResultadoPesquisaWeb(
                    query = query,
                    titulo = o.optString("title"),
                    url = o.optString("url"),
                    trecho = o.optString("content").ifEmpty { o.optString("snippet") }.take(500),
                    fonte = "tavily"
                )
            }
        } catch (e: Exception) {
            listOf(
                ResultadoPesquisaWeb(query, "Parse error", "", e.message.orEmpty(), "tavily_error")
            )
        }
    }
}

object LabPesquisaFabrica {
    fun criar(ctx: Context): LabPesquisaProvedor {
        return when (LabConfig.searchProvider(ctx).lowercase()) {
            "stub" -> StubPesquisaProvedor()
            else -> {
                if (LabConfig.temSearchKey(ctx)) TavilyPesquisaProvedor()
                else StubPesquisaProvedor()
            }
        }
    }
}
