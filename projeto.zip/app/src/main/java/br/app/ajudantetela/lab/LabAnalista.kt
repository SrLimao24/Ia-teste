package br.app.ajudantetela.lab

import android.content.Context
import br.app.ajudantetela.ConfigIA
import br.app.ajudantetela.FabricaIA
import br.app.ajudantetela.GeminiProvedor

/**
 * IA do Lab = pesquisador (nao e a IA operacional da missao).
 * Uma resposta da IA NUNCA vira conhecimento validado automaticamente.
 */
object LabAnalista {

    data class ResultadoAnalise(
        val ok: Boolean,
        val texto: String,
        val hipoteseRegistrada: Boolean
    )

    fun analisarRelatorioLocal(rel: RelatorioLab): String {
        val t = rel.textoCompleto.lowercase()
        val pontos = mutableListOf<String>()
        pontos += "Objetivo: ${rel.objetivo}"
        pontos += "Resultado missao: ${if (rel.sucesso) "SUCESSO" else "FALHA/INTERROMPIDA"}"
        pontos += "Competencia sugerida: ${rel.competenciaSugerida}"

        if (t.contains("sem efeito") || t.contains("sem mudanca"))
            pontos += "Falha detectada: acoes sem efeito na arvore"
        if (t.contains("loop"))
            pontos += "Falha detectada: possivel loop"
        if (t.contains("enviar") && (t.contains("nao confirm") || t.contains("campo") && t.contains("texto")))
            pontos += "Ponto critico: evidencias de envio insuficientes apos Enviar"
        if (t.contains("viewgroup") || t.contains("relativelayout"))
            pontos += "Estrategia fraca: alvos de layout generico"
        if (t.contains("progresso"))
            pontos += "Ha registros de progresso parcial — mapear onde parou"

        pontos += "Proxima etapa Lab: formular HIPOTESE + rodar experimento no simulador (nao validar ainda)."
        return pontos.joinToString("
")
    }

    /**
     * Consulta opcional a API (mesma chave do app, provedor separado semanticamente).
     * Resultado vira no maximo HIPOTESE, nunca CONHECIMENTO_VALIDADO.
     */
    fun pedirHipoteseIa(
        ctx: Context,
        rel: RelatorioLab,
        callback: (ResultadoAnalise) -> Unit
    ) {
        if (!ConfigIA.temChave(ctx)) {
            callback(
                ResultadoAnalise(
                    false,
                    "Sem chave de API. Use analise local + simulador.",
                    false
                )
            )
            return
        }
        val provedor = FabricaIA.criar(ConfigIA.provedor(ctx))
        if (provedor is GeminiProvedor) {
            val m = ConfigIA.modelo(ctx, ConfigIA.provedor(ctx))
            if (m.isNotEmpty()) provedor.definirModelo(m)
        }
        val prompt = buildString {
            appendLine("Voce e o Lua Lab, pesquisador. NAO e a Lua operacional.")
            appendLine("Sua funcao: entender falhas e propor HIPOTESES testaveis (nao conhecimento final).")
            appendLine("Competencia: ${rel.competenciaSugerida}")
            appendLine("Objetivo da missao: ${rel.objetivo}")
            appendLine("Relatorio:")
            appendLine(rel.textoCompleto.take(3500))
            appendLine()
            appendLine("Responda em texto curto:")
            appendLine("1) Onde faltou evidencia")
            appendLine("2) 2-3 hipoteses testaveis")
            appendLine("3) 1 experimento sugerido no simulador")
            appendLine("Nao declare a competencia como aprendida.")
        }
        val chave = ConfigIA.apiKey(ctx)
        // reutiliza pedirAcao com contexto vazio — interpretacao livre no texto
        provedor.pedirAcao(chave, prompt, "(lab)") { res ->
            if (!res.ok) {
                callback(ResultadoAnalise(false, res.erro, false))
                return@pedirAcao
            }
            val texto = res.texto.ifBlank { res.erro }
            LabRepositorio.adicionarRegistro(
                ctx,
                RegistroLab(
                    id = "hip_${System.currentTimeMillis()}",
                    tipo = TipoRegistroLab.HIPOTESE,
                    competenciaId = "",
                    titulo = "Hipotese IA sobre: ${rel.competenciaSugerida}",
                    corpo = texto,
                    confianca = 25,
                    timestamp = System.currentTimeMillis(),
                    origemRelatorioIds = listOf(rel.id)
                )
            )
            callback(ResultadoAnalise(true, texto, true))
        }
    }

    fun registrarDescobertaAposSim(
        ctx: Context,
        competenciaId: String,
        resumoSim: String,
        sucessoSim: Boolean
    ) {
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = "desc_${System.currentTimeMillis()}",
                tipo = if (sucessoSim) TipoRegistroLab.DESCOBERTA else TipoRegistroLab.EXPERIENCIA,
                competenciaId = competenciaId,
                titulo = if (sucessoSim) "Descoberta em simulador" else "Falha em simulador",
                corpo = resumoSim,
                confianca = if (sucessoSim) 55 else 15,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    /**
     * Validacao explicita pelo usuario/Lab — unica porta para CONHECIMENTO_VALIDADO nesta fase.
     */
    fun validarConhecimento(
        ctx: Context,
        competencia: CompetenciaLab,
        estrategias: List<String>,
        evidencias: List<String>,
        falhas: List<String>
    ): ConhecimentoParaLua {
        val k = ConhecimentoParaLua(
            competencia = competencia.nome,
            estrategias = estrategias,
            condicoes = listOf("Interface compativel com estados observados nos relatorios"),
            evidenciasSucesso = evidencias,
            falhasConhecidas = falhas,
            alternativas = emptyList(),
            confianca = 70,
            geradoEm = System.currentTimeMillis()
        )
        LabRepositorio.salvarConhecimentoParaLua(ctx, k)
        LabRepositorio.atualizarCompetencia(
            ctx,
            competencia.copy(
                status = StatusCompetencia.VALIDADA,
                conhecimentoResumo = estrategias.joinToString(" | "),
                estrategias = estrategias,
                falhasIdentificadas = falhas,
                atualizadoEm = System.currentTimeMillis()
            )
        )
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = "val_${System.currentTimeMillis()}",
                tipo = TipoRegistroLab.CONHECIMENTO_VALIDADO,
                competenciaId = competencia.id,
                titulo = "Conhecimento validado: ${competencia.nome}",
                corpo = k.toString(),
                confianca = 70,
                timestamp = System.currentTimeMillis(),
                origemRelatorioIds = competencia.relatorioIds
            )
        )
        return k
    }
}
