package br.app.ajudantetela.lab

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistencia local do Lab (SharedPreferences + JSON).
 * Nao mistura com memoria operacional da Lua.
 */
object LabRepositorio {

    private const val PREFS = "lua_lab_v1"
    private const val K_REL = "relatorios"
    private const val K_REG = "registros"
    private const val K_COMP = "competencias"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun receberRelatorio(
        ctx: Context,
        objetivo: String,
        sucesso: Boolean,
        textoCompleto: String
    ): RelatorioLab {
        val id = "rel_${System.currentTimeMillis()}"
        val compNome = sugerirCompetencia(objetivo)
        val rel = RelatorioLab(
            id = id,
            timestamp = System.currentTimeMillis(),
            objetivo = objetivo,
            sucesso = sucesso,
            textoCompleto = textoCompleto,
            competenciaSugerida = compNome
        )
        val lista = listarRelatorios(ctx).toMutableList()
        lista.add(0, rel)
        while (lista.size > 80) lista.removeAt(lista.lastIndex)
        salvarRelatorios(ctx, lista)

        // vincula / cria competencia
        val comps = listarCompetencias(ctx).toMutableList()
        val idx = comps.indexOfFirst { it.nome.equals(compNome, true) }
        if (idx >= 0) {
            val c = comps[idx]
            val ids = (c.relatorioIds + id).distinct().take(40)
            comps[idx] = c.copy(
                relatorioIds = ids,
                atualizadoEm = System.currentTimeMillis(),
                status = if (c.status == StatusCompetencia.VALIDADA) c.status
                else StatusCompetencia.EM_PESQUISA
            )
        } else {
            comps.add(
                0,
                CompetenciaLab(
                    id = "comp_${System.currentTimeMillis()}",
                    nome = compNome,
                    descricao = "Derivada de missoes: $objetivo",
                    status = StatusCompetencia.ABERTA,
                    relatorioIds = listOf(id),
                    experimentos = 0,
                    falhasIdentificadas = emptyList(),
                    estrategias = emptyList(),
                    conhecimentoResumo = "",
                    atualizadoEm = System.currentTimeMillis()
                )
            )
        }
        salvarCompetencias(ctx, comps)

        // experiencia automatica a partir do relatorio
        adicionarRegistro(
            ctx,
            RegistroLab(
                id = "exp_$id",
                tipo = TipoRegistroLab.EXPERIENCIA,
                competenciaId = comps.firstOrNull { it.nome.equals(compNome, true) }?.id.orEmpty(),
                titulo = if (sucesso) "Missao com sucesso" else "Missao com falha/interrupcao",
                corpo = textoCompleto.take(4000),
                confianca = if (sucesso) 40 else 20,
                timestamp = System.currentTimeMillis(),
                origemRelatorioIds = listOf(id)
            )
        )
        return rel
    }

    fun sugerirCompetencia(objetivo: String): String {
        val o = objetivo.lowercase()
        return when {
            o.contains("whatsapp") && (o.contains("mensagem") || o.contains("mande") || o.contains("envie")) ->
                "Enviar mensagem no WhatsApp"
            o.contains("whatsapp") -> "Usar WhatsApp"
            o.contains("youtube") && o.contains("pesquis") -> "Pesquisar no YouTube"
            o.contains("mensagem") -> "Enviar mensagem"
            else -> "Competencia: ${objetivo.take(48)}"
        }
    }

    fun listarRelatorios(ctx: Context): List<RelatorioLab> {
        val raw = prefs(ctx).getString(K_REL, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RelatorioLab(
                    id = o.optString("id"),
                    timestamp = o.optLong("ts"),
                    objetivo = o.optString("obj"),
                    sucesso = o.optBoolean("ok"),
                    textoCompleto = o.optString("txt"),
                    competenciaSugerida = o.optString("comp")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun salvarRelatorios(ctx: Context, lista: List<RelatorioLab>) {
        val arr = JSONArray()
        lista.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("ts", r.timestamp)
                put("obj", r.objetivo)
                put("ok", r.sucesso)
                put("txt", r.textoCompleto)
                put("comp", r.competenciaSugerida)
            })
        }
        prefs(ctx).edit().putString(K_REL, arr.toString()).apply()
    }

    fun listarCompetencias(ctx: Context): List<CompetenciaLab> {
        val raw = prefs(ctx).getString(K_COMP, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                CompetenciaLab(
                    id = o.optString("id"),
                    nome = o.optString("nome"),
                    descricao = o.optString("desc"),
                    status = try {
                        StatusCompetencia.valueOf(o.optString("status", "ABERTA"))
                    } catch (_: Exception) {
                        StatusCompetencia.ABERTA
                    },
                    relatorioIds = jsonStrList(o.optJSONArray("rels")),
                    experimentos = o.optInt("exps"),
                    falhasIdentificadas = jsonStrList(o.optJSONArray("falhas")),
                    estrategias = jsonStrList(o.optJSONArray("estrats")),
                    conhecimentoResumo = o.optString("conhec"),
                    atualizadoEm = o.optLong("upd")
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun salvarCompetencias(ctx: Context, lista: List<CompetenciaLab>) {
        val arr = JSONArray()
        lista.forEach { c ->
            arr.put(JSONObject().apply {
                put("id", c.id)
                put("nome", c.nome)
                put("desc", c.descricao)
                put("status", c.status.name)
                put("rels", JSONArray(c.relatorioIds))
                put("exps", c.experimentos)
                put("falhas", JSONArray(c.falhasIdentificadas))
                put("estrats", JSONArray(c.estrategias))
                put("conhec", c.conhecimentoResumo)
                put("upd", c.atualizadoEm)
            })
        }
        prefs(ctx).edit().putString(K_COMP, arr.toString()).apply()
    }

    fun adicionarRegistro(ctx: Context, reg: RegistroLab) {
        val lista = listarRegistros(ctx).toMutableList()
        lista.add(0, reg)
        while (lista.size > 120) lista.removeAt(lista.lastIndex)
        val arr = JSONArray()
        lista.forEach { r ->
            arr.put(JSONObject().apply {
                put("id", r.id)
                put("tipo", r.tipo.name)
                put("comp", r.competenciaId)
                put("tit", r.titulo)
                put("corpo", r.corpo)
                put("conf", r.confianca)
                put("ts", r.timestamp)
                put("orig", JSONArray(r.origemRelatorioIds))
            })
        }
        prefs(ctx).edit().putString(K_REG, arr.toString()).apply()
    }

    fun listarRegistros(ctx: Context): List<RegistroLab> {
        val raw = prefs(ctx).getString(K_REG, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                RegistroLab(
                    id = o.optString("id"),
                    tipo = try {
                        TipoRegistroLab.valueOf(o.optString("tipo"))
                    } catch (_: Exception) {
                        TipoRegistroLab.EXPERIENCIA
                    },
                    competenciaId = o.optString("comp"),
                    titulo = o.optString("tit"),
                    corpo = o.optString("corpo"),
                    confianca = o.optInt("conf"),
                    timestamp = o.optLong("ts"),
                    origemRelatorioIds = jsonStrList(o.optJSONArray("orig"))
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun atualizarCompetencia(ctx: Context, comp: CompetenciaLab) {
        val lista = listarCompetencias(ctx).toMutableList()
        val i = lista.indexOfFirst { it.id == comp.id }
        if (i >= 0) lista[i] = comp else lista.add(comp)
        salvarCompetencias(ctx, lista)
    }

    fun salvarConhecimentoParaLua(ctx: Context, k: ConhecimentoParaLua) {
        prefs(ctx).edit()
            .putString("conhecimento_lua_${k.competencia.hashCode()}", conhecimentoToJson(k))
            .apply()
    }

    fun listarConhecimentosParaLua(ctx: Context): List<ConhecimentoParaLua> {
        val all = prefs(ctx).all
        return all.filterKeys { it.startsWith("conhecimento_lua_") }
            .values
            .mapNotNull { v ->
                try {
                    conhecimentoFromJson(v as String)
                } catch (_: Exception) {
                    null
                }
            }
    }

    private fun conhecimentoToJson(k: ConhecimentoParaLua): String =
        JSONObject().apply {
            put("comp", k.competencia)
            put("estrats", JSONArray(k.estrategias))
            put("conds", JSONArray(k.condicoes))
            put("evid", JSONArray(k.evidenciasSucesso))
            put("falhas", JSONArray(k.falhasConhecidas))
            put("alts", JSONArray(k.alternativas))
            put("conf", k.confianca)
            put("ts", k.geradoEm)
        }.toString()

    private fun conhecimentoFromJson(s: String): ConhecimentoParaLua {
        val o = JSONObject(s)
        return ConhecimentoParaLua(
            competencia = o.optString("comp"),
            estrategias = jsonStrList(o.optJSONArray("estrats")),
            condicoes = jsonStrList(o.optJSONArray("conds")),
            evidenciasSucesso = jsonStrList(o.optJSONArray("evid")),
            falhasConhecidas = jsonStrList(o.optJSONArray("falhas")),
            alternativas = jsonStrList(o.optJSONArray("alts")),
            confianca = o.optInt("conf"),
            geradoEm = o.optLong("ts")
        )
    }

    private fun jsonStrList(arr: JSONArray?): List<String> {
        if (arr == null) return emptyList()
        return (0 until arr.length()).map { arr.getString(it) }
    }
}
