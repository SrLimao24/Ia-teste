package br.app.ajudantetela.lab

import android.content.Context

/**
 * Analise automatica e rastreavel de um relatorio da Lua.
 * Fontes: [RELATORIO] [INFERENCIA] — nunca marca como validado.
 */
object LabAnaliseRelatorio {

    data class Analise(
        val relatorioId: String,
        val objetivo: String,
        val sucesso: Boolean,
        val acoes: List<String>,
        val sucessos: List<String>,
        val falhas: List<String>,
        val teveLoop: Boolean,
        val estrategiasRepetidas: List<String>,
        val ultimoProgresso: String,
        val primeiroPontoFalha: String,
        val problemaFormulado: String,
        val tipoProblema: String,
        val perguntaPesquisa: String,
        val textoCompleto: String
    )

    fun analisar(rel: RelatorioLab): Analise {
        val t = rel.textoCompleto
        val low = t.lowercase()
        val linhas = t.lines().map { it.trim() }.filter { it.isNotEmpty() }

        val acoes = mutableListOf<String>()
        val sucessos = mutableListOf<String>()
        val falhas = mutableListOf<String>()
        val repetidas = mutableListOf<String>()

        for (l in linhas) {
            val ll = l.lowercase()
            when {
                ll.contains("executou") || ll.contains("clicou") || ll.contains("digitou") ||
                    ll.contains("abriu") || ll.contains("acao:") || ll.contains("decidiu") -> {
                    acoes.add(l.take(200))
                    if (ll.contains("falha") || ll.contains("sem efeito") || ll.contains("sem mudanca") ||
                        ll.contains("desconhecida") || ll.contains("interromp")
                    ) falhas.add(l.take(200))
                    else if (ll.contains("ok") || ll.contains("sucesso") || ll.contains("progresso") ||
                        ll.contains("clicou \"") || ll.contains("digitou")
                    ) sucessos.add(l.take(200))
                }
                ll.contains("falha") || ll.contains("sem efeito") || ll.contains("sem mudanca") ||
                    ll.contains("erro") || ll.contains("interromp") -> falhas.add(l.take(200))
                ll.contains("progresso") || ll.contains("abriu") -> sucessos.add(l.take(200))
            }
            if (ll.contains("sem efeito") || ll.contains("tentativa 2") || ll.contains("bloquead")) {
                val m = Regex("""clicar[^\n]{0,40}""", RegexOption.IGNORE_CASE).find(l)
                if (m != null) repetidas.add(m.value)
            }
        }

        val teveLoop = low.contains("loop") || low.contains("oscil") ||
            (repetidas.isNotEmpty() && falhas.size >= 2)

        val ultimoProgresso = sucessos.lastOrNull()
            ?: linhas.lastOrNull { it.contains("progresso", true) || it.contains("abriu", true) }
            ?: "Nao registrado."

        val primeiroPontoFalha = falhas.firstOrNull()
            ?: if (!rel.sucesso) "Missao sem sucesso; falha nao isolada em linha unica."
            else "Nao registrado (missao com sucesso)."

        val tipo = classificarProblema(low, falhas)
        val problema = formularProblema(rel, tipo, primeiroPontoFalha, ultimoProgresso)
        val pergunta = perguntaParaTipo(tipo, rel.objetivo)

        return Analise(
            relatorioId = rel.id,
            objetivo = rel.objetivo,
            sucesso = rel.sucesso,
            acoes = acoes.distinct().take(40),
            sucessos = sucessos.distinct().take(20),
            falhas = falhas.distinct().take(20),
            teveLoop = teveLoop,
            estrategiasRepetidas = repetidas.distinct().take(10),
            ultimoProgresso = ultimoProgresso,
            primeiroPontoFalha = primeiroPontoFalha,
            problemaFormulado = problema,
            tipoProblema = tipo,
            perguntaPesquisa = pergunta,
            textoCompleto = buildString {
                appendLine("[RELATORIO] id=${rel.id} sucesso=${rel.sucesso}")
                appendLine("[INFERENCIA] tipoProblema=$tipo")
                appendLine("[INFERENCIA] problema=$problema")
                appendLine("[INFERENCIA] perguntaPesquisa=$pergunta")
                appendLine("Ultimo progresso: $ultimoProgresso")
                appendLine("Primeiro ponto de falha: $primeiroPontoFalha")
                appendLine("Loop detectado (texto): $teveLoop")
                appendLine("Acoes (${acoes.size}):")
                acoes.take(15).forEach { appendLine("  - $it") }
                appendLine("Falhas (${falhas.size}):")
                falhas.take(10).forEach { appendLine("  - $it") }
            }
        )
    }

    private fun classificarProblema(low: String, falhas: List<String>): String {
        val f = falhas.joinToString(" ").lowercase() + " " + low
        return when {
            f.contains("edittext") && f.contains("clic") -> "clique_em_texto_nao_clicavel"
            f.contains("sem efeito") || f.contains("sem mudanca") -> "clique_sem_efeito"
            f.contains("digitar") || f.contains("edittext") || f.contains("set_text") -> "digitacao"
            f.contains("enviar") && (f.contains("evidenc") || f.contains("confirm")) -> "confirmacao_envio"
            f.contains("nao encontrei") || f.contains("nao encontrado") -> "identificacao_elemento"
            f.contains("desconhecida") || f.contains("cliar") || f.contains("cliker") -> "acao_invalida"
            f.contains("loop") -> "loop"
            f.contains("abrir") && f.contains("falha") -> "abrir_app"
            else -> if (low.contains("falha") || low.contains("interromp")) "falha_generica" else "nenhum"
        }
    }

    private fun formularProblema(
        rel: RelatorioLab,
        tipo: String,
        falha: String,
        progresso: String
    ): String {
        return when (tipo) {
            "clique_em_texto_nao_clicavel" ->
                "A Lua localizou texto do alvo, mas o no associado pode ser EditText/TextView sem ACTION_CLICK. " +
                    "Clique nao abre a conversa. Progresso previo: $progresso. Falha: $falha"
            "clique_sem_efeito" ->
                "Clique executado sem mudanca relevante na arvore. Possivel alvo errado ou UI ainda estabilizando. Falha: $falha"
            "digitacao" ->
                "Problema relacionado a campo de texto / foco / digitar. Falha: $falha"
            "confirmacao_envio" ->
                "Acao de envio pode ter ocorrido sem evidencia observavel suficiente de mensagem enviada."
            "identificacao_elemento" ->
                "Elemento alvo nao encontrado na arvore de acessibilidade com os criterios usados."
            "acao_invalida" ->
                "A IA operacional sugeriu acao nao reconhecida pelo executor."
            "loop" ->
                "Padrao de repeticao/loop detectado no relatorio."
            "abrir_app" ->
                "Falha ao abrir aplicativo ou localizar pacote."
            "nenhum" ->
                if (rel.sucesso) "Missao com sucesso; sem problema primario de falha."
                else "Falha generica no objetivo: ${rel.objetivo}"
            else -> "Problema: $tipo | $falha"
        }
    }

    fun perguntaParaTipo(tipo: String, objetivo: String): String {
        return when (tipo) {
            "clique_em_texto_nao_clicavel", "clique_sem_efeito" ->
                "Android AccessibilityNodeInfo find clickable parent of TextView ACTION_CLICK list item"
            "digitacao" ->
                "Android AccessibilityNodeInfo ACTION_SET_TEXT focus EditText clipboard"
            "confirmacao_envio" ->
                "Android accessibility detect message sent EditText empty conversation bubble"
            "identificacao_elemento" ->
                "Android accessibility tree text contentDescription className bounds find node"
            "abrir_app" ->
                "Android open app packageName Intent AccessibilityService"
            "loop" ->
                "UI automation detect no state change after click avoid retry same target"
            else ->
                "$objetivo Android AccessibilityService how to automate reliably"
        }
    }

    /**
     * Processa relatorio: salva analise, memoria de erro, hipotese inicial.
     * Pode disparar pesquisa se internet permitida (em thread separada).
     */
    fun processarChegada(ctx: Context, rel: RelatorioLab) {
        val analise = analisar(rel)
        val compId = LabRepositorio.listarCompetencias(ctx)
            .firstOrNull { it.nome.equals(rel.competenciaSugerida, true) }?.id.orEmpty()

        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = "anl_" + rel.id,
                tipo = TipoRegistroLab.EXPERIENCIA,
                competenciaId = compId,
                titulo = "Analise automatica do relatorio",
                corpo = analise.textoCompleto,
                confianca = 45,
                timestamp = System.currentTimeMillis(),
                origemRelatorioIds = listOf(rel.id)
            )
        )

        // memoria de estrategias que falharam
        analise.estrategiasRepetidas.forEach { est ->
            LabMemoriaErros.registrar(
                ctx,
                competencia = rel.competenciaSugerida,
                estrategia = est,
                contexto = "missao: ${rel.objetivo.take(60)}",
                resultado = "FALHOU",
                origem = "[RELATORIO] ${rel.id}"
            )
        }
        analise.falhas.take(5).forEach { f ->
            if (f.contains("clicar", true) || f.contains("falha ao clicar", true)) {
                LabMemoriaErros.registrar(
                    ctx,
                    competencia = rel.competenciaSugerida,
                    estrategia = f.take(80),
                    contexto = analise.tipoProblema,
                    resultado = "FALHOU",
                    origem = "[RELATORIO] ${rel.id}"
                )
            }
        }

        // hipotese inicial a partir do problema (nunca validada)
        if (!rel.sucesso && analise.tipoProblema != "nenhum") {
            LabRepositorio.salvarHipotese(
                ctx,
                HipoteseLab(
                    id = "hip_auto_" + rel.id,
                    competenciaId = compId,
                    texto = "[HIPOTESE — ainda nao comprovada] " + analise.problemaFormulado,
                    base = "[RELATORIO]+[INFERENCIA] tipo=" + analise.tipoProblema,
                    status = "aberta",
                    timestamp = System.currentTimeMillis()
                )
            )
        }

        // comparacao com relatorios anteriores da mesma competencia
        val anteriores = LabRepositorio.listarRelatorios(ctx)
            .filter { it.competenciaSugerida.equals(rel.competenciaSugerida, true) && it.id != rel.id }
            .take(5)
        if (anteriores.isNotEmpty()) {
            val cmp = compararComAnteriores(rel, analise, anteriores)
            LabRepositorio.adicionarRegistro(
                ctx,
                RegistroLab(
                    id = "cmp_" + rel.id,
                    tipo = TipoRegistroLab.EXPERIENCIA,
                    competenciaId = compId,
                    titulo = "Comparacao com tentativas anteriores",
                    corpo = cmp,
                    confianca = 40,
                    timestamp = System.currentTimeMillis(),
                    origemRelatorioIds = listOf(rel.id) + anteriores.map { it.id }
                )
            )
        }

        // ensino candidato estruturado (nao validado)
        LabEnsino.gerarCandidato(ctx, rel, analise)

        // pesquisa adaptativa opcional em background se internet OK
        if (LabConfig.internetPermitida(ctx) && !rel.sucesso) {
            Thread {
                try {
                    val bloqueadas = LabMemoriaErros.listar(ctx, rel.competenciaSugerida)
                        .map { it.estrategia.lowercase() }
                    var pergunta = analise.perguntaPesquisa
                    if (bloqueadas.any { pergunta.lowercase().contains(it.take(20)) }) {
                        pergunta = pergunta + " alternative approach not " + bloqueadas.first().take(30)
                    }
                    LabPesquisador.executarUmaPesquisa(
                        ctx,
                        compId,
                        pergunta,
                        "Apos relatorio ${rel.id}: ${analise.tipoProblema}"
                    )
                } catch (_: Exception) {
                }
            }.start()
        }
    }

    private fun compararComAnteriores(
        atual: RelatorioLab,
        analise: Analise,
        anteriores: List<RelatorioLab>
    ): String {
        return buildString {
            appendLine("[RELATORIO] Comparando tentativa atual com ${anteriores.size} anteriores.")
            appendLine("Atual sucesso=${atual.sucesso} tipoProblema=${analise.tipoProblema}")
            anteriores.forEachIndexed { i, a ->
                appendLine("Anterior ${i + 1}: sucesso=${a.sucesso} obj=${a.objetivo.take(50)}")
            }
            if (!atual.sucesso && anteriores.any { !it.sucesso }) {
                appendLine(
                    "[INFERENCIA] Nova falha na mesma competencia — estrategia anterior provavelmente ainda nao resolveu."
                )
            }
            if (atual.sucesso && anteriores.any { !it.sucesso }) {
                appendLine("[INFERENCIA] Melhora: houve sucesso apos falhas anteriores.")
            }
        }
    }
}
