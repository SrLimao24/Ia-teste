package br.app.ajudantetela.autofix

enum class VerificationResult {
    SUCCESS,
    FAILURE,
    UNKNOWN,
    ACTION_FAILED
}

data class VerificationEvidence(
    val source: String,
    val messageCountBefore: Int? = null,
    val messageCountAfter: Int? = null,
    val inputTextBefore: String? = null,
    val inputTextAfter: String? = null,
    val sendButtonPresentBefore: Boolean? = null,
    val sendButtonPresentAfter: Boolean? = null,
    val lastBubbleText: String? = null,
    val appInForeground: Boolean? = null,
    val actionExecuted: Boolean = false
)

data class VerificationDecision(
    val result: VerificationResult,
    val reason: String,
    val evidence: List<VerificationEvidence>
)

/**
 * Detector determinístico. Não recebe objectiveReached pronto de uma IA.
 */
object GoalVerifier {

    fun verifyMessageSend(
        before: VerificationEvidence,
        afterSamples: List<VerificationEvidence>
    ): VerificationDecision {
        if (afterSamples.isEmpty()) {
            return VerificationDecision(
                VerificationResult.UNKNOWN,
                "Nenhuma reobservacao disponivel apos a acao.",
                listOf(before)
            )
        }

        val last = afterSamples.last()

        if (!last.actionExecuted) {
            return VerificationDecision(
                VerificationResult.ACTION_FAILED,
                "A acao de envio nao foi confirmada como executada.",
                listOf(before, last)
            )
        }

        if (last.appInForeground == false) {
            return VerificationDecision(
                VerificationResult.FAILURE,
                "O aplicativo alvo deixou de estar em primeiro plano.",
                listOf(before, last)
            )
        }

        val beforeCount = before.messageCountBefore
        val afterCount = last.messageCountAfter
        if (beforeCount != null && afterCount != null && afterCount > beforeCount) {
            return VerificationDecision(
                VerificationResult.SUCCESS,
                "A contagem de mensagens compatíveis aumentou apos o envio.",
                listOf(before, last)
            )
        }

        val beforeInput = before.inputTextBefore
        val afterInput = last.inputTextAfter
        val sendBefore = before.sendButtonPresentBefore
        val sendAfter = last.sendButtonPresentAfter

        // Campo esvaziado + botao enviar sumiu: forte indicio de envio
        if (beforeInput?.isNotBlank() == true &&
            afterInput?.isBlank() == true &&
            sendBefore == true &&
            sendAfter == false
        ) {
            return VerificationDecision(
                VerificationResult.SUCCESS,
                "Campo de mensagem esvaziado e botao Enviar deixou de estar presente.",
                listOf(before, last)
            )
        }

        // Campo esvaziado sozinho (WhatsApp muitas vezes mantém o botão de mic/enviar)
        if (beforeInput?.isNotBlank() == true && afterInput?.isBlank() == true) {
            return VerificationDecision(
                VerificationResult.SUCCESS,
                "Campo de mensagem esvaziado apos a acao de envio.",
                listOf(before, last)
            )
        }

        // Ultimo balao mudou para o texto enviado (quando disponivel via lastBubbleText)
        val beforeBubble = before.lastBubbleText
        val afterBubble = last.lastBubbleText
        if (!afterBubble.isNullOrBlank() && afterBubble != beforeBubble &&
            (beforeInput.isNullOrBlank() || afterBubble.contains(beforeInput.take(20)))
        ) {
            return VerificationDecision(
                VerificationResult.SUCCESS,
                "Ultimo balao visivel mudou de forma compativel com o texto enviado.",
                listOf(before, last)
            )
        }

        // Arvore igual ou sem evidencia suficiente = UNKNOWN, nunca FAILURE so por isso
        return VerificationDecision(
            VerificationResult.UNKNOWN,
            "Acao executada, mas sem evidencia deterministica suficiente para confirmar ou negar o envio.",
            listOf(before) + afterSamples
        )
    }
}
