package br.app.ajudantetela.lab

import android.content.Context

/**
 * Experimentos baratos no simulador + registro estruturado.
 */
object LabExperimentos {

    fun experimentoEnvioWhatsApp(
        ctx: Context,
        competenciaId: String,
        hipoteseId: String,
        descricao: String
    ): ExperimentoLab {
        var est = LabSimulador.EstadoSim.TELA_INICIAL
        val passos = mutableListOf<LabSimulador.PassoSim>()
        val script = listOf(
            "abrir_app" to "WhatsApp",
            "digitar" to "contato",
            "clicar" to "contato",
            "clicar" to "mensagem",
            "digitar" to "TESTE LAB",
            "clicar" to "Enviar"
        )
        for ((ac, al) in script) {
            val p = LabSimulador.aplicarAcao(est, ac, al)
            passos.add(p)
            if (p.para != null) est = p.para
        }
        val resumo = LabSimulador.avaliarTrajetoria(passos)
        val ok = passos.any { it.para == LabSimulador.EstadoSim.MENSAGEM_ENVIADA }
        val exp = ExperimentoLab(
            id = "exp_" + System.currentTimeMillis(),
            competenciaId = competenciaId,
            hipoteseId = hipoteseId,
            descricao = descricao,
            resultado = resumo,
            sucesso = ok,
            timestamp = System.currentTimeMillis()
        )
        LabRepositorio.salvarExperimento(ctx, exp)
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = exp.id,
                tipo = TipoRegistroLab.EXPERIMENTO,
                competenciaId = competenciaId,
                titulo = if (ok) "Experimento OK" else "Experimento falhou",
                corpo = descricao + "\n" + resumo,
                confianca = if (ok) 50 else 20,
                timestamp = exp.timestamp
            )
        )
        LabAnalista.registrarDescobertaAposSim(ctx, competenciaId, resumo, ok)
        return exp
    }

    fun experimentoCliqueLayoutGenerico(
        ctx: Context,
        competenciaId: String
    ): ExperimentoLab {
        val p = LabSimulador.aplicarAcao(
            LabSimulador.EstadoSim.RESULTADOS, "clicar", "ViewGroup"
        )
        val ok = p.progresso
        val exp = ExperimentoLab(
            id = "exp_" + System.currentTimeMillis(),
            competenciaId = competenciaId,
            hipoteseId = "",
            descricao = "Clicar layout generico na lista de resultados",
            resultado = p.detalhe,
            sucesso = ok,
            timestamp = System.currentTimeMillis()
        )
        LabRepositorio.salvarExperimento(ctx, exp)
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = exp.id,
                tipo = TipoRegistroLab.EXPERIMENTO,
                competenciaId = competenciaId,
                titulo = "Experimento: layout generico",
                corpo = "progresso=" + p.progresso + " " + p.detalhe,
                confianca = 40,
                timestamp = exp.timestamp
            )
        )
        return exp
    }
}
