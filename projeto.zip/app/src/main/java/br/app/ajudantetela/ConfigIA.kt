package br.app.ajudantetela

import android.content.Context

/**
 * Configuração local da IA.
 * Chaves e modelo escolhido ficam SÓ no aparelho.
 */
object ConfigIA {
    private const val PREFS = "lua_ia_config"
    private const val CHAVE_PROVEDOR = "provedor"
    private const val CHAVE_ULTIMO_STATUS = "ultimo_status"
    private const val CHAVE_INTERVALO_MS = "intervalo_pensamento_ms"

    const val PROVEDOR_GEMINI = "gemini"
    const val PROVEDOR_GROK = "grok"
    const val PROVEDOR_OPENAI = "openai"

    val PROVEDORES = listOf(
        PROVEDOR_GEMINI to "Gemini (Google)",
        PROVEDOR_GROK to "Grok (xAI)",
        PROVEDOR_OPENAI to "OpenAI"
    )

    fun provedor(ctx: Context): String =
        prefs(ctx).getString(CHAVE_PROVEDOR, PROVEDOR_GEMINI) ?: PROVEDOR_GEMINI

    fun salvarProvedor(ctx: Context, provedor: String) {
        prefs(ctx).edit().putString(CHAVE_PROVEDOR, provedor).apply()
    }

    fun nomeProvedor(id: String): String =
        PROVEDORES.firstOrNull { it.first == id }?.second ?: id

    fun apiKey(ctx: Context): String = apiKey(ctx, provedor(ctx))

    fun apiKey(ctx: Context, provedor: String): String =
        prefs(ctx).getString(chaveKey(provedor), "") ?: ""

    fun salvarApiKey(ctx: Context, key: String) {
        salvarApiKey(ctx, provedor(ctx), key)
    }

    fun salvarApiKey(ctx: Context, provedor: String, key: String) {
        prefs(ctx).edit().putString(chaveKey(provedor), key.trim()).apply()
    }

    fun temChave(ctx: Context): Boolean = apiKey(ctx).isNotBlank()

    /** Modelo descoberto/selecionado para o provedor (ex.: gemini-3.5-flash). */
    fun modelo(ctx: Context, provedor: String = provedor(ctx)): String =
        prefs(ctx).getString(chaveModelo(provedor), "") ?: ""

    fun salvarModelo(ctx: Context, provedor: String, modelo: String) {
        prefs(ctx).edit().putString(chaveModelo(provedor), modelo).apply()
    }

    fun ultimoStatus(ctx: Context): String =
        prefs(ctx).getString(CHAVE_ULTIMO_STATUS, "Não testado") ?: "Não testado"

    fun salvarStatus(ctx: Context, status: String) {
        prefs(ctx).edit().putString(CHAVE_ULTIMO_STATUS, status).apply()
    }

    /** Intervalo entre ciclos (ms). Padrão 1500. */
    fun intervaloPensamentoMs(ctx: Context): Long {
        val v = prefs(ctx).getLong(CHAVE_INTERVALO_MS, 1500L)
        return v.coerceIn(300L, 15000L)
    }

    fun salvarIntervaloPensamentoMs(ctx: Context, ms: Long) {
        prefs(ctx).edit().putLong(CHAVE_INTERVALO_MS, ms.coerceIn(300L, 15000L)).apply()
    }

    private fun chaveKey(provedor: String) = "api_key_$provedor"
    private fun chaveModelo(provedor: String) = "modelo_$provedor"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
