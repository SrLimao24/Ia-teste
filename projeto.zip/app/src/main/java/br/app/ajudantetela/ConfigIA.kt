package br.app.ajudantetela

import android.content.Context

/**
 * Configuração local da IA.
 * A chave NUNCA vai para o código, GitHub ou APK embutido —
 * só fica no SharedPreferences do aparelho do usuário.
 */
object ConfigIA {
    private const val PREFS = "lua_ia_config"
    private const val CHAVE_PROVEDOR = "provedor"
    private const val CHAVE_API_KEY = "api_key"
    private const val CHAVE_ULTIMO_STATUS = "ultimo_status"

    const val PROVEDOR_GROK = "grok"
    // Futuros: openai, claude, gemini, local

    fun provedor(ctx: Context): String =
        prefs(ctx).getString(CHAVE_PROVEDOR, PROVEDOR_GROK) ?: PROVEDOR_GROK

    fun salvarProvedor(ctx: Context, provedor: String) {
        prefs(ctx).edit().putString(CHAVE_PROVEDOR, provedor).apply()
    }

    fun apiKey(ctx: Context): String =
        prefs(ctx).getString(CHAVE_API_KEY, "") ?: ""

    fun salvarApiKey(ctx: Context, key: String) {
        prefs(ctx).edit().putString(CHAVE_API_KEY, key.trim()).apply()
    }

    fun temChave(ctx: Context): Boolean = apiKey(ctx).isNotBlank()

    fun ultimoStatus(ctx: Context): String =
        prefs(ctx).getString(CHAVE_ULTIMO_STATUS, "Não testado") ?: "Não testado"

    fun salvarStatus(ctx: Context, status: String) {
        prefs(ctx).edit().putString(CHAVE_ULTIMO_STATUS, status).apply()
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
