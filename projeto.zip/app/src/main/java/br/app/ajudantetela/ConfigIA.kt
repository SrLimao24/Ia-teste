package br.app.ajudantetela

import android.content.Context

/**
 * Configuração local da IA.
 * Chaves ficam SÓ no aparelho (SharedPreferences).
 * Cada provedor tem sua própria chave — não se misturam.
 */
object ConfigIA {
    private const val PREFS = "lua_ia_config"
    private const val CHAVE_PROVEDOR = "provedor"
    private const val CHAVE_ULTIMO_STATUS = "ultimo_status"

    const val PROVEDOR_GEMINI = "gemini"
    const val PROVEDOR_GROK = "grok"
    const val PROVEDOR_OPENAI = "openai"

    val PROVEDORES = listOf(
        PROVEDOR_GEMINI to "Gemini (Google)",
        PROVEDOR_GROK to "Grok (xAI)",
        PROVEDOR_OPENAI to "OpenAI"
    )

    fun provedor(ctx: Context): String =
        prefs(ctx).getString(CHAVE_PROVEDOR, PROVEDOR_GEMINI) ?: PROVEDOR_GEMINI

    fun salvarProvedor(ctx: Context, provedor: String) {
        prefs(ctx).edit().putString(CHAVE_PROVEDOR, provedor).apply()
    }

    fun nomeProvedor(id: String): String =
        PROVEDORES.firstOrNull { it.first == id }?.second ?: id

    /** Chave do provedor atualmente selecionado. */
    fun apiKey(ctx: Context): String = apiKey(ctx, provedor(ctx))

    /** Chave de um provedor específico. */
    fun apiKey(ctx: Context, provedor: String): String =
        prefs(ctx).getString(chaveKey(provedor), "") ?: ""

    fun salvarApiKey(ctx: Context, key: String) {
        salvarApiKey(ctx, provedor(ctx), key)
    }

    fun salvarApiKey(ctx: Context, provedor: String, key: String) {
        prefs(ctx).edit().putString(chaveKey(provedor), key.trim()).apply()
    }

    fun temChave(ctx: Context): Boolean = apiKey(ctx).isNotBlank()

    fun temChave(ctx: Context, provedor: String): Boolean =
        apiKey(ctx, provedor).isNotBlank()

    fun ultimoStatus(ctx: Context): String =
        prefs(ctx).getString(CHAVE_ULTIMO_STATUS, "Não testado") ?: "Não testado"

    fun salvarStatus(ctx: Context, status: String) {
        prefs(ctx).edit().putString(CHAVE_ULTIMO_STATUS, status).apply()
    }

    private fun chaveKey(provedor: String) = "api_key_$provedor"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
