package br.app.ajudantetela.lab

/**
 * Modelos do Lua Lab — isolados da IA operacional.
 * EXPERIENCIA → HIPOTESE → DESCOBERTA → CONHECIMENTO_VALIDADO
 */

enum class TipoRegistroLab {
    EXPERIENCIA,
    HIPOTESE,
    DESCOBERTA,
    CONHECIMENTO_VALIDADO
}

enum class StatusCompetencia {
    ABERTA,
    EM_PESQUISA,
    EM_EXPERIMENTO,
    VALIDADA,
    DESCARTADA
}

data class RelatorioLab(
    val id: String,
    val timestamp: Long,
    val objetivo: String,
    val sucesso: Boolean,
    val textoCompleto: String,
    val competenciaSugerida: String
)

data class RegistroLab(
    val id: String,
    val tipo: TipoRegistroLab,
    val competenciaId: String,
    val titulo: String,
    val corpo: String,
    val confianca: Int,
    val timestamp: Long,
    val origemRelatorioIds: List<String> = emptyList()
)

data class CompetenciaLab(
    val id: String,
    val nome: String,
    val descricao: String,
    val status: StatusCompetencia,
    val relatorioIds: List<String>,
    val experimentos: Int,
    val falhasIdentificadas: List<String>,
    val estrategias: List<String>,
    val conhecimentoResumo: String,
    val atualizadoEm: Long
)

/** Representacao estruturada para entrega futura a Lua operacional. */
data class ConhecimentoParaLua(
    val competencia: String,
    val estrategias: List<String>,
    val condicoes: List<String>,
    val evidenciasSucesso: List<String>,
    val falhasConhecidas: List<String>,
    val alternativas: List<String>,
    val confianca: Int,
    val geradoEm: Long
)
