package br.app.ajudantetela.lab

enum class TipoRegistroLab {
    EXPERIENCIA,
    HIPOTESE,
    DESCOBERTA,
    CONHECIMENTO_VALIDADO,
    PESQUISA,
    EXPERIMENTO,
    SESSAO
}

enum class StatusCompetencia {
    ABERTA,
    EM_PESQUISA,
    EM_EXPERIMENTO,
    VALIDADA,
    DESCARTADA
}

enum class StatusSessaoLab {
    CRIADA,
    PESQUISANDO,
    ANALISANDO,
    EXPERIMENTANDO,
    VALIDANDO,
    CONCLUIDA,
    PAUSADA,
    FALHA
}

data class RelatorioLab(
    val id: String,
    val timestamp: Long,
    val objetivo: String,
    val sucesso: Boolean,
    val textoCompleto: String,
    val competenciaSugerida: String
)

data class RegistroLab(
    val id: String,
    val tipo: TipoRegistroLab,
    val competenciaId: String,
    val titulo: String,
    val corpo: String,
    val confianca: Int,
    val timestamp: Long,
    val origemRelatorioIds: List<String> = emptyList()
)

data class CompetenciaLab(
    val id: String,
    val nome: String,
    val descricao: String,
    val status: StatusCompetencia,
    val relatorioIds: List<String>,
    val experimentos: Int,
    val falhasIdentificadas: List<String>,
    val estrategias: List<String>,
    val conhecimentoResumo: String,
    val atualizadoEm: Long
)

data class ConhecimentoParaLua(
    val competencia: String,
    val estrategias: List<String>,
    val condicoes: List<String>,
    val evidenciasSucesso: List<String>,
    val falhasConhecidas: List<String>,
    val alternativas: List<String>,
    val confianca: Int,
    val geradoEm: Long
)

data class ResultadoPesquisaWeb(
    val query: String,
    val titulo: String,
    val url: String,
    val trecho: String,
    val fonte: String
)

data class HipoteseLab(
    val id: String,
    val competenciaId: String,
    val texto: String,
    val base: String,
    val status: String,
    val timestamp: Long
)

data class ExperimentoLab(
    val id: String,
    val competenciaId: String,
    val hipoteseId: String,
    val descricao: String,
    val resultado: String,
    val sucesso: Boolean,
    val timestamp: Long
)

data class SessaoLab(
    val id: String,
    val objetivo: String,
    val competenciaNome: String,
    val status: StatusSessaoLab,
    val iniciadaEm: Long,
    val atualizadaEm: Long,
    val pesquisas: Int,
    val hipoteses: Int,
    val experimentos: Int,
    val log: List<String>,
    val fontes: List<String>,
    val conhecimentoId: String = ""
)
