package br.app.ajudantetela.lab

import android.content.Context

/**
 * Config isolada do Lab. Chaves e permissao NUNCA no codigo-fonte.
 */
object LabConfig {
    private const val PREFS = "lua_lab_config_v1"
    private const val K_SEARCH_KEY = "search_api_key"
    private const val K_SEARCH_PROVIDER = "search_provider"
    private const val K_LAB_IA = "lab_ia_enabled"
    private const val K_NET = "lab_internet_allowed"
    private const val K_MAX_PESQ = "max_pesquisas_sessao"
    private const val K_MAX_CICLOS = "max_ciclos_sessao"
    private const val K_MAX_MIN = "max_minutos_sessao"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun searchApiKey(ctx: Context): String =
        p(ctx).getString(K_SEARCH_KEY, "")?.trim().orEmpty()

    fun setSearchApiKey(ctx: Context, key: String) {
        p(ctx).edit().putString(K_SEARCH_KEY, key.trim()).apply()
    }

    fun temSearchKey(ctx: Context): Boolean = searchApiKey(ctx).isNotEmpty()

    /** tavily | webview | stub */
    fun searchProvider(ctx: Context): String =
        p(ctx).getString(K_SEARCH_PROVIDER, "webview") ?: "webview"

    fun setSearchProvider(ctx: Context, name: String) {
        p(ctx).edit().putString(K_SEARCH_PROVIDER, name).apply()
    }

    fun labIaEnabled(ctx: Context): Boolean = p(ctx).getBoolean(K_LAB_IA, true)

    fun setLabIaEnabled(ctx: Context, v: Boolean) {
        p(ctx).edit().putBoolean(K_LAB_IA, v).apply()
    }

    /** Porta da internet do Lab — padrao BLOQUEADA */
    fun internetPermitida(ctx: Context): Boolean = p(ctx).getBoolean(K_NET, false)

    fun setInternetPermitida(ctx: Context, v: Boolean) {
        p(ctx).edit().putBoolean(K_NET, v).apply()
    }

    fun maxPesquisasSessao(ctx: Context): Int =
        p(ctx).getInt(K_MAX_PESQ, 8).coerceIn(1, 30)

    fun maxCiclosSessao(ctx: Context): Int =
        p(ctx).getInt(K_MAX_CICLOS, 6).coerceIn(1, 20)

    fun maxMinutosSessao(ctx: Context): Int =
        p(ctx).getInt(K_MAX_MIN, 15).coerceIn(1, 120)
}
