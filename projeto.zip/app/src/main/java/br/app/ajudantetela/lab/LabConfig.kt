package br.app.ajudantetela.lab

import android.content.Context

/**
 * Configuracao isolada do Lab (nao mistura com ConfigIA da missao).
 * Chave de pesquisa: inserida pelo usuario; NUNCA embutida no codigo.
 */
object LabConfig {
    private const val PREFS = "lua_lab_config_v1"
    private const val K_SEARCH_KEY = "search_api_key"
    private const val K_SEARCH_PROVIDER = "search_provider"
    private const val K_LAB_IA_ENABLED = "lab_ia_enabled"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun searchApiKey(ctx: Context): String =
        p(ctx).getString(K_SEARCH_KEY, "")?.trim().orEmpty()

    fun setSearchApiKey(ctx: Context, key: String) {
        p(ctx).edit().putString(K_SEARCH_KEY, key.trim()).apply()
    }

    fun temSearchKey(ctx: Context): Boolean = searchApiKey(ctx).isNotEmpty()

    /** tavily | stub */
    fun searchProvider(ctx: Context): String =
        p(ctx).getString(K_SEARCH_PROVIDER, "tavily") ?: "tavily"

    fun setSearchProvider(ctx: Context, name: String) {
        p(ctx).edit().putString(K_SEARCH_PROVIDER, name).apply()
    }

    fun labIaEnabled(ctx: Context): Boolean =
        p(ctx).getBoolean(K_LAB_IA_ENABLED, true)

    fun setLabIaEnabled(ctx: Context, v: Boolean) {
        p(ctx).edit().putBoolean(K_LAB_IA_ENABLED, v).apply()
    }
}
