package br.app.ajudantetela.autofix

import android.view.accessibility.AccessibilityNodeInfo
import br.app.ajudantetela.InterpreteAcao

data class MessageSnapshot(
    val packageName: String?,
    val inputText: String?,
    val sendButtonPresent: Boolean,
    val compatibleBubbleCount: Int?,
    val lastBubbleText: String?
)

fun MessageSnapshot.toEvidence(
    source: String,
    before: MessageSnapshot? = null,
    actionExecuted: Boolean = false
): VerificationEvidence {
    return VerificationEvidence(
        source = source,
        messageCountBefore = before?.compatibleBubbleCount,
        messageCountAfter = compatibleBubbleCount,
        inputTextBefore = before?.inputText,
        inputTextAfter = inputText,
        sendButtonPresentBefore = before?.sendButtonPresent,
        sendButtonPresentAfter = sendButtonPresent,
        lastBubbleText = lastBubbleText,
        appInForeground = packageName != null,
        actionExecuted = actionExecuted
    )
}

/**
 * Monta snapshot a partir da arvore real de acessibilidade.
 * Contagem de "baloes" e heuristica (TextViews com texto, nao editaveis).
 */
object MessageSnapshotBuilder {

    fun fromRoot(raiz: AccessibilityNodeInfo?, textoEnviado: String = ""): MessageSnapshot {
        if (raiz == null) {
            return MessageSnapshot(null, null, false, null, null)
        }
        val pkg = raiz.packageName?.toString()
        val campos = InterpreteAcao.listarCamposEditaveis(raiz)
        // Preferir o campo com texto (mensagem pendente) ou o ultimo editavel
        val input = campos.firstOrNull { it.texto.isNotBlank() }?.texto
            ?: campos.lastOrNull()?.texto
            ?: ""
        val elems = InterpreteAcao.listarElementosInterativos(raiz, 60)
        val sendPresent = elems.any { InterpreteAcao.pareceBotaoEnviar(it) }
        val bubbleTexts = coletarTextosNaoEditaveis(raiz, 80)
        val compatible = if (textoEnviado.isNotBlank()) {
            bubbleTexts.count { it.contains(textoEnviado.take(24), ignoreCase = true) }
        } else {
            bubbleTexts.size
        }
        val lastBubble = bubbleTexts.lastOrNull()
        return MessageSnapshot(
            packageName = pkg,
            inputText = input,
            sendButtonPresent = sendPresent,
            compatibleBubbleCount = compatible,
            lastBubbleText = lastBubble
        )
    }

    private fun coletarTextosNaoEditaveis(raiz: AccessibilityNodeInfo, max: Int): List<String> {
        val out = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= max) return
            try {
                val editable = n.isEditable
                val text = n.text?.toString()?.trim().orEmpty()
                val cls = n.className?.toString().orEmpty()
                if (!editable && text.length in 1..400 &&
                    (cls.contains("TextView") || cls.contains("Text") || text.isNotEmpty())
                ) {
                    // filtrar hints/ui genericas
                    val low = text.lowercase()
                    if (!low.contains("digite") && !low.contains("mensagem") &&
                        !low.contains("pesquis") && !low.startsWith("http")
                    ) {
                        out.add(text)
                    }
                }
                for (i in 0 until n.childCount) {
                    walk(n.getChild(i))
                }
            } catch (_: Exception) {
            }
        }
        walk(raiz)
        return out
    }
}
