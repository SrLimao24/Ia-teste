package br.app.ajudantetela.lab

import android.content.Context

/**
 * Plano de ensino candidato — NUNCA aplica na Lua operacional automaticamente.
 */
object LabEnsino {

    fun gerarCandidato(ctx: Context, rel: RelatorioLab, analise: LabAnaliseRelatorio.Analise) {
        val falhasMem = LabMemoriaErros.listar(ctx, rel.competenciaSugerida)
        val texto = buildString {
            appendLine("ENSINAMENTO PREPARADO PARA LUA (CANDIDATO — NAO APLICADO)")
            appendLine("Competencia: ${rel.competenciaSugerida}")
            appendLine("Problema encontrado: ${analise.problemaFormulado}")
            appendLine("Tipo: ${analise.tipoProblema}")
            appendLine()
            appendLine("Estrategias antigas que falharam:")
            if (falhasMem.isEmpty()) appendLine("- Nao registrado.")
            else falhasMem.take(8).forEach {
                appendLine("- ${it.estrategia} | ${it.resultado} | ${it.origem}")
            }
            appendLine()
            appendLine("Nova estrategia sugerida (HIPOTESE — ainda nao comprovada):")
            when (analise.tipoProblema) {
                "clique_em_texto_nao_clicavel", "clique_sem_efeito" ->
                    appendLine(
                        "Localizar no com o texto do contato; subir ancestrais ate no com ACTION_CLICK/isClickable; " +
                            "evitar clicar so no TextView/EditText; verificar mudanca de tela apos o clique."
                    )
                "confirmacao_envio" ->
                    appendLine(
                        "Apos Enviar, exigir evidencia: campo vazio ou bolha enviada; nao concluir so por mudanca qualquer."
                    )
                "digitacao" ->
                    appendLine("Focar EditText editavel; ACTION_SET_TEXT ou fallback; confirmar texto no no.")
                else ->
                    appendLine("Reavaliar arvore de acessibilidade no ponto de falha e evitar estrategias ja falhas.")
            }
            appendLine()
            appendLine("Como saber que funcionou: mudanca de estado alinhada ao objetivo (ex.: conversa aberta).")
            appendLine("Como saber que falhou: mesma assinatura de tela / sem progresso apos acao.")
            appendLine("Nivel de confianca: baixo (candidato)")
            appendLine("Teste necessario: nova missao real da Lua no mesmo objetivo.")
            appendLine("Aplicado a Lua: NAO")
            appendLine("Status: CANDIDATO")
        }
        val compId = LabRepositorio.listarCompetencias(ctx)
            .firstOrNull { it.nome.equals(rel.competenciaSugerida, true) }?.id.orEmpty()
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = "ens_" + rel.id,
                tipo = TipoRegistroLab.DESCOBERTA,
                competenciaId = compId,
                titulo = "Plano de ensino candidato",
                corpo = texto,
                confianca = 25,
                timestamp = System.currentTimeMillis(),
                origemRelatorioIds = listOf(rel.id)
            )
        )
    }
}
