package br.app.ajudantetela

import android.content.Context
import org.json.JSONArray

/** Textos salvos pelo usuário, guardados só no aparelho. */
object Textos {
    private const val PREFS = "textos"
    private const val CHAVE = "lista"

    fun ler(ctx: Context): MutableList<String> {
        val bruto = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(CHAVE, "[]") ?: "[]"
        val lista = mutableListOf<String>()
        try {
            val arr = JSONArray(bruto)
            for (i in 0 until arr.length()) lista.add(arr.getString(i))
        } catch (_: Exception) {
        }
        return lista
    }

    fun salvar(ctx: Context, lista: List<String>) {
        val arr = JSONArray()
        lista.forEach { arr.put(it) }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(CHAVE, arr.toString()).apply()
    }
}
