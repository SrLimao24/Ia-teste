package br.app.ajudantetela

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Memória local das tarefas que o usuário ensinou à Lua. */
object Habilidades {
    private const val PREFS = "habilidades"
    private const val CHAVE = "lista"

    data class Passo(
        val acao: String,
        val app: String,
        val texto: String,
        val descricao: String,
        val classe: String,
        val esquerda: Int,
        val topo: Int,
        val direita: Int,
        val baixo: Int
    )

    data class Habilidade(
        val nome: String,
        val passos: List<Passo>
    )

    fun ler(ctx: Context): MutableList<Habilidade> {
        val bruto = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(CHAVE, "[]") ?: "[]"
        val lista = mutableListOf<Habilidade>()
        try {
            val arr = JSONArray(bruto)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val passosJson = obj.optJSONArray("passos") ?: JSONArray()
                val passos = mutableListOf<Passo>()
                for (j in 0 until passosJson.length()) {
                    val p = passosJson.getJSONObject(j)
                    passos.add(
                        Passo(
                            p.optString("acao"), p.optString("app"),
                            p.optString("texto"), p.optString("descricao"),
                            p.optString("classe"), p.optInt("esquerda"),
                            p.optInt("topo"), p.optInt("direita"), p.optInt("baixo")
                        )
                    )
                }
                lista.add(Habilidade(obj.optString("nome"), passos))
            }
        } catch (_: Exception) { }
        return lista
    }

    fun adicionar(ctx: Context, habilidade: Habilidade) {
        val lista = ler(ctx)
        lista.removeAll { it.nome.equals(habilidade.nome, ignoreCase = true) }
        lista.add(habilidade)
        salvar(ctx, lista)
    }

    fun salvar(ctx: Context, lista: List<Habilidade>) {
        val arr = JSONArray()
        lista.forEach { h ->
            val obj = JSONObject().put("nome", h.nome)
            val passos = JSONArray()
            h.passos.forEach { p ->
                passos.put(
                    JSONObject()
                        .put("acao", p.acao)
                        .put("app", p.app)
                        .put("texto", p.texto)
                        .put("descricao", p.descricao)
                        .put("classe", p.classe)
                        .put("esquerda", p.esquerda)
                        .put("topo", p.topo)
                        .put("direita", p.direita)
                        .put("baixo", p.baixo)
                )
            }
            obj.put("passos", passos)
            arr.put(obj)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(CHAVE, arr.toString()).apply()
    }
}
