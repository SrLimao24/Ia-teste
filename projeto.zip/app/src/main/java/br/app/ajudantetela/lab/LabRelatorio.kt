package br.app.ajudantetela.lab

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Gera o relatorio do Lab (trabalho do laboratorio), nao o da missao da Lua.
 */
object LabRelatorio {

    private fun fmt(ts: Long): String {
        if (ts <= 0L) return "Nao registrado."
        return try {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ts))
        } catch (_: Exception) {
            ts.toString()
        }
    }

    fun gerar(ctx: Context, sessaoId: String? = null): String {
        val sessoes = LabRepositorio.listarSessoes(ctx)
        val sessao = when {
            sessaoId != null -> sessoes.firstOrNull { it.id == sessaoId }
            else -> sessoes.firstOrNull()
        }
        val comps = LabRepositorio.listarCompetencias(ctx)
        val rels = LabRepositorio.listarRelatorios(ctx)
        val hip = LabRepositorio.listarHipoteses(ctx)
        val exps = LabRepositorio.listarExperimentos(ctx)
        val regs = LabRepositorio.listarRegistros(ctx)
        val conhec = LabRepositorio.listarConhecimentosParaLua(ctx)
        val pesquisas = regs.filter { it.tipo == TipoRegistroLab.PESQUISA }

        val sb = StringBuilder()
        sb.appendLine("========================================")
        sb.appendLine("RELATORIO DO LUA LAB")
        sb.appendLine("========================================")
        sb.appendLine()

        sb.appendLine("SESSAO")
        if (sessao == null) {
            sb.appendLine("- Objetivo: Nao registrado.")
            sb.appendLine("- Competencia investigada: Nao registrado.")
            sb.appendLine("- Data/hora de inicio: Nao registrado.")
            sb.appendLine("- Data/hora de termino: Nao registrado.")
            sb.appendLine("- Duracao: Nao registrado.")
        } else {
            val durMs = (sessao.atualizadaEm - sessao.iniciadaEm).coerceAtLeast(0)
            val durMin = durMs / 60000.0
            sb.appendLine("- Objetivo: ${sessao.objetivo}")
            sb.appendLine("- Competencia investigada: ${sessao.competenciaNome}")
            sb.appendLine("- Data/hora de inicio: ${fmt(sessao.iniciadaEm)}")
            sb.appendLine("- Data/hora de termino: ${fmt(sessao.atualizadaEm)}")
            sb.appendLine("- Duracao: ${"%.1f".format(durMin)} min (${durMs} ms)")
            sb.appendLine("- Id da sessao: ${sessao.id}")
        }
        sb.appendLine()

        sb.appendLine("STATUS")
        if (sessao == null) {
            sb.appendLine("- CONCLUÍDO / PARCIAL / INTERROMPIDO / FALHOU: Nao registrado.")
            sb.appendLine("- Motivo: Nenhuma sessao encontrada.")
        } else {
            val st = when (sessao.status) {
                StatusSessaoLab.CONCLUIDA -> "CONCLUIDO"
                StatusSessaoLab.PAUSADA -> "PARCIAL"
                StatusSessaoLab.FALHA -> "FALHOU"
                else -> "PARCIAL / EM ANDAMENTO (${sessao.status})"
            }
            sb.appendLine("- Status: $st")
            val motivo = sessao.log.lastOrNull { it.contains("Limite", true) || it.contains("conclu", true) }
                ?: sessao.log.lastOrNull()
                ?: "Nao registrado."
            sb.appendLine("- Motivo / ultima nota: $motivo")
        }
        sb.appendLine()

        sb.appendLine("PESQUISA")
        sb.appendLine("- Pesquisas registradas: ${pesquisas.size}")
        sb.appendLine("- Fontes (URLs na sessao): ${sessao?.fontes?.size ?: 0}")
        if (sessao != null && sessao.fontes.isNotEmpty()) {
            sessao.fontes.take(20).forEach { sb.appendLine("  * $it") }
        } else {
            sb.appendLine("  * Nao registrado.")
        }
        sb.appendLine("- Detalhe de cada pesquisa:")
        if (pesquisas.isEmpty()) {
            sb.appendLine("  Nao registrado.")
        } else {
            pesquisas.take(30).forEachIndexed { i, p ->
                sb.appendLine("  [${i + 1}] ${p.titulo}")
                sb.appendLine("      ${p.corpo.take(800).replace("\n", "\n      ")}")
            }
        }
        sb.appendLine()

        sb.appendLine("ANALISE")
        val relComp = if (sessao != null) {
            rels.filter {
                it.competenciaSugerida.equals(sessao.competenciaNome, true) ||
                    it.objetivo.contains(sessao.objetivo.take(20), true)
            }
        } else rels
        sb.appendLine("- Relatorios da Lua relacionados: ${relComp.size}")
        if (relComp.isEmpty()) {
            sb.appendLine("- O que os relatorios da Lua mostraram: Nao registrado.")
        } else {
            relComp.take(5).forEach { r ->
                val local = LabAnalista.analisarRelatorioLocal(r)
                sb.appendLine("  * Missao (${if (r.sucesso) "OK" else "FALHA"}): ${r.objetivo.take(80)}")
                sb.appendLine("    Analise local: ${local.replace("\n", " | ").take(400)}")
            }
        }
        sb.appendLine("- Problemas / padroes: ver analises locais acima (quando houver).")
        sb.appendLine("- Relacao experiencia real + pesquisa: registrada nos logs da sessao e registros PESQUISA.")
        sb.appendLine()

        sb.appendLine("HIPOTESES")
        val hipF = if (sessao != null) {
            val cid = comps.firstOrNull { it.nome.equals(sessao.competenciaNome, true) }?.id
            if (cid != null) hip.filter { it.competenciaId == cid } else hip
        } else hip
        if (hipF.isEmpty()) {
            sb.appendLine("- Nao registrado.")
        } else {
            hipF.forEachIndexed { i, h ->
                sb.appendLine("- Hipotese ${i + 1}: ${h.texto}")
                sb.appendLine("  Evidencias/base: ${h.base}")
                sb.appendLine("  Confianca: (hipotese — nao validada como verdade)")
                sb.appendLine("  Status: ${h.status}")
            }
        }
        sb.appendLine()

        sb.appendLine("EXPERIMENTOS")
        val expF = if (sessao != null) {
            val cid = comps.firstOrNull { it.nome.equals(sessao.competenciaNome, true) }?.id
            if (cid != null) exps.filter { it.competenciaId == cid } else exps
        } else exps
        if (expF.isEmpty()) {
            sb.appendLine("- Nao registrado.")
        } else {
            expF.forEachIndexed { i, e ->
                sb.appendLine("- Experimento ${i + 1}: ${e.descricao}")
                sb.appendLine("  Resultado: ${if (e.sucesso) "funcionou (simulador)" else "falhou (simulador)"}")
                sb.appendLine("  Evidencia: ${e.resultado.take(500).replace("\n", " | ")}")
                sb.appendLine("  Aprendizado: ver resultado do simulador acima.")
            }
        }
        sb.appendLine()

        sb.appendLine("CONHECIMENTO CANDIDATO / VALIDADO")
        if (conhec.isEmpty()) {
            sb.appendLine("- Estrategia: Nao registrado.")
            sb.appendLine("- Foi validado? Nao.")
        } else {
            conhec.forEach { k ->
                sb.appendLine("- Competencia: ${k.competencia}")
                sb.appendLine("  Estrategias: ${k.estrategias.joinToString(" -> ")}")
                sb.appendLine("  Condicoes: ${k.condicoes.joinToString("; ").ifBlank { "Nao registrado." }}")
                sb.appendLine("  Evidencias: ${k.evidenciasSucesso.joinToString("; ").ifBlank { "Nao registrado." }}")
                sb.appendLine("  Falhas conhecidas: ${k.falhasConhecidas.joinToString("; ").ifBlank { "Nao registrado." }}")
                sb.appendLine("  Confianca: ${k.confianca}")
                sb.appendLine("  Validado: sim (autorizacao no Lab) em ${fmt(k.geradoEm)}")
            }
        }
        sb.appendLine()

        sb.appendLine("VALIDACAO")
        sb.appendLine("- Foi validado automaticamente pelo Lab? Nao (regra: so com autorizacao explicita).")
        sb.appendLine("- Quem autorizou: usuario no botao do Lab, se houver conhecimento listado acima.")
        sb.appendLine("- O que ainda precisa ser comprovado: uso real na Lua operacional (ponte ainda isolada).")
        sb.appendLine()

        sb.appendLine("LIMITES E AUDITORIA")
        sb.appendLine("- Internet do Lab permitida agora: ${LabConfig.internetPermitida(ctx)}")
        sb.appendLine("- Provedor de pesquisa: ${LabConfig.searchProvider(ctx)}")
        sb.appendLine("- Max pesquisas/sessao (config): ${LabConfig.maxPesquisasSessao(ctx)}")
        sb.appendLine("- Max ciclos (config): ${LabConfig.maxCiclosSessao(ctx)}")
        sb.appendLine("- Max minutos (config): ${LabConfig.maxMinutosSessao(ctx)}")
        if (sessao != null) {
            sb.appendLine("- Contadores da sessao: pesq=${sessao.pesquisas} hip=${sessao.hipoteses} exp=${sessao.experimentos}")
            sb.appendLine("- Log da sessao:")
            sessao.log.forEach { sb.appendLine("  * $it") }
        }
        sb.appendLine()

        sb.appendLine("CONCLUSAO DO LAB")
        sb.appendLine("- O que o Lab registrou ter feito: ver secoes PESQUISA, HIPOTESES, EXPERIMENTOS.")
        sb.appendLine("- O que ainda nao sabe: tudo que permanece como hipotese ou sem experimento real no app.")
        sb.appendLine("- O conhecimento esta pronto para a Lua operacional? Somente se validado E apos ponte futura (ainda nao automatica).")
        sb.appendLine()
        sb.appendLine("========================================")
        sb.appendLine("FIM DO RELATORIO")
        sb.appendLine("========================================")
        return sb.toString()
    }
}
