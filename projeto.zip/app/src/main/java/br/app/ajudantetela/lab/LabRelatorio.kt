package br.app.ajudantetela.lab

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object LabRelatorio {

    private fun fmt(ts: Long): String {
        if (ts <= 0L) return "Nao registrado."
        return try {
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(ts))
        } catch (_: Exception) {
            ts.toString()
        }
    }

    fun gerar(ctx: Context, sessaoId: String? = null): String {
        val sessoes = LabRepositorio.listarSessoes(ctx)
        val sessao = sessaoId?.let { id -> sessoes.firstOrNull { it.id == id } } ?: sessoes.firstOrNull()
        val comps = LabRepositorio.listarCompetencias(ctx)
        val rels = LabRepositorio.listarRelatorios(ctx)
        val hip = LabRepositorio.listarHipoteses(ctx)
        val exps = LabRepositorio.listarExperimentos(ctx)
        val regs = LabRepositorio.listarRegistros(ctx)
        val conhec = LabRepositorio.listarConhecimentosParaLua(ctx)
        val pesquisas = regs.filter { it.tipo == TipoRegistroLab.PESQUISA }
        val analises = regs.filter { it.titulo.contains("Analise automatica", true) }
        val ensinos = regs.filter { it.titulo.contains("Plano de ensino", true) }
        val comparacoes = regs.filter { it.titulo.contains("Comparacao", true) }
        val memErros = LabMemoriaErros.listar(ctx)

        val sb = StringBuilder()
        sb.appendLine("========================================")
        sb.appendLine("RELATORIO DO LUA LAB")
        sb.appendLine("========================================")
        sb.appendLine()

        sb.appendLine("OBJETIVO")
        sb.appendLine(sessao?.objetivo ?: rels.firstOrNull()?.objetivo ?: "Nao registrado.")
        sb.appendLine()

        sb.appendLine("RELATORIOS DA LUA ANALISADOS")
        sb.appendLine("- Quantidade armazenada: ${rels.size}")
        sb.appendLine("- Analises automaticas: ${analises.size}")
        if (rels.isEmpty()) {
            sb.appendLine("- Nao registrado.")
        } else {
            rels.take(8).forEach { r ->
                sb.appendLine("  * [${if (r.sucesso) "OK" else "FALHA"}] ${r.objetivo.take(70)} (${fmt(r.timestamp)})")
            }
        }
        sb.appendLine()

        sb.appendLine("PROBLEMA IDENTIFICADO")
        val ultimaAnalise = analises.firstOrNull()?.corpo
        if (ultimaAnalise.isNullOrBlank()) {
            sb.appendLine("Nao registrado.")
        } else {
            ultimaAnalise.lines().filter {
                it.contains("problema=", true) || it.contains("tipoProblema", true) ||
                    it.contains("Primeiro ponto", true)
            }.forEach { sb.appendLine(it) }
            if (sb.toString().endsWith("PROBLEMA IDENTIFICADO\n")) {
                sb.appendLine(ultimaAnalise.take(600))
            }
        }
        sb.appendLine()

        sb.appendLine("EVIDENCIAS")
        sb.appendLine("- Fontes: [RELATORIO] da Lua + [INFERENCIA] do Lab")
        analises.take(2).forEach { a ->
            sb.appendLine(a.corpo.take(900))
            sb.appendLine("---")
        }
        if (analises.isEmpty()) sb.appendLine("Nao registrado.")
        sb.appendLine()

        sb.appendLine("COMPARACAO COM TENTATIVAS ANTERIORES")
        if (comparacoes.isEmpty()) sb.appendLine("Nao registrado.")
        else comparacoes.take(3).forEach { sb.appendLine(it.corpo.take(500)); sb.appendLine("---") }
        sb.appendLine()

        sb.appendLine("MEMORIA DE ESTRATEGIAS QUE FALHARAM")
        if (memErros.isEmpty()) sb.appendLine("Nao registrado.")
        else memErros.take(15).forEach {
            sb.appendLine("- ${it.estrategia} | ${it.resultado} | ${it.contexto} | ${it.origem}")
        }
        sb.appendLine()

        sb.appendLine("PESQUISA REALIZADA")
        sb.appendLine("- Total registros PESQUISA: ${pesquisas.size}")
        if (pesquisas.isEmpty()) {
            sb.appendLine("Nao registrado.")
        } else {
            pesquisas.take(20).forEachIndexed { i, p ->
                sb.appendLine("[${i + 1}] ${p.titulo}")
                sb.appendLine(p.corpo.take(700).prependIndent("    "))
            }
        }
        sb.appendLine()

        sb.appendLine("ANALISE DO LAB")
        sb.appendLine("Juncao de relatorios + pesquisas + memoria de erros + comparacoes.")
        sb.appendLine(analises.firstOrNull()?.corpo?.take(1000) ?: "Nao registrado.")
        sb.appendLine()

        sb.appendLine("HIPOTESES")
        if (hip.isEmpty()) sb.appendLine("Nao registrado.")
        else hip.take(12).forEachIndexed { i, h ->
            sb.appendLine("- Hipotese ${i + 1}: ${h.texto}")
            sb.appendLine("  Base/evidencia: ${h.base}")
            sb.appendLine("  Status: ${h.status} | Confianca: hipotese (nao verdade)")
        }
        sb.appendLine()

        sb.appendLine("EXPERIMENTOS")
        if (exps.isEmpty()) {
            sb.appendLine("Nao registrado.")
        } else {
            exps.take(10).forEachIndexed { i, e ->
                sb.appendLine("- Exp ${i + 1}: ${e.descricao}")
                sb.appendLine("  Resultado: ${if (e.sucesso) "SIMULACAO OK" else "SIMULACAO FALHOU"}")
                sb.appendLine("  Evidencia: ${e.resultado.take(400).replace("\n", " | ")}")
                sb.appendLine("  Nota: simulacao NÃO prova funcionamento real na Lua.")
            }
        }
        sb.appendLine()

        sb.appendLine("O QUE FUNCIONOU")
        val okLines = rels.filter { it.sucesso }.map { it.objetivo }
        if (okLines.isEmpty()) sb.appendLine("Nenhuma missao real com sucesso registrada.")
        else okLines.take(5).forEach { sb.appendLine("- Missao real OK: $it") }
        exps.filter { it.sucesso }.forEach { sb.appendLine("- Simulador: ${it.descricao}") }
        sb.appendLine()

        sb.appendLine("O QUE NAO FUNCIONOU")
        memErros.take(10).forEach { sb.appendLine("- ${it.estrategia}") }
        rels.filter { !it.sucesso }.take(5).forEach {
            sb.appendLine("- Missao real FALHA: ${it.objetivo.take(60)}")
        }
        if (memErros.isEmpty() && rels.none { !it.sucesso }) sb.appendLine("Nao registrado.")
        sb.appendLine()

        sb.appendLine("O QUE O LAB ENSINARIA A LUA")
        if (ensinos.isEmpty()) sb.appendLine("Nao registrado.")
        else ensinos.take(2).forEach { sb.appendLine(it.corpo); sb.appendLine("---") }
        sb.appendLine()

        sb.appendLine("CONHECIMENTO CANDIDATO / VALIDADO")
        if (conhec.isEmpty()) {
            sb.appendLine("- Nenhum conhecimento VALIDADO armazenado.")
            sb.appendLine("- Candidatos: ver planos de ensino e hipoteses (nao sao validados).")
        } else {
            conhec.forEach { k ->
                sb.appendLine("- ${k.competencia} conf=${k.confianca}")
                sb.appendLine("  ${k.estrategias.joinToString(" -> ")}")
            }
        }
        sb.appendLine()

        sb.appendLine("STATUS DO CONHECIMENTO")
        comps.forEach { c ->
            val pronto = LabValidador.avaliarProntidao(ctx, c)
            val st = when {
                c.status == StatusCompetencia.VALIDADA && pronto.ok -> "Validado manualmente"
                c.status == StatusCompetencia.VALIDADA && !pronto.ok -> "INCONSISTENTE (corrigir: nao deveria estar validado)"
                conhec.any { it.competencia.equals(c.nome, true) } -> "Validado manualmente"
                ensinos.isNotEmpty() -> "Candidato"
                else -> "Nao testado / em investigacao"
            }
            sb.appendLine("- ${c.nome}: $st | prontidao=${pronto.ok}")
        }
        if (comps.isEmpty()) sb.appendLine("Nao registrado.")
        sb.appendLine()

        sb.appendLine("APLICACAO NA LUA")
        sb.appendLine("- Nao aplicado (ponte operacional ainda isolada).")
        sb.appendLine("- Resultado de simulador = SIMULACAO, nunca prova real.")
        sb.appendLine()

        sb.appendLine("SESSAO DE TREINAMENTO (se houver)")
        if (sessao == null) {
            sb.appendLine("Nao registrado.")
        } else {
            sb.appendLine("- Status: ${sessao.status}")
            sb.appendLine("- Pesquisas: ${sessao.pesquisas} | Hipoteses: ${sessao.hipoteses} | Exps: ${sessao.experimentos}")
            sb.appendLine("- Inicio: ${fmt(sessao.iniciadaEm)} | Fim: ${fmt(sessao.atualizadaEm)}")
            sb.appendLine("- Log:")
            sessao.log.forEach { sb.appendLine("  * $it") }
            sb.appendLine("- Fontes:")
            if (sessao.fontes.isEmpty()) sb.appendLine("  * Nao registrado.")
            else sessao.fontes.forEach { sb.appendLine("  * $it") }
        }
        sb.appendLine()

        sb.appendLine("PROXIMO EXPERIMENTO")
        sb.appendLine(
            ensinos.firstOrNull()?.corpo?.lines()?.lastOrNull { it.contains("Teste necessario", true) }
                ?: "Nova missao real da Lua no mesmo objetivo, evitando estrategias da memoria de erros."
        )
        sb.appendLine()

        sb.appendLine("CONCLUSAO DO LAB")
        sb.appendLine(
            "O Lab registra evidencias com origem [RELATORIO]/[PESQUISA]/[EXPERIMENTO]/[INFERENCIA]. " +
                "Hipoteses nao sao conhecimento. Simulacao nao e prova real. Validacao exige relatorio real + autorizacao."
        )
        sb.appendLine()
        sb.appendLine("========================================")
        sb.appendLine("FIM DO RELATORIO")
        sb.appendLine("========================================")
        return sb.toString()
    }
}
