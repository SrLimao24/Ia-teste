package br.app.ajudantetela

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

data class AcaoIA(
    val tipo: String,
    val pacote: String = "",
    val app: String = "",
    val texto: String = "",
    val alvo: String = "",
    val motivo: String = ""
)

data class ElementoUI(
    val id: Int,
    val classe: String,
    val texto: String,
    val descricao: String,
    val clicavel: Boolean,
    val focavel: Boolean,
    val editavel: Boolean,
    val esquerda: Int,
    val topo: Int,
    val direita: Int,
    val baixo: Int
) {
    fun resumo(): String = buildString {
        append("[$id] ${classe.substringAfterLast('.')}")
        if (texto.isNotEmpty()) append(" text="${texto.take(30)}"")
        if (descricao.isNotEmpty()) append(" desc="${descricao.take(40)}"")
        append(" click=$clicavel edit=$editavel")
        append(" b=($esquerda,$topo)-($direita,$baixo)")
    }
}

data class AppInstalado(
    val rotulo: String,
    val pacote: String
)

/** Campo candidato a receber texto. */
data class CampoEditavel(
    val id: Int,
    val classe: String,
    val texto: String,
    val dica: String,
    val descricao: String,
    val focado: Boolean,
    val habilitado: Boolean,
    val editavel: Boolean = true,
    val focavel: Boolean = false,
    val clicavel: Boolean = false,
    val esquerda: Int,
    val topo: Int,
    val direita: Int,
    val baixo: Int,
    val score: Int = 0
) {
    fun resumo(): String = buildString {
        append("[$id] ")
        append(classe.substringAfterLast('.').ifEmpty { classe })
        append(" edit=$editavel focusable=$focavel click=$clicavel")
        if (focado) append(" FOCADO")
        if (dica.isNotEmpty()) append(" hint=\"$dica\"")
        if (texto.isNotEmpty()) append(" texto=\"${texto.take(40)}\"")
        if (descricao.isNotEmpty()) append(" desc=\"${descricao.take(50)}\"")
        append(" score=$score")
        append(" bounds=(${esquerda},${topo})-(${direita},${baixo})")
    }
}

object InterpreteAcao {
    fun parse(resposta: String): AcaoIA? {
        val jsonStr = extrairJson(resposta) ?: return null
        return try {
            val o = JSONObject(jsonStr)
            AcaoIA(
                tipo = o.optString("acao", o.optString("tipo", "")).lowercase().trim(),
                pacote = o.optString("pacote", "").trim(),
                app = o.optString("app", o.optString("aplicativo", "")).trim(),
                texto = o.optString("texto", o.optString("mensagem", "")).trim(),
                alvo = o.optString("alvo", o.optString("campo", "")).trim(),
                motivo = o.optString("motivo", "").trim()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun extrairJson(s: String): String? {
        val t = s.trim()
        val fence = Regex("```(?:json)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        fence.find(t)?.groupValues?.getOrNull(1)?.trim()?.let { return it }
        val ini = t.indexOf('{')
        val fim = t.lastIndexOf('}')
        if (ini >= 0 && fim > ini) return t.substring(ini, fim + 1)
        return null
    }

    fun listarCamposEditaveis(raiz: AccessibilityNodeInfo?): List<CampoEditavel> {
        if (raiz == null) return emptyList()
        val bruto = mutableListOf<CampoEditavel>()
        coletarCandidatos(raiz, bruto, 0)
        return bruto.sortedByDescending { it.score }.mapIndexed { i, c -> c.copy(id = i) }
    }

    fun diagnosticoArvore(raiz: AccessibilityNodeInfo?, maxLinhas: Int = 45): String {
        if (raiz == null) return "rootInActiveWindow = null (sem árvore)."
        val linhas = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?, prof: Int) {
            if (n == null || prof > 45 || linhas.size >= maxLinhas) return
            val cls = n.className?.toString() ?: ""
            val short = cls.substringAfterLast('.')
            val desc = n.contentDescription?.toString().orEmpty()
            val hint = n.hintText?.toString().orEmpty()
            val interessante =
                n.isEditable || n.isFocused || n.isFocusable ||
                    short.contains("Edit", true) || short.contains("Text", true) ||
                    hint.isNotBlank() ||
                    desc.contains("pesquis", true) || desc.contains("search", true) ||
                    desc.contains("Meta AI", true) || desc.contains("mensagem", true) ||
                    desc.contains("message", true) || desc.contains("Pergunte", true)
            if (interessante && n.isVisibleToUser) {
                val r = Rect()
                n.getBoundsInScreen(r)
                linhas.add(
                    "• $short edit=${n.isEditable} focusable=${n.isFocusable} " +
                        "click=${n.isClickable} focused=${n.isFocused} " +
                        (if (hint.isNotBlank()) "hint=\"${hint.take(40)}\" " else "") +
                        (if (desc.isNotBlank()) "desc=\"${desc.take(45)}\" " else "") +
                        (n.text?.toString()?.takeIf { it.isNotBlank() }?.let { "text=\"${it.take(25)}\" " } ?: "") +
                        "b=${r.left},${r.top}-${r.right},${r.bottom}"
                )
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), prof + 1)
        }
        walk(raiz, 0)
        return if (linhas.isEmpty()) "Nenhum nó interessante visível."
        else "Diagnóstico (${linhas.size}):\n" + linhas.joinToString("\n")
    }

    private fun coletarCandidatos(
        n: AccessibilityNodeInfo?,
        saida: MutableList<CampoEditavel>,
        prof: Int
    ) {
        if (n == null || prof > 50) return
        if (n.isVisibleToUser && !n.isPassword && n.isEnabled) {
            val score = pontuarInput(n)
            if (score > 0) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.width() > 8 && r.height() > 8) {
                    saida.add(
                        CampoEditavel(
                            id = saida.size,
                            classe = n.className?.toString() ?: "",
                            texto = n.text?.toString()?.trim().orEmpty(),
                            dica = n.hintText?.toString()?.trim().orEmpty(),
                            descricao = n.contentDescription?.toString()?.trim().orEmpty(),
                            focado = n.isFocused,
                            habilitado = n.isEnabled,
                            editavel = n.isEditable,
                            focavel = n.isFocusable,
                            clicavel = n.isClickable,
                            esquerda = r.left,
                            topo = r.top,
                            direita = r.right,
                            baixo = r.bottom,
                            score = score
                        )
                    )
                }
            }
        }
        for (i in 0 until n.childCount) coletarCandidatos(n.getChild(i), saida, prof + 1)
    }

    private fun pontuarInput(n: AccessibilityNodeInfo): Int {
        var s = 0
        val cls = (n.className?.toString() ?: "").lowercase()
        val hint = (n.hintText?.toString() ?: "").lowercase()
        val desc = (n.contentDescription?.toString() ?: "").lowercase()
        val txt = (n.text?.toString() ?: "").lowercase()
        val bag = "$hint $desc $txt"

        if (n.isEditable) s += 100
        if (n.isFocused && (n.isEditable || n.isFocusable)) s += 45
        if (cls.contains("edittext") || cls.contains("autocompletetextview") ||
            cls.contains("textfield") || cls.contains("searchview")
        ) s += 80
        if (cls.contains("textinput") || (cls.contains("edit") && !cls.contains("textview"))) s += 50
        if (n.isFocusable && n.isClickable && (
                bag.contains("pesquis") || bag.contains("search") ||
                    bag.contains("meta ai") || bag.contains("digite") ||
                    bag.contains("type a message") || bag.contains("mensagem") ||
                    bag.contains("message") || bag.contains("pergunte") ||
                    bag.contains("ask ")
                )
        ) s += 75
        if (n.isFocusable && (bag.contains("pesquis") || bag.contains("search") || bag.contains("meta"))) s += 40
        if (cls.contains("button") && !n.isEditable) s -= 60
        if (cls.contains("imagebutton") || cls.contains("imageview")) s -= 50
        return s
    }

    fun escolherCampo(campos: List<CampoEditavel>, alvo: String): CampoEditavel? {
        if (campos.isEmpty()) return null
        val a = alvo.trim()
        if (a.isNotEmpty()) {
            a.toIntOrNull()?.let { id -> campos.firstOrNull { it.id == id }?.let { return it } }
            val low = a.lowercase()
            campos.firstOrNull {
                it.dica.lowercase().contains(low) ||
                    it.descricao.lowercase().contains(low) ||
                    it.texto.lowercase().contains(low)
            }?.let { return it }
        }
        campos.firstOrNull { it.focado }?.let { return it }
        return campos.firstOrNull { it.habilitado } ?: campos.firstOrNull()
    }


    fun listarElementosInterativos(raiz: AccessibilityNodeInfo?, max: Int = 35): List<ElementoUI> {
        if (raiz == null) return emptyList()
        val out = mutableListOf<ElementoUI>()
        fun walk(n: AccessibilityNodeInfo?, prof: Int) {
            if (n == null || prof > 45 || out.size >= max) return
            if (n.isVisibleToUser && n.isEnabled) {
                val txt = n.text?.toString()?.trim().orEmpty()
                val desc = n.contentDescription?.toString()?.trim().orEmpty()
                val useful = n.isClickable || n.isEditable || n.isFocusable ||
                    txt.isNotEmpty() || desc.isNotEmpty()
                if (useful && (n.isClickable || n.isEditable ||
                        txt.length in 1..40 || desc.length in 1..50)
                ) {
                    val r = android.graphics.Rect()
                    n.getBoundsInScreen(r)
                    if (r.width() > 4 && r.height() > 4) {
                        out.add(
                            ElementoUI(
                                id = out.size,
                                classe = n.className?.toString() ?: "",
                                texto = txt,
                                descricao = desc,
                                clicavel = n.isClickable,
                                focavel = n.isFocusable,
                                editavel = n.isEditable,
                                esquerda = r.left,
                                topo = r.top,
                                direita = r.right,
                                baixo = r.bottom
                            )
                        )
                    }
                }
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), prof + 1)
        }
        walk(raiz, 0)
        return out
    }

    fun pareceBotaoEnviar(el: ElementoUI): Boolean {
        val bag = "${el.texto} ${el.descricao}".lowercase()
        return bag.contains("enviar") || bag.contains("send") ||
            bag.contains("mandar") || bag == "➤" || bag.contains("submit")
    }

    fun listarAppsLauncher(ctx: Context): List<AppInstalado> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolve = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolve.mapNotNull { ri ->
            val rotulo = try {
                ri.loadLabel(pm)?.toString()?.trim().orEmpty()
            } catch (_: Exception) {
                ""
            }
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            if (rotulo.isEmpty()) null else AppInstalado(rotulo, pkg)
        }.distinctBy { it.pacote }
    }

    fun resolverNoDispositivo(ctx: Context, appOuPacote: String): AppInstalado? {
        val pedido = appOuPacote.trim()
        if (pedido.isEmpty()) return null
        val pedidoLow = pedido.lowercase()
        val apps = listarAppsLauncher(ctx)
        if (apps.isEmpty()) return null
        apps.firstOrNull { it.rotulo.equals(pedido, ignoreCase = true) }?.let { return it }
        apps.filter { it.rotulo.lowercase().contains(pedidoLow) }
            .minByOrNull { it.rotulo.length }?.let { return it }
        apps.firstOrNull { it.pacote.equals(pedido, ignoreCase = true) }?.let { return it }
        apps.firstOrNull { it.pacote.lowercase().contains(pedidoLow) }?.let { return it }
        val aliases = mapOf(
            "youtube" to listOf("youtube"),
            "whatsapp" to listOf("whatsapp"),
            "instagram" to listOf("instagram"),
            "telegram" to listOf("telegram"),
            "chrome" to listOf("chrome"),
            "gmail" to listOf("gmail", "mail"),
            "chatgpt" to listOf("chatgpt", "openai"),
            "gemini" to listOf("gemini"),
            "grok" to listOf("grok")
        )
        val chaves = aliases.entries
            .filter { pedidoLow == it.key || pedidoLow.contains(it.key) }
            .flatMap { it.value }
            .ifEmpty { listOf(pedidoLow) }
        for (chave in chaves) {
            apps.firstOrNull { it.rotulo.lowercase().contains(chave) }?.let { return it }
            apps.firstOrNull { it.pacote.lowercase().contains(chave) }?.let { return it }
        }
        return null
    }
}
