package br.app.ajudantetela

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import org.json.JSONObject

/**
 * Ação estruturada devolvida pela IA.
 */
data class AcaoIA(
    val tipo: String,
    val pacote: String = "",
    val app: String = "",
    val texto: String = "",
    val motivo: String = ""
)

data class AppInstalado(
    val rotulo: String,
    val pacote: String
)

object InterpreteAcao {
    fun parse(resposta: String): AcaoIA? {
        val jsonStr = extrairJson(resposta) ?: return null
        return try {
            val o = JSONObject(jsonStr)
            AcaoIA(
                tipo = o.optString("acao", o.optString("tipo", "")).lowercase().trim(),
                pacote = o.optString("pacote", "").trim(),
                app = o.optString("app", o.optString("aplicativo", "")).trim(),
                texto = o.optString("texto", o.optString("mensagem", "")).trim(),
                motivo = o.optString("motivo", o.optString("mensagem", "")).trim()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun extrairJson(s: String): String? {
        val t = s.trim()
        val fence = Regex("```(?:json)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        fence.find(t)?.groupValues?.getOrNull(1)?.trim()?.let { return it }
        val ini = t.indexOf('{')
        val fim = t.lastIndexOf('}')
        if (ini >= 0 && fim > ini) return t.substring(ini, fim + 1)
        return null
    }

    /**
     * Lista apps que aparecem na tela inicial (MAIN + LAUNCHER).
     * Requer &lt;queries&gt; no Manifest (Android 11+).
     */
    fun listarAppsLauncher(ctx: Context): List<AppInstalado> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolve = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolve.mapNotNull { ri ->
            val rotulo = try {
                ri.loadLabel(pm)?.toString()?.trim().orEmpty()
            } catch (_: Exception) {
                ""
            }
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            if (rotulo.isEmpty()) null else AppInstalado(rotulo, pkg)
        }.distinctBy { it.pacote }
    }

    /**
     * Resolve o pacote real no aparelho a partir do nome do app ou pacote sugerido pela IA.
     * 1) match exato do rótulo
     * 2) rótulo contém o nome
     * 3) pacote contém o nome / pacote sugerido
     * 4) aliases conhecidos só como dica de busca (não como verdade absoluta)
     */
    fun resolverNoDispositivo(ctx: Context, appOuPacote: String): AppInstalado? {
        val pedido = appOuPacote.trim()
        if (pedido.isEmpty()) return null
        val pedidoLow = pedido.lowercase()

        val apps = listarAppsLauncher(ctx)
        if (apps.isEmpty()) return null

        // 1) Rótulo exatamente igual
        apps.firstOrNull { it.rotulo.equals(pedido, ignoreCase = true) }?.let { return it }

        // 2) Rótulo contém o pedido (ex.: "YouTube" em "YouTube")
        apps.filter { it.rotulo.lowercase().contains(pedidoLow) }
            .minByOrNull { it.rotulo.length }
            ?.let { return it }

        // 3) Pacote igual ou contém
        apps.firstOrNull { it.pacote.equals(pedido, ignoreCase = true) }?.let { return it }
        apps.firstOrNull { it.pacote.lowercase().contains(pedidoLow) }?.let { return it }

        // 4) Aliases → palavras-chave para buscar no rótulo/pacote instalado
        val aliases = mapOf(
            "youtube" to listOf("youtube"),
            "whatsapp" to listOf("whatsapp"),
            "instagram" to listOf("instagram"),
            "telegram" to listOf("telegram"),
            "chrome" to listOf("chrome"),
            "gmail" to listOf("gmail", "mail"),
            "maps" to listOf("maps", "mapas"),
            "google maps" to listOf("maps", "mapas"),
            "tiktok" to listOf("tiktok", "tik tok"),
            "spotify" to listOf("spotify"),
            "chatgpt" to listOf("chatgpt", "openai"),
            "gemini" to listOf("gemini"),
            "claude" to listOf("claude"),
            "grok" to listOf("grok"),
            "settings" to listOf("settings", "configura"),
            "configurações" to listOf("configura", "settings"),
            "configuracoes" to listOf("configura", "settings")
        )
        val chaves = aliases.entries
            .filter { pedidoLow == it.key || pedidoLow.contains(it.key) }
            .flatMap { it.value }
            .ifEmpty { listOf(pedidoLow) }

        for (chave in chaves) {
            apps.firstOrNull { it.rotulo.lowercase().contains(chave) }?.let { return it }
            apps.firstOrNull { it.pacote.lowercase().contains(chave) }?.let { return it }
        }

        return null
    }
}
