package br.app.ajudantetela

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

/**
 * Ação estruturada devolvida pela IA.
 */
data class AcaoIA(
    val tipo: String,
    val pacote: String = "",
    val app: String = "",
    val texto: String = "",
    val alvo: String = "",
    val motivo: String = ""
)

data class AppInstalado(
    val rotulo: String,
    val pacote: String
)

/** Elemento editável encontrado na árvore de acessibilidade. */
data class CampoEditavel(
    val id: Int,
    val classe: String,
    val texto: String,
    val dica: String,
    val descricao: String,
    val focado: Boolean,
    val habilitado: Boolean,
    val esquerda: Int,
    val topo: Int,
    val direita: Int,
    val baixo: Int
) {
    fun resumo(): String = buildString {
        append("[$id] ")
        append(classe.substringAfterLast('.').ifEmpty { classe })
        if (focado) append(" FOCADO")
        if (dica.isNotEmpty()) append(" hint=\"$dica\"")
        if (texto.isNotEmpty()) append(" texto=\"${texto.take(40)}\"")
        if (descricao.isNotEmpty()) append(" desc=\"$descricao\"")
        append(" bounds=(${esquerda},${topo})-(${direita},${baixo})")
    }
}

object InterpreteAcao {
    fun parse(resposta: String): AcaoIA? {
        val jsonStr = extrairJson(resposta) ?: return null
        return try {
            val o = JSONObject(jsonStr)
            AcaoIA(
                tipo = o.optString("acao", o.optString("tipo", "")).lowercase().trim(),
                pacote = o.optString("pacote", "").trim(),
                app = o.optString("app", o.optString("aplicativo", "")).trim(),
                texto = o.optString("texto", o.optString("mensagem", "")).trim(),
                alvo = o.optString("alvo", o.optString("campo", "")).trim(),
                motivo = o.optString("motivo", "").trim()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun extrairJson(s: String): String? {
        val t = s.trim()
        val fence = Regex("```(?:json)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        fence.find(t)?.groupValues?.getOrNull(1)?.trim()?.let { return it }
        val ini = t.indexOf('{')
        val fim = t.lastIndexOf('}')
        if (ini >= 0 && fim > ini) return t.substring(ini, fim + 1)
        return null
    }

    /**
     * Percorre a árvore e lista campos que podem receber texto.
     * Ignora senha e nós invisíveis.
     */
    fun listarCamposEditaveis(raiz: AccessibilityNodeInfo?): List<CampoEditavel> {
        if (raiz == null) return emptyList()
        val saida = mutableListOf<CampoEditavel>()
        coletarEditaveis(raiz, saida, 0)
        return saida
    }

    private fun coletarEditaveis(
        n: AccessibilityNodeInfo?,
        saida: MutableList<CampoEditavel>,
        prof: Int
    ) {
        if (n == null || prof > 50) return
        if (n.isVisibleToUser && n.isEditable && !n.isPassword) {
            val r = Rect()
            n.getBoundsInScreen(r)
            // ignora retângulos degenerados
            if (r.width() > 8 && r.height() > 8) {
                saida.add(
                    CampoEditavel(
                        id = saida.size,
                        classe = n.className?.toString() ?: "",
                        texto = n.text?.toString()?.trim().orEmpty(),
                        dica = n.hintText?.toString()?.trim().orEmpty(),
                        descricao = n.contentDescription?.toString()?.trim().orEmpty(),
                        focado = n.isFocused,
                        habilitado = n.isEnabled,
                        esquerda = r.left,
                        topo = r.top,
                        direita = r.right,
                        baixo = r.bottom
                    )
                )
            }
        }
        for (i in 0 until n.childCount) {
            coletarEditaveis(n.getChild(i), saida, prof + 1)
        }
    }

    /**
     * Escolhe o campo-alvo:
     * 1) id numérico no "alvo"
     * 2) match por hint/desc/texto
     * 3) campo focado
     * 4) único campo na tela
     * 5) primeiro habilitado
     */
    fun escolherCampo(campos: List<CampoEditavel>, alvo: String): CampoEditavel? {
        if (campos.isEmpty()) return null
        val a = alvo.trim()
        if (a.isNotEmpty()) {
            a.toIntOrNull()?.let { id ->
                campos.firstOrNull { it.id == id }?.let { return it }
            }
            val low = a.lowercase()
            campos.firstOrNull {
                it.dica.lowercase().contains(low) ||
                    it.descricao.lowercase().contains(low) ||
                    it.texto.lowercase().contains(low) ||
                    it.classe.lowercase().contains(low)
            }?.let { return it }
        }
        campos.firstOrNull { it.focado }?.let { return it }
        if (campos.size == 1) return campos.first()
        return campos.firstOrNull { it.habilitado } ?: campos.first()
    }

    fun listarAppsLauncher(ctx: Context): List<AppInstalado> {
        val pm = ctx.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolve = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        return resolve.mapNotNull { ri ->
            val rotulo = try {
                ri.loadLabel(pm)?.toString()?.trim().orEmpty()
            } catch (_: Exception) {
                ""
            }
            val pkg = ri.activityInfo?.packageName ?: return@mapNotNull null
            if (rotulo.isEmpty()) null else AppInstalado(rotulo, pkg)
        }.distinctBy { it.pacote }
    }

    fun resolverNoDispositivo(ctx: Context, appOuPacote: String): AppInstalado? {
        val pedido = appOuPacote.trim()
        if (pedido.isEmpty()) return null
        val pedidoLow = pedido.lowercase()
        val apps = listarAppsLauncher(ctx)
        if (apps.isEmpty()) return null

        apps.firstOrNull { it.rotulo.equals(pedido, ignoreCase = true) }?.let { return it }
        apps.filter { it.rotulo.lowercase().contains(pedidoLow) }
            .minByOrNull { it.rotulo.length }
            ?.let { return it }
        apps.firstOrNull { it.pacote.equals(pedido, ignoreCase = true) }?.let { return it }
        apps.firstOrNull { it.pacote.lowercase().contains(pedidoLow) }?.let { return it }

        val aliases = mapOf(
            "youtube" to listOf("youtube"),
            "whatsapp" to listOf("whatsapp"),
            "instagram" to listOf("instagram"),
            "telegram" to listOf("telegram"),
            "chrome" to listOf("chrome"),
            "gmail" to listOf("gmail", "mail"),
            "maps" to listOf("maps", "mapas"),
            "tiktok" to listOf("tiktok"),
            "spotify" to listOf("spotify"),
            "chatgpt" to listOf("chatgpt", "openai"),
            "gemini" to listOf("gemini"),
            "claude" to listOf("claude"),
            "grok" to listOf("grok")
        )
        val chaves = aliases.entries
            .filter { pedidoLow == it.key || pedidoLow.contains(it.key) }
            .flatMap { it.value }
            .ifEmpty { listOf(pedidoLow) }
        for (chave in chaves) {
            apps.firstOrNull { it.rotulo.lowercase().contains(chave) }?.let { return it }
            apps.firstOrNull { it.pacote.lowercase().contains(chave) }?.let { return it }
        }
        return null
    }
}
