package br.app.ajudantetela

import org.json.JSONObject

/**
 * Ação estruturada devolvida pela IA.
 * Ciclo mínimo v1: abrir_app, dizer, concluir, erro.
 */
data class AcaoIA(
    val tipo: String,
    val pacote: String = "",
    val app: String = "",
    val texto: String = "",
    val motivo: String = ""
)

object InterpreteAcao {
    /**
     * Extrai JSON de uma resposta de modelo (pode vir com ```json ... ```).
     */
    fun parse(resposta: String): AcaoIA? {
        val jsonStr = extrairJson(resposta) ?: return null
        return try {
            val o = JSONObject(jsonStr)
            AcaoIA(
                tipo = o.optString("acao", o.optString("tipo", "")).lowercase().trim(),
                pacote = o.optString("pacote", "").trim(),
                app = o.optString("app", o.optString("aplicativo", "")).trim(),
                texto = o.optString("texto", o.optString("mensagem", "")).trim(),
                motivo = o.optString("motivo", o.optString("mensagem", "")).trim()
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun extrairJson(s: String): String? {
        val t = s.trim()
        // bloco markdown
        val fence = Regex("```(?:json)?\\s*([\\s\\S]*?)```", RegexOption.IGNORE_CASE)
        fence.find(t)?.groupValues?.getOrNull(1)?.trim()?.let { return it }
        // objeto direto
        val ini = t.indexOf('{')
        val fim = t.lastIndexOf('}')
        if (ini >= 0 && fim > ini) return t.substring(ini, fim + 1)
        return null
    }

    /** Mapa simples nome → pacote para o teste mínimo. */
    fun resolverPacote(appOuPacote: String): String? {
        val s = appOuPacote.lowercase().trim()
        if (s.contains('.') && !s.contains(' ')) return s // já parece pacote
        val mapa = mapOf(
            "whatsapp" to "com.whatsapp",
            "whatsapp business" to "com.whatsapp.w4b",
            "telegram" to "org.telegram.messenger",
            "chrome" to "com.android.chrome",
            "youtube" to "com.google.android.youtube",
            "instagram" to "com.instagram.android",
            "gmail" to "com.google.android.gm",
            "maps" to "com.google.android.apps.maps",
            "google maps" to "com.google.android.apps.maps",
            "settings" to "com.android.settings",
            "configurações" to "com.android.settings",
            "configuracoes" to "com.android.settings",
            "camera" to "com.android.camera",
            "câmera" to "com.android.camera",
            "telefone" to "com.android.dialer",
            "contatos" to "com.android.contacts",
            "fotos" to "com.google.android.apps.photos",
            "spotify" to "com.spotify.music",
            "chatgpt" to "com.openai.chatgpt",
            "gemini" to "com.google.android.apps.gemini",
            "claude" to "com.anthropic.claude",
            "grok" to "ai.x.grok"
        )
        // match por contém
        mapa.entries.firstOrNull { s == it.key || s.contains(it.key) }?.value?.let { return it }
        return null
    }
}
