package br.app.ajudantetela.lab

import android.content.Context

/**
 * Criterios para promover DESCOBERTA → CONHECIMENTO_VALIDADO.
 * Nunca promove sozinho so por resposta de IA.
 */
object LabValidador {

    data class CriterioResultado(
        val ok: Boolean,
        val motivos: List<String>
    )

    fun avaliarProntidao(ctx: Context, competencia: CompetenciaLab): CriterioResultado {
        val regs = LabRepositorio.listarRegistros(ctx)
            .filter { it.competenciaId == competencia.id || competencia.relatorioIds.any { id -> id in it.origemRelatorioIds } }
        val exps = LabRepositorio.listarExperimentos(ctx).filter { it.competenciaId == competencia.id }
        val hip = LabRepositorio.listarHipoteses(ctx).filter { it.competenciaId == competencia.id }
        val motivos = mutableListOf<String>()
        var ok = true
        if (competencia.relatorioIds.isEmpty()) {
            ok = false; motivos += "Sem relatorios de missao reais"
        } else motivos += "Relatorios: ${competencia.relatorioIds.size}"
        if (exps.none { it.sucesso }) {
            ok = false; motivos += "Nenhum experimento com sucesso"
        } else motivos += "Experimentos OK: ${exps.count { it.sucesso }}"
        if (hip.isEmpty()) {
            motivos += "Sem hipoteses formalizadas (recomendado)"
        }
        // exige validacao humana nesta fase mesmo se ok
        motivos += "Validacao final ainda requer confirmacao explicita no Lab"
        return CriterioResultado(ok, motivos)
    }

    fun gerarConhecimentoEstruturado(
        ctx: Context,
        competencia: CompetenciaLab
    ): ConhecimentoParaLua {
        val expsOk = LabRepositorio.listarExperimentos(ctx)
            .filter { it.competenciaId == competencia.id && it.sucesso }
        val falhas = LabRepositorio.listarExperimentos(ctx)
            .filter { it.competenciaId == competencia.id && !it.sucesso }
            .map { it.descricao }
            .distinct()
        val estrats = listOf(
            "Abrir aplicativo alvo",
            "Localizar pesquisa/contato pelo texto (nao layout generico)",
            "Clicar ancestral com ACTION_CLICK",
            "Abrir conversa",
            "Digitar mensagem",
            "Clicar Enviar e verificar evidencia de envio (campo vazio / bolha)"
        )
        return LabAnalista.validarConhecimento(
            ctx,
            competencia,
            estrategias = estrats,
            evidencias = listOf(
                "Conversa correta",
                "Campo mensagem",
                "Evidencia pos-envio"
            ),
            falhas = falhas.ifEmpty {
                listOf("TextView sem clique", "Layout generico", "Envio sem evidencia")
            }
        )
    }
}
