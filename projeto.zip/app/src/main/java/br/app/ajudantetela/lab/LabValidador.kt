package br.app.ajudantetela.lab

import android.content.Context

object LabValidador {

    data class CriterioResultado(
        val ok: Boolean,
        val motivos: List<String>
    )

    fun avaliarProntidao(ctx: Context, competencia: CompetenciaLab): CriterioResultado {
        val regs = LabRepositorio.listarRegistros(ctx)
        val exps = LabRepositorio.listarExperimentos(ctx).filter { it.competenciaId == competencia.id }
        val hip = LabRepositorio.listarHipoteses(ctx).filter { it.competenciaId == competencia.id }
        val motivos = mutableListOf<String>()
        var ok = true

        if (competencia.relatorioIds.isEmpty()) {
            ok = false
            motivos += "Sem relatorios de missao reais — nao pode validar"
        } else {
            motivos += "Relatorios reais: ${competencia.relatorioIds.size}"
        }

        val temAnalise = regs.any {
            it.titulo.contains("Analise automatica", true) &&
                it.origemRelatorioIds.any { id -> id in competencia.relatorioIds }
        }
        if (!temAnalise) {
            motivos += "Analise automatica ainda nao encontrada para estes relatorios"
        } else {
            motivos += "Ha analise automatica associada"
        }

        if (exps.isEmpty()) {
            motivos += "Nenhum experimento registrado (simulador opcional)"
        } else {
            motivos += "Experimentos: ${exps.size} (ok=${exps.count { it.sucesso }}) — simulacao NAO e prova real"
        }

        if (hip.isEmpty()) {
            motivos += "Sem hipoteses formalizadas"
        }

        motivos += "Validacao final exige autorizacao explicita do usuario"
        motivos += "Simulador nunca conta como prova de funcionamento real na Lua"
        return CriterioResultado(ok, motivos)
    }

    /**
     * So grava CONHECIMENTO_VALIDADO se houver relatorio real + autorizacao (chamada do botao).
     * Se prontidao=false, NAO grava como validado.
     */
    fun gerarConhecimentoEstruturado(
        ctx: Context,
        competencia: CompetenciaLab
    ): ConhecimentoParaLua? {
        val pronto = avaliarProntidao(ctx, competencia)
        if (!pronto.ok) {
            LabRepositorio.adicionarRegistro(
                ctx,
                RegistroLab(
                    id = "val_rec_" + System.currentTimeMillis(),
                    tipo = TipoRegistroLab.EXPERIENCIA,
                    competenciaId = competencia.id,
                    titulo = "Validacao RECUSADA",
                    corpo = "Prontidao=false. Motivos: " + pronto.motivos.joinToString("; ") +
                        "\nStatus do conhecimento: NAO VALIDADO",
                    confianca = 0,
                    timestamp = System.currentTimeMillis()
                )
            )
            return null
        }
        val falhas = LabMemoriaErros.listar(ctx, competencia.nome).map { it.estrategia }.distinct()
        val estrats = listOf(
            "Abrir aplicativo alvo",
            "Pesquisar/localizar contato pelo texto",
            "Clicar ancestral com ACTION_CLICK (nao so TextView/EditText)",
            "Confirmar mudanca de tela (conversa)",
            "Digitar mensagem",
            "Enviar e verificar evidencia de envio"
        )
        return LabAnalista.validarConhecimento(
            ctx,
            competencia,
            estrategias = estrats,
            evidencias = listOf(
                "Relatorios reais da Lua associados",
                "Analise automatica do Lab",
                "Autorizacao explicita do usuario"
            ),
            falhas = falhas.ifEmpty {
                listOf("Clique so no texto", "Layout generico", "Envio sem evidencia")
            }
        )
    }
}
