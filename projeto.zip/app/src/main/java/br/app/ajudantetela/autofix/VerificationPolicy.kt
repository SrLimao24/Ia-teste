package br.app.ajudantetela.autofix

enum class ActionClass {
    READ_ONLY,
    DUPLICABLE,
    NON_DUPLICABLE
}

data class PolicyDecision(
    val allowAction: Boolean,
    val reason: String
)

object VerificationPolicy {

    fun afterVerification(
        actionClass: ActionClass,
        result: VerificationResult
    ): PolicyDecision {
        return when (result) {
            VerificationResult.SUCCESS ->
                PolicyDecision(false, "Objetivo confirmado; encerrar missao.")

            VerificationResult.ACTION_FAILED ->
                PolicyDecision(true, "Acao falhou antes de efeito; recuperacao permitida.")

            VerificationResult.FAILURE ->
                if (actionClass == ActionClass.DUPLICABLE)
                    PolicyDecision(false, "Falha concreta; nao repetir acao duplicavel automaticamente.")
                else
                    PolicyDecision(true, "Falha concreta; recuperacao nao duplicavel pode ser avaliada.")

            VerificationResult.UNKNOWN ->
                if (actionClass == ActionClass.DUPLICABLE)
                    PolicyDecision(false, "Estado incerto; bloquear repeticao duplicavel.")
                else
                    PolicyDecision(true, "Estado incerto; somente acoes seguras/read-only.")
        }
    }
}
