package br.app.ajudantetela.lab

import android.content.Context

/**
 * Pesquisa orientada a competencia + geracao da PROXIMA pergunta.
 */
object LabPesquisador {

    data class Rodada(
        val pergunta: String,
        val motivo: String,
        val resultados: List<ResultadoPesquisaWeb>,
        val conclusao: String,
        val proximaPergunta: String?
    )

    fun perguntaInicial(objetivo: String, competencia: String): Pair<String, String> {
        val base = competencia.ifBlank { objetivo }
        return Pair(
            base + " Android AccessibilityService como automatizar",
            "Entender como a acessibilidade do Android permite esta tarefa"
        )
    }

    fun proximaPerguntaApos(
        objetivo: String,
        competencia: String,
        rodadas: List<Rodada>,
        relatoriosResumo: String
    ): Pair<String, String>? {
        val n = rodadas.size
        val base = competencia.ifBlank { objetivo }
        val texto = (rodadas.flatMap { it.resultados.map { r -> r.titulo + " " + r.trecho } } + listOf(relatoriosResumo))
            .joinToString(" ")
            .lowercase()

        return when {
            n == 0 -> perguntaInicial(objetivo, competencia)
            n == 1 && (base.contains("WhatsApp", true) || objetivo.contains("mensagem", true)) ->
                Pair(
                    "WhatsApp accessibility click contact list item ACTION_CLICK",
                    "Descobrir como clicar no contato certo na lista de resultados"
                )
            n == 2 && objetivo.contains("mensagem", true) ->
                Pair(
                    "Android AccessibilityNodeInfo verify text sent EditText empty after send",
                    "Descobrir como confirmar que a mensagem foi enviada"
                )
            n == 3 && (texto.contains("image") || objetivo.contains("imagem", true)) ->
                Pair(
                    "Android ImageView contentDescription OCR accessibility",
                    "Investigar como imagens aparecem na arvore de acessibilidade"
                )
            n < 5 && texto.contains("click") ->
                Pair(
                    "Android accessibility performAction ACTION_CLICK parent clickable node",
                    "Aprofundar clique em ancestral clicavel vs TextView"
                )
            n < 6 && !texto.contains("accessibility") ->
                Pair(
                    base + " accessibility tree UIAutomator",
                    "Ainda pouco sobre arvore de acessibilidade — aprofundar"
                )
            else -> null
        }
    }

    fun executarUmaPesquisa(
        ctx: Context,
        competenciaId: String,
        pergunta: String,
        motivo: String
    ): Rodada {
        val provedor = LabPesquisaFabrica.criar(ctx)
        val res = try {
            provedor.pesquisar(ctx, pergunta, 5)
        } catch (e: Exception) {
            listOf(
                ResultadoPesquisaWeb(pergunta, "Erro", "", e.message.orEmpty(), "error")
            )
        }
        val conclusao = when {
            res.all { it.fonte == "stub" } ->
                "Pesquisa nao executada (internet bloqueada ou sem provedor)."
            res.any { it.fonte.endsWith("error") } ->
                "Houve erro na pesquisa; resultados limitados."
            res.any { it.trecho.length > 40 } ->
                "Foram encontrados trechos potencialmente uteis para a competencia."
            else -> "Resultados curtos ou vazios."
        }
        val corpo = buildString {
            append("Motivo: ").append(motivo).append('\n')
            append("Pergunta: ").append(pergunta).append('\n')
            append("Conclusao: ").append(conclusao).append('\n')
            res.forEach { r ->
                append("- ").append(r.titulo).append(" | ").append(r.trecho.take(140))
                append(" | ").append(r.url).append('\n')
            }
        }
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = "pesq_" + System.currentTimeMillis(),
                tipo = TipoRegistroLab.PESQUISA,
                competenciaId = competenciaId,
                titulo = "Pesquisa: " + pergunta.take(50),
                corpo = corpo,
                confianca = if (provedor.nome == "stub") 5 else 40,
                timestamp = System.currentTimeMillis()
            )
        )
        return Rodada(pergunta, motivo, res, conclusao, null)
    }
}
