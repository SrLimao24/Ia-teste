package br.app.ajudantetela.lab

import android.content.Context

object LabPesquisador {

    data class Rodada(
        val pergunta: String,
        val motivo: String,
        val resultados: List<ResultadoPesquisaWeb>,
        val conclusao: String,
        val proximaPergunta: String?
    )

    private fun perguntasJaFeitas(ctx: Context): Set<String> {
        return LabRepositorio.listarRegistros(ctx)
            .filter { it.tipo == TipoRegistroLab.PESQUISA }
            .mapNotNull { r ->
                r.corpo.lines().firstOrNull { it.startsWith("Pergunta:") }
                    ?.removePrefix("Pergunta:")?.trim()?.lowercase()
            }
            .filter { it.isNotBlank() }
            .toSet()
    }

    fun perguntaInicial(objetivo: String, competencia: String): Pair<String, String> {
        val base = competencia.ifBlank { objetivo }
        return Pair(
            base + " Android AccessibilityNodeInfo clickable parent of text node",
            "Entender como clicar o item certo quando o texto nao e o no clicavel"
        )
    }

    /**
     * Proxima pergunta adaptativa, evitando repetir pesquisas ja feitas.
     */
    fun proximaPerguntaApos(
        ctx: Context,
        objetivo: String,
        competencia: String,
        rodadas: List<Rodada>,
        relatoriosResumo: String,
        tipoProblema: String = ""
    ): Pair<String, String>? {
        val feitas = perguntasJaFeitas(ctx) + rodadas.map { it.pergunta.lowercase() }.toSet()
        val base = competencia.ifBlank { objetivo }
        val texto = (rodadas.flatMap { it.resultados.map { r -> r.titulo + " " + r.trecho } } +
            listOf(relatoriosResumo, tipoProblema)).joinToString(" ").lowercase()

        val candidatos = mutableListOf<Pair<String, String>>()

        when {
            tipoProblema.contains("clique") || texto.contains("sem efeito") || texto.contains("bela") -> {
                candidatos += Pair(
                    "Android AccessibilityNodeInfo ACTION_CLICK parent of TextView RecyclerView item",
                    "Erro de clique: texto pode estar em filho nao clicavel"
                )
                candidatos += Pair(
                    "WhatsApp search result click contact row accessibility node hierarchy",
                    "Estrutura de item de contato no WhatsApp via acessibilidade"
                )
                candidatos += Pair(
                    "UiAutomator click list item by text find clickable ancestor",
                    "Alternativa: ancestral clicavel a partir do texto"
                )
            }
            tipoProblema.contains("digit") -> {
                candidatos += Pair(
                    "Android AccessibilityNodeInfo ACTION_SET_TEXT focus EditText",
                    "Problema de digitacao/foco"
                )
            }
            tipoProblema.contains("confirm") || tipoProblema.contains("envio") -> {
                candidatos += Pair(
                    "detect message sent accessibility EditText empty chat bubble",
                    "Como confirmar envio na arvore de acessibilidade"
                )
            }
            else -> {
                candidatos += perguntaInicial(objetivo, competencia)
                candidatos += Pair(
                    base + " accessibility automation common failures click text",
                    "Falhas comuns de clique por texto"
                )
            }
        }

        if (rodadas.size >= 1) {
            candidatos += Pair(
                "Android accessibility tree dump debug clickable bounds contentDescription",
                "Pesquisa anterior insuficiente — mudar para estrutura/bounds/desc"
            )
        }
        if (rodadas.size >= 2) {
            candidatos += Pair(
                "espresso uiautomator click on parent layout of textview",
                "Mudar abordagem: layout pai em vez de ACTION_CLICK generico"
            )
        }

        for (c in candidatos) {
            val key = c.first.lowercase()
            val similar = feitas.any { f ->
                f == key || (f.length > 20 && key.contains(f.take(40))) || (key.length > 20 && f.contains(key.take(40)))
            }
            if (!similar) return c
        }
        return null // todas as perguntas uteis ja foram feitas
    }

    fun executarUmaPesquisa(
        ctx: Context,
        competenciaId: String,
        pergunta: String,
        motivo: String
    ): Rodada {
        val feitas = perguntasJaFeitas(ctx)
        if (feitas.any { it == pergunta.lowercase() || (it.length > 25 && pergunta.lowercase().contains(it.take(40))) }) {
            val msg = "Pesquisa repetida evitada: ja feita anteriormente — $pergunta"
            LabRepositorio.adicionarRegistro(
                ctx,
                RegistroLab(
                    id = "pesq_skip_" + System.currentTimeMillis(),
                    tipo = TipoRegistroLab.PESQUISA,
                    competenciaId = competenciaId,
                    titulo = "Pesquisa repetida EVITADA",
                    corpo = "Motivo original: $motivo\nPergunta: $pergunta\nConclusao: $msg",
                    confianca = 10,
                    timestamp = System.currentTimeMillis()
                )
            )
            return Rodada(pergunta, motivo, emptyList(), msg, null)
        }

        val provedor = LabPesquisaFabrica.criar(ctx)
        val res = try {
            provedor.pesquisar(ctx, pergunta, 5)
        } catch (e: Exception) {
            listOf(ResultadoPesquisaWeb(pergunta, "Erro", "", e.message.orEmpty(), "error"))
        }
        val util = res.any { it.trecho.length > 40 && it.fonte != "stub" && !it.fonte.endsWith("error") }
        val conclusao = when {
            res.all { it.fonte == "stub" } -> "Pesquisa nao executada (internet bloqueada ou sem provedor)."
            !util -> "Resultados pouco uteis — proxima rodada deve mudar a pergunta."
            else -> "Trechos potencialmente uteis encontrados."
        }
        val corpo = buildString {
            append("Motivo: ").append(motivo).append('\n')
            append("Pergunta: ").append(pergunta).append('\n')
            append("Conclusao: ").append(conclusao).append('\n')
            append("Util: ").append(util).append('\n')
            res.forEach { r ->
                append("- ").append(r.titulo).append(" | ").append(r.trecho.take(140))
                append(" | ").append(r.url).append('\n')
            }
        }
        LabRepositorio.adicionarRegistro(
            ctx,
            RegistroLab(
                id = "pesq_" + System.currentTimeMillis(),
                tipo = TipoRegistroLab.PESQUISA,
                competenciaId = competenciaId,
                titulo = "Pesquisa: " + pergunta.take(50),
                corpo = corpo,
                confianca = if (provedor.nome == "stub") 5 else if (util) 45 else 15,
                timestamp = System.currentTimeMillis()
            )
        )
        return Rodada(pergunta, motivo, res, conclusao, null)
    }
}
