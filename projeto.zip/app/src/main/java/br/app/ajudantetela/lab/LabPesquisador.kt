package br.app.ajudantetela.lab

import android.content.Context

/**
 * Organiza consultas web em torno de uma COMPETENCIA (nao "pesquise tudo").
 */
object LabPesquisador {

    fun queriesParaCompetencia(objetivo: String, competencia: String): List<String> {
        val base = competencia.ifBlank { objetivo }
        return listOf(
            "$base Android AccessibilityService",
            "$base UI automation accessibility tree",
            "WhatsApp accessibility send message confirm delivered",
            "Android AccessibilityNodeInfo ACTION_CLICK list item",
            "$base verify message sent UI state"
        ).distinct()
    }

    fun executarRodadaPesquisa(
        ctx: Context,
        sessaoId: String,
        competenciaId: String,
        objetivo: String,
        competenciaNome: String
    ): List<ResultadoPesquisaWeb> {
        val provedor = LabPesquisaFabrica.criar(ctx)
        val queries = queriesParaCompetencia(objetivo, competenciaNome).take(3)
        val todos = mutableListOf<ResultadoPesquisaWeb>()
        queries.forEach { q ->
            val res = try {
                provedor.pesquisar(ctx, q, 4)
            } catch (e: Exception) {
                listOf(
                    ResultadoPesquisaWeb(q, "Excecao pesquisa", "", e.message.orEmpty(), "error")
                )
            }
            todos.addAll(res)
            val corpo = res.joinToString("\n") { r ->
                "- " + r.titulo + ": " + r.trecho.take(160) + " (" + r.url + ")"
            }
            LabRepositorio.adicionarRegistro(
                ctx,
                RegistroLab(
                    id = "pesq_" + System.currentTimeMillis() + "_" + q.hashCode(),
                    tipo = TipoRegistroLab.PESQUISA,
                    competenciaId = competenciaId,
                    titulo = "Pesquisa: " + q.take(60),
                    corpo = corpo,
                    confianca = if (provedor.nome == "stub") 5 else 35,
                    timestamp = System.currentTimeMillis()
                )
            )
        }
        return todos
    }
}
