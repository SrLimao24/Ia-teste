package br.app.ajudantetela

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Memória local de estratégias semânticas (não coordenadas).
 * Gemini ensina; a Lua reutiliza quando o objetivo for parecido.
 */
data class PassoSemantico(
    val acao: String,
    val alvo: String = "",
    val texto: String = "",
    val app: String = "",
    val motivo: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("acao", acao)
        .put("alvo", alvo)
        .put("texto", texto)
        .put("app", app)
        .put("motivo", motivo)

    fun resumoLinha(): String = buildString {
        append(acao)
        if (app.isNotEmpty()) append(" app=$app")
        if (alvo.isNotEmpty()) append(" alvo=\"$alvo\"")
        if (texto.isNotEmpty()) append(" texto=\"${texto.take(40)}\"")
    }

    companion object {
        fun fromJson(o: JSONObject) = PassoSemantico(
            acao = o.optString("acao"),
            alvo = o.optString("alvo"),
            texto = o.optString("texto"),
            app = o.optString("app"),
            motivo = o.optString("motivo")
        )
    }
}

data class HabilidadeAprendida(
    val id: String,
    val nome: String,
    val objetivo: String,
    val objetivoNorm: String,
    val aplicativo: String,
    val passos: List<PassoSemantico>,
    val sucessos: Int = 1,
    val falhas: Int = 0,
    val usos: Int = 0,
    val confianca: Int = 40,
    val origem: String = "Missão concluída",
    val criadoEm: Long = System.currentTimeMillis(),
    val atualizadoEm: Long = System.currentTimeMillis()
) {
    fun estrategiaTexto(): String =
        passos.mapIndexed { i, p -> "${i + 1}. ${p.resumoLinha()}" }.joinToString("\n")

    fun confiancaPct(): Int = confianca.coerceIn(0, 100)

    fun toJson(): JSONObject {
        val arr = JSONArray()
        passos.forEach { arr.put(it.toJson()) }
        return JSONObject()
            .put("id", id)
            .put("nome", nome)
            .put("objetivo", objetivo)
            .put("objetivoNorm", objetivoNorm)
            .put("aplicativo", aplicativo)
            .put("passos", arr)
            .put("sucessos", sucessos)
            .put("falhas", falhas)
            .put("usos", usos)
            .put("confianca", confianca)
            .put("origem", origem)
            .put("criadoEm", criadoEm)
            .put("atualizadoEm", atualizadoEm)
    }

    companion object {
        fun fromJson(o: JSONObject): HabilidadeAprendida {
            val arr = o.optJSONArray("passos") ?: JSONArray()
            val passos = (0 until arr.length()).map { PassoSemantico.fromJson(arr.getJSONObject(it)) }
            val objetivo = o.optString("objetivo")
            return HabilidadeAprendida(
                id = o.optString("id"),
                nome = o.optString("nome").ifEmpty { objetivo.take(48) },
                objetivo = objetivo,
                objetivoNorm = o.optString("objetivoNorm"),
                aplicativo = o.optString("aplicativo"),
                passos = passos,
                sucessos = o.optInt("sucessos", 1),
                falhas = o.optInt("falhas", 0),
                usos = o.optInt("usos", 0),
                confianca = o.optInt("confianca", 40),
                origem = o.optString("origem", "Missão concluída"),
                criadoEm = o.optLong("criadoEm", o.optLong("atualizadoEm")),
                atualizadoEm = o.optLong("atualizadoEm")
            )
        }
    }
}

object MemoriaAprendizado {
    private const val PREFS = "lua_memoria_aprendizado"
    private const val CHAVE = "habilidades_v2"

    fun normalizarObjetivo(s: String): String =
        s.lowercase()
            .replace(Regex("""[“”"']"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()

    fun listar(ctx: Context): List<HabilidadeAprendida> {
        val raw = prefs(ctx).getString(CHAVE, null)
            ?: prefs(ctx).getString("habilidades_v1", "[]")
            ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { HabilidadeAprendida.fromJson(arr.getJSONObject(it)) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun salvarTodas(ctx: Context, lista: List<HabilidadeAprendida>) {
        val arr = JSONArray()
        lista.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString(CHAVE, arr.toString()).apply()
    }

    fun agruparPorApp(ctx: Context): Map<String, List<HabilidadeAprendida>> =
        listar(ctx).groupBy { it.aplicativo.ifEmpty { "GERAL" } }

    /**
     * Aprende/atualiza após missão bem-sucedida.
     * @return texto para o relatório
     */
    fun aprender(
        ctx: Context,
        objetivo: String,
        passos: List<PassoSemantico>,
        aplicativo: String = ""
    ): String {
        if (passos.isEmpty()) return "Aprendizado ignorado (sem passos semânticos)."
        // não gravar se só tem ações claramente inúteis
        val uteis = passos.filter {
            it.acao !in listOf("erro", "dizer", "esperar", "wait")
        }
        if (uteis.isEmpty()) return "Aprendizado ignorado (nenhuma ação útil)."

        val norm = normalizarObjetivo(objetivo)
        val app = aplicativo.ifEmpty {
            uteis.firstOrNull { it.app.isNotEmpty() }?.app.orEmpty()
        }
        val nome = nomeHabilidade(objetivo, app)
        val lista = listar(ctx).toMutableList()
        val idx = lista.indexOfFirst {
            it.objetivoNorm == norm || (it.aplicativo.equals(app, true) && it.nome.equals(nome, true))
        }

        return if (idx >= 0) {
            val antiga = lista[idx]
            val novaConf = (antiga.confianca + 12).coerceAtMost(95)
            lista[idx] = antiga.copy(
                passos = uteis,
                sucessos = antiga.sucessos + 1,
                confianca = novaConf,
                aplicativo = app.ifEmpty { antiga.aplicativo },
                atualizadoEm = System.currentTimeMillis(),
                origem = "Missão concluída (atualizada)"
            )
            salvarTodas(ctx, lista)
            buildString {
                append("Habilidade atualizada: $nome\n")
                append("Confiança: $novaConf%\n")
                append("Estratégia:\n")
                append(uteis.mapIndexed { i, p -> "${i + 1}. ${p.resumoLinha()}" }.joinToString("\n"))
            }
        } else {
            val conf = 45
            val nova = HabilidadeAprendida(
                id = "hab_${System.currentTimeMillis()}",
                nome = nome,
                objetivo = objetivo,
                objetivoNorm = norm,
                aplicativo = app.ifEmpty { "GERAL" },
                passos = uteis,
                sucessos = 1,
                falhas = 0,
                usos = 0,
                confianca = conf,
                origem = "Missão concluída"
            )
            lista.add(0, nova)
            while (lista.size > 50) lista.removeAt(lista.lastIndex)
            salvarTodas(ctx, lista)
            buildString {
                append("Nova habilidade: $nome\n")
                append("Aplicativo: ${nova.aplicativo}\n")
                append("Confiança inicial: $conf%\n")
                append("Origem: Missão concluída\n")
                append("Estratégia registrada:\n")
                append(uteis.mapIndexed { i, p -> "${i + 1}. ${p.resumoLinha()}" }.joinToString("\n"))
            }
        }
    }

    private fun nomeHabilidade(objetivo: String, app: String): String {
        val o = objetivo.trim()
        if (o.length <= 48) return o
        return o.take(45) + "…"
    }

    fun buscarSemelhante(ctx: Context, objetivo: String): HabilidadeAprendida? {
        val norm = normalizarObjetivo(objetivo)
        val lista = listar(ctx)
        lista.firstOrNull { it.objetivoNorm == norm }?.let { return it }
        val palavras = norm.split(" ").filter { it.length > 3 }.toSet()
        if (palavras.isEmpty()) return null
        return lista
            .map { hab ->
                val hp = hab.objetivoNorm.split(" ").filter { it.length > 3 }.toSet()
                hab to palavras.intersect(hp).size
            }
            .filter { it.second >= 2 }
            .maxByOrNull { it.second }
            ?.first
    }

    fun marcarUso(ctx: Context, id: String, sucesso: Boolean) {
        val lista = listar(ctx).toMutableList()
        val i = lista.indexOfFirst { it.id == id }
        if (i < 0) return
        val h = lista[i]
        lista[i] = h.copy(
            usos = h.usos + 1,
            sucessos = h.sucessos + if (sucesso) 1 else 0,
            falhas = h.falhas + if (sucesso) 0 else 1,
            confianca = if (sucesso) (h.confianca + 5).coerceAtMost(99)
            else (h.confianca - 8).coerceAtLeast(10),
            atualizadoEm = System.currentTimeMillis()
        )
        salvarTodas(ctx, lista)
    }

    fun formatarData(ms: Long): String {
        if (ms <= 0) return "—"
        return SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(ms))
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
