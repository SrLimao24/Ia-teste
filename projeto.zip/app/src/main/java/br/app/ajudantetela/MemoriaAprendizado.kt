package br.app.ajudantetela

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Memória local de habilidades semânticas (sem coordenadas).
 * Gemini ensina; a Lua reutiliza quando o objetivo for parecido.
 */
data class PassoSemantico(
    val acao: String,
    val alvo: String = "",
    val texto: String = "",
    val app: String = "",
    val motivo: String = ""
) {
    fun toJson(): JSONObject = JSONObject()
        .put("acao", acao)
        .put("alvo", alvo)
        .put("texto", texto)
        .put("app", app)
        .put("motivo", motivo)

    companion object {
        fun fromJson(o: JSONObject) = PassoSemantico(
            acao = o.optString("acao"),
            alvo = o.optString("alvo"),
            texto = o.optString("texto"),
            app = o.optString("app"),
            motivo = o.optString("motivo")
        )
    }
}

data class HabilidadeAprendida(
    val id: String,
    val objetivo: String,
    val objetivoNorm: String,
    val passos: List<PassoSemantico>,
    val usos: Int = 0,
    val atualizadoEm: Long = System.currentTimeMillis()
) {
    fun toJson(): JSONObject {
        val arr = JSONArray()
        passos.forEach { arr.put(it.toJson()) }
        return JSONObject()
            .put("id", id)
            .put("objetivo", objetivo)
            .put("objetivoNorm", objetivoNorm)
            .put("passos", arr)
            .put("usos", usos)
            .put("atualizadoEm", atualizadoEm)
    }

    companion object {
        fun fromJson(o: JSONObject): HabilidadeAprendida {
            val arr = o.optJSONArray("passos") ?: JSONArray()
            val passos = (0 until arr.length()).map { PassoSemantico.fromJson(arr.getJSONObject(it)) }
            return HabilidadeAprendida(
                id = o.optString("id"),
                objetivo = o.optString("objetivo"),
                objetivoNorm = o.optString("objetivoNorm"),
                passos = passos,
                usos = o.optInt("usos"),
                atualizadoEm = o.optLong("atualizadoEm")
            )
        }
    }
}

object MemoriaAprendizado {
    private const val PREFS = "lua_memoria_aprendizado"
    private const val CHAVE = "habilidades_v1"

    fun normalizarObjetivo(s: String): String =
        s.lowercase()
            .replace(Regex("""[“”"']"""), "")
            .replace(Regex("""\s+"""), " ")
            .trim()

    fun listar(ctx: Context): List<HabilidadeAprendida> {
        val raw = prefs(ctx).getString(CHAVE, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { HabilidadeAprendida.fromJson(arr.getJSONObject(it)) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun salvarTodas(ctx: Context, lista: List<HabilidadeAprendida>) {
        val arr = JSONArray()
        lista.forEach { arr.put(it.toJson()) }
        prefs(ctx).edit().putString(CHAVE, arr.toString()).apply()
    }

    /**
     * Aprende/atualiza a partir de passos bem-sucedidos.
     * @return mensagem de log: aprendida | atualizada | ignorada
     */
    fun aprender(
        ctx: Context,
        objetivo: String,
        passos: List<PassoSemantico>
    ): String {
        if (passos.isEmpty()) return "aprendizado ignorado (sem passos)"
        val norm = normalizarObjetivo(objetivo)
        val lista = listar(ctx).toMutableList()
        val idx = lista.indexOfFirst { it.objetivoNorm == norm }
        return if (idx >= 0) {
            val antiga = lista[idx]
            lista[idx] = antiga.copy(
                passos = passos,
                usos = antiga.usos,
                atualizadoEm = System.currentTimeMillis()
            )
            salvarTodas(ctx, lista)
            "habilidade atualizada: \"${objetivo.take(60)}\" (${passos.size} passos)"
        } else {
            val nova = HabilidadeAprendida(
                id = "hab_${System.currentTimeMillis()}",
                objetivo = objetivo,
                objetivoNorm = norm,
                passos = passos
            )
            lista.add(0, nova)
            // limite simples
            while (lista.size > 40) lista.removeAt(lista.lastIndex)
            salvarTodas(ctx, lista)
            "habilidade aprendida e salva: \"${objetivo.take(60)}\" (${passos.size} passos)"
        }
    }

    /** Busca habilidade com objetivo igual ou contendo as mesmas palavras-chave principais. */
    fun buscarSemelhante(ctx: Context, objetivo: String): HabilidadeAprendida? {
        val norm = normalizarObjetivo(objetivo)
        val lista = listar(ctx)
        lista.firstOrNull { it.objetivoNorm == norm }?.let { return it }
        val palavras = norm.split(" ").filter { it.length > 3 }.toSet()
        if (palavras.isEmpty()) return null
        return lista
            .map { hab ->
                val hp = hab.objetivoNorm.split(" ").filter { it.length > 3 }.toSet()
                val inter = palavras.intersect(hp).size
                hab to inter
            }
            .filter { it.second >= 2 }
            .maxByOrNull { it.second }
            ?.first
    }

    fun marcarUso(ctx: Context, id: String) {
        val lista = listar(ctx).toMutableList()
        val i = lista.indexOfFirst { it.id == id }
        if (i < 0) return
        lista[i] = lista[i].copy(usos = lista[i].usos + 1, atualizadoEm = System.currentTimeMillis())
        salvarTodas(ctx, lista)
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
