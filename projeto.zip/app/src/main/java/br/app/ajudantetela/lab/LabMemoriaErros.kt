package br.app.ajudantetela.lab

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class EstrategiaFalhada(
    val competencia: String,
    val estrategia: String,
    val contexto: String,
    val resultado: String,
    val origem: String,
    val timestamp: Long
)

object LabMemoriaErros {
    private const val PREFS = "lua_lab_v1"
    private const val K = "estrategias_falhadas"

    fun registrar(
        ctx: Context,
        competencia: String,
        estrategia: String,
        contexto: String,
        resultado: String,
        origem: String
    ) {
        val lista = listar(ctx).toMutableList()
        val chave = (competencia + "|" + estrategia).lowercase()
        if (lista.any { (it.competencia + "|" + it.estrategia).lowercase() == chave }) return
        lista.add(
            0,
            EstrategiaFalhada(
                competencia, estrategia.take(120), contexto.take(120),
                resultado, origem, System.currentTimeMillis()
            )
        )
        while (lista.size > 100) lista.removeAt(lista.lastIndex)
        val arr = JSONArray()
        lista.forEach { e ->
            arr.put(JSONObject().apply {
                put("comp", e.competencia)
                put("est", e.estrategia)
                put("ctx", e.contexto)
                put("res", e.resultado)
                put("orig", e.origem)
                put("ts", e.timestamp)
            })
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(K, arr.toString()).apply()
    }

    fun listar(ctx: Context, competencia: String? = null): List<EstrategiaFalhada> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(K, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                EstrategiaFalhada(
                    o.optString("comp"),
                    o.optString("est"),
                    o.optString("ctx"),
                    o.optString("res"),
                    o.optString("orig"),
                    o.optLong("ts")
                )
            }.filter { competencia == null || it.competencia.equals(competencia, true) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun jaFalhou(ctx: Context, competencia: String, estrategia: String): Boolean {
        val e = estrategia.lowercase()
        return listar(ctx, competencia).any {
            it.estrategia.lowercase() == e || it.estrategia.lowercase().contains(e.take(25))
        }
    }
}
