package br.app.ajudantetela.autofix

enum class VerificationEvent {
    SNAPSHOT_BEFORE,
    ACTION_EXECUTED,
    VERIFY_RETRY,
    GOAL_CONFIRMED,
    GOAL_UNKNOWN,
    ACTION_FAILED,
    DUPLICATE_BLOCKED
}

data class VerificationLog(
    val event: VerificationEvent,
    val detail: String,
    val source: String = "deterministic_verifier"
)
