package br.app.ajudantetela

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Google Gemini — generateContent + ListModels.
 * Não fixa um modelo descontinuado: consulta a lista da API e escolhe um compatível.
 */
class GeminiProvedor : ModeloIA {
    override val id = ConfigIA.PROVEDOR_GEMINI
    override val nome = "Gemini (Google)"

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    /** Último modelo escolhido nesta sessão (também salvo em ConfigIA pelo caller). */
    @Volatile
    var modeloSelecionado: String = ""
        private set

    override fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit) {
        if (apiKey.isBlank()) {
            callback(ResultadoTeste(false, "Chave da API vazia.", TipoErroIA.CONFIGURACAO))
            return
        }
        executor.execute {
            try {
                // 1) Listar modelos disponíveis para esta chave
                val lista = listarModelos(apiKey)
                if (lista.isEmpty()) {
                    main.post {
                        callback(
                            ResultadoTeste(
                                false,
                                "Nenhum modelo de texto disponível para esta chave. Verifique a chave ou a conta Google AI.",
                                TipoErroIA.CONFIGURACAO
                            )
                        )
                    }
                    return@execute
                }

                val escolhido = escolherMelhorModelo(lista)
                modeloSelecionado = escolhido

                // 2) Chamada mínima de generateContent
                val teste = generateContent(apiKey, escolhido, "Responda apenas com a palavra: ok")
                main.post {
                    if (teste.ok) {
                        callback(
                            ResultadoTeste(
                                true,
                                "Conectado ✓ · modelo: $escolhido",
                                TipoErroIA.NENHUM
                            )
                        )
                    } else {
                        callback(teste)
                    }
                }
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                val tipo = when {
                    msg.contains("API key", true) || msg.contains("401") || msg.contains("403") ->
                        TipoErroIA.CHAVE_INVALIDA
                    msg.contains("429") -> TipoErroIA.QUOTA
                    msg.contains("ListModels HTTP") -> TipoErroIA.CONFIGURACAO
                    else -> TipoErroIA.REDE
                }
                main.post {
                    callback(
                        ResultadoTeste(
                            false,
                            if (msg.startsWith("ListModels")) "Erro ao listar modelos: $msg"
                            else "Problema de internet ou API: $msg",
                            tipo
                        )
                    )
                }
            }
        }
    }

    override fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    ) {
        executor.execute {
            try {
                var modelo = modeloSelecionado
                if (modelo.isBlank()) {
                    val lista = listarModelos(apiKey)
                    if (lista.isEmpty()) {
                        main.post {
                            callback(
                                ResultadoAcao(
                                    false,
                                    erro = "Nenhum modelo Gemini disponível para esta chave.",
                                    tipo = TipoErroIA.CONFIGURACAO
                                )
                            )
                        }
                        return@execute
                    }
                    modelo = escolherMelhorModelo(lista)
                    modeloSelecionado = modelo
                }

                val prompt = buildString {
                    append("Você é a Lua, assistente que ajuda a controlar um celular Android.\n")
                    append("Comando do usuário: $comando\n")
                    if (contextoTela.isNotBlank()) append("Contexto da tela:\n$contextoTela\n")
                    append("Responda de forma curta e objetiva.")
                }

                val r = generateContent(apiKey, modelo, prompt)
                main.post {
                    if (r.ok) {
                        // extrair texto da última chamada bem-sucedida fica em r.mensagem só no teste;
                        // para pedirAcao precisamos do texto real — generateContent retorna ResultadoTeste.
                        // Refazemos parse abaixo com método dedicado.
                    }
                }
                // Chamada dedicada com texto
                val textoResult = generateContentTexto(apiKey, modelo, prompt)
                main.post { callback(textoResult) }
            } catch (e: Exception) {
                main.post {
                    callback(
                        ResultadoAcao(
                            false,
                            erro = "Rede: ${e.message ?: e.javaClass.simpleName}",
                            tipo = TipoErroIA.REDE
                        )
                    )
                }
            }
        }
    }

    /**
     * GET /v1beta/models — retorna nomes curtos (sem prefixo "models/")
     * que suportam generateContent.
     */
    private fun listarModelos(apiKey: String): List<String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("x-goog-api-key", apiKey)
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

        if (code !in 200..299) {
            // Propaga como exception com corpo real para o caller tratar
            throw RuntimeException("ListModels HTTP $code: ${raw.take(300)}")
        }

        val arr = JSONObject(raw).optJSONArray("models") ?: JSONArray()
        val saida = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val name = m.optString("name") // "models/gemini-xxx"
            val methods = m.optJSONArray("supportedGenerationMethods") ?: JSONArray()
            var gera = false
            for (j in 0 until methods.length()) {
                if (methods.getString(j) == "generateContent") {
                    gera = true
                    break
                }
            }
            if (!gera) continue
            // Ignora embeddings, imagen, etc.
            val curto = name.removePrefix("models/")
            val low = curto.lowercase()
            if (low.contains("embed") || low.contains("imagen") || low.contains("aqa") ||
                low.contains("tts") || low.contains("robotics")
            ) continue
            saida.add(curto)
        }
        return saida
    }

    /**
     * Prefere flash recente, depois pro, depois qualquer gemini com generateContent.
     * Evita nomes explicitamente legados quando há alternativa.
     */
    private fun escolherMelhorModelo(lista: List<String>): String {
        fun score(n: String): Int {
            val s = n.lowercase()
            var p = 0
            if (s.contains("flash")) p += 30
            if (s.contains("pro")) p += 20
            if (s.contains("gemini")) p += 10
            // Preferir versões mais altas numericamente de forma simples
            Regex("""(\d+(?:\.\d+)?)""").findAll(s).forEach { m ->
                p += ((m.groupValues[1].toDoubleOrNull() ?: 0.0) * 10).toInt()
            }
            if (s.contains("exp") || s.contains("preview") || s.contains("thinking")) p -= 5
            if (s.contains("1.5") || s.contains("2.0")) p -= 15 // legados se existirem outros
            return p
        }
        return lista.maxByOrNull { score(it) } ?: lista.first()
    }

    private fun generateContent(apiKey: String, modelo: String, texto: String): ResultadoTeste {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$modelo:generateContent"
        )
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", texto))
                    )
                )
            )

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
        return interpretar(code, raw, modelo)
    }

    private fun generateContentTexto(apiKey: String, modelo: String, texto: String): ResultadoAcao {
        val r = generateContent(apiKey, modelo, texto)
        if (!r.ok) return ResultadoAcao(false, erro = r.mensagem, tipo = r.tipo)

        // Re-fetch não é ideal; parseamos de novo com uma chamada — na prática
        // generateContent já validou. Para obter o texto, refazemos parse da mesma lógica:
        // Simpler: second call is wasteful. Inline parse in generateContent would be better.
        // For now do one more lightweight call is ok for rare pedirAcao; optimize later.
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$modelo:generateContent"
        )
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", texto))
                    )
                )
            )
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
        if (code !in 200..299) {
            val t = interpretar(code, raw, modelo)
            return ResultadoAcao(false, erro = t.mensagem, tipo = t.tipo)
        }
        val out = JSONObject(raw)
            .optJSONArray("candidates")
            ?.optJSONObject(0)
            ?.optJSONObject("content")
            ?.optJSONArray("parts")
            ?.optJSONObject(0)
            ?.optString("text")
            ?.trim()
            .orEmpty()
        return if (out.isEmpty())
            ResultadoAcao(false, erro = "Resposta inesperada da API Gemini: ${raw.take(180)}", tipo = TipoErroIA.RESPOSTA_INESPERADA)
        else
            ResultadoAcao(true, texto = out)
    }

    private fun interpretar(code: Int, raw: String, modelo: String): ResultadoTeste {
        val lower = raw.lowercase()
        // Extrai mensagem de erro da API Google se existir
        val msgApi = try {
            val j = JSONObject(raw)
            j.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
                ?: j.optString("message").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }

        return when {
            code in 200..299 ->
                ResultadoTeste(true, "Conectado ✓ · modelo: $modelo")

            code == 400 || code == 404 -> {
                val detalhe = msgApi ?: raw.take(200)
                val tipo = when {
                    lower.contains("api key") || lower.contains("api_key") ||
                        lower.contains("permission denied") || lower.contains("invalid") && lower.contains("key") ->
                        TipoErroIA.CHAVE_INVALIDA
                    lower.contains("not found") || lower.contains("is not found") ||
                        lower.contains("no longer available") || lower.contains("deprecated") ->
                        TipoErroIA.MODELO_INEXISTENTE
                    else -> TipoErroIA.CONFIGURACAO
                }
                ResultadoTeste(
                    false,
                    when (tipo) {
                        TipoErroIA.CHAVE_INVALIDA -> "Chave inválida: $detalhe"
                        TipoErroIA.MODELO_INEXISTENTE -> "Modelo indisponível ($modelo): $detalhe"
                        else -> "Erro da API (HTTP $code): $detalhe"
                    },
                    tipo
                )
            }

            code == 401 || code == 403 ->
                ResultadoTeste(
                    false,
                    "Chave sem permissão (HTTP $code): ${msgApi ?: raw.take(160)}",
                    TipoErroIA.CHAVE_INVALIDA
                )

            code == 429 ->
                ResultadoTeste(
                    false,
                    "Limite/quota atingido (HTTP 429): ${msgApi ?: "aguarde e tente de novo"}",
                    TipoErroIA.QUOTA
                )

            code >= 500 ->
                ResultadoTeste(
                    false,
                    "Servidor Gemini indisponível (HTTP $code): ${msgApi ?: raw.take(120)}",
                    TipoErroIA.REDE
                )

            else ->
                ResultadoTeste(
                    false,
                    "Falha HTTP $code: ${msgApi ?: raw.take(160)}",
                    TipoErroIA.OUTRO
                )
        }
    }
}
