package br.app.ajudantetela

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Google Gemini — ListModels + generateContent.
 * Prioriza modelos tipicamente disponíveis no Free Tier (flash).
 * Evita deep-research e similares com quota 0 no free tier.
 */
class GeminiProvedor : ModeloIA {
    override val id = ConfigIA.PROVEDOR_GEMINI
    override val nome = "Gemini (Google)"

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    var modeloSelecionado: String = ""
        private set

    /** Lista completa de modelos de texto detectados na última consulta (para a UI). */
    @Volatile
    var modelosDisponiveis: List<String> = emptyList()
        private set

    override fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit) {
        if (apiKey.isBlank()) {
            callback(ResultadoTeste(false, "Chave da API vazia.", TipoErroIA.CONFIGURACAO))
            return
        }
        executor.execute {
            try {
                val lista = listarModelos(apiKey)
                modelosDisponiveis = lista
                if (lista.isEmpty()) {
                    main.post {
                        callback(
                            ResultadoTeste(
                                false,
                                "Nenhum modelo de texto disponível para esta chave.",
                                TipoErroIA.CONFIGURACAO
                            )
                        )
                    }
                    return@execute
                }

                val ordenados = ordenarParaFreeTier(lista)
                // Preferir modelo já salvo se ainda existir e for razoável
                val preferido = modeloSelecionado.takeIf { it in ordenados }

                val candidatos = buildList {
                    if (preferido != null) add(preferido)
                    addAll(ordenados.filter { it != preferido })
                }

                var ultimoErro: ResultadoTeste? = null
                for (modelo in candidatos) {
                    val r = generateContent(apiKey, modelo, "Responda apenas com a palavra: ok")
                    if (r.ok) {
                        modeloSelecionado = modelo
                        main.post {
                            callback(
                                ResultadoTeste(
                                    true,
                                    "Conectado ✓ · modelo: $modelo",
                                    TipoErroIA.NENHUM
                                )
                            )
                        }
                        return@execute
                    }
                    ultimoErro = r
                    // Quota 0 / modelo sem free tier → tenta o próximo
                    if (r.tipo == TipoErroIA.QUOTA && pareceQuotaZero(r.mensagem)) {
                        continue
                    }
                    // Modelo inexistente → próximo
                    if (r.tipo == TipoErroIA.MODELO_INEXISTENTE) {
                        continue
                    }
                    // Chave inválida / rede → para na hora
                    if (r.tipo == TipoErroIA.CHAVE_INVALIDA || r.tipo == TipoErroIA.REDE) {
                        main.post { callback(r) }
                        return@execute
                    }
                    // Outros erros: ainda tenta mais um ou dois flash
                    continue
                }

                main.post {
                    callback(
                        ultimoErro ?: ResultadoTeste(
                            false,
                            "Nenhum modelo testado respondeu. Lista: ${ordenados.take(5).joinToString()}",
                            TipoErroIA.QUOTA
                        )
                    )
                }
            } catch (e: Exception) {
                val msg = e.message ?: e.javaClass.simpleName
                val tipo = when {
                    msg.contains("API key", true) || msg.contains("401") || msg.contains("403") ->
                        TipoErroIA.CHAVE_INVALIDA
                    msg.contains("429") -> TipoErroIA.QUOTA
                    msg.contains("ListModels HTTP") -> TipoErroIA.CONFIGURACAO
                    else -> TipoErroIA.REDE
                }
                main.post {
                    callback(
                        ResultadoTeste(
                            false,
                            if (msg.startsWith("ListModels")) "Erro ao listar modelos: $msg"
                            else "Problema de internet ou API: $msg",
                            tipo
                        )
                    )
                }
            }
        }
    }

    /** Força um modelo específico (vindo da UI) e testa só ele. */
    fun testarModelo(apiKey: String, modelo: String, callback: (ResultadoTeste) -> Unit) {
        if (apiKey.isBlank()) {
            callback(ResultadoTeste(false, "Chave da API vazia.", TipoErroIA.CONFIGURACAO))
            return
        }
        if (modelo.isBlank()) {
            callback(ResultadoTeste(false, "Nenhum modelo selecionado.", TipoErroIA.CONFIGURACAO))
            return
        }
        executor.execute {
            try {
                val r = generateContent(apiKey, modelo, "Responda apenas com a palavra: ok")
                if (r.ok) modeloSelecionado = modelo
                main.post { callback(r) }
            } catch (e: Exception) {
                main.post {
                    callback(
                        ResultadoTeste(
                            false,
                            "Rede: ${e.message ?: e.javaClass.simpleName}",
                            TipoErroIA.REDE
                        )
                    )
                }
            }
        }
    }

    fun atualizarListaModelos(apiKey: String, callback: (List<String>, String?) -> Unit) {
        executor.execute {
            try {
                val lista = ordenarParaFreeTier(listarModelos(apiKey))
                modelosDisponiveis = lista
                main.post { callback(lista, null) }
            } catch (e: Exception) {
                main.post { callback(emptyList(), e.message) }
            }
        }
    }

    override fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    ) {
        executor.execute {
            try {
                var modelo = modeloSelecionado
                if (modelo.isBlank()) {
                    val lista = ordenarParaFreeTier(listarModelos(apiKey))
                    modelosDisponiveis = lista
                    if (lista.isEmpty()) {
                        main.post {
                            callback(
                                ResultadoAcao(
                                    false,
                                    erro = "Nenhum modelo Gemini disponível.",
                                    tipo = TipoErroIA.CONFIGURACAO
                                )
                            )
                        }
                        return@execute
                    }
                    // Tenta até achar um que não seja quota 0
                    for (m in lista) {
                        val t = generateContent(apiKey, m, "ok")
                        if (t.ok) {
                            modelo = m
                            modeloSelecionado = m
                            break
                        }
                        if (t.tipo == TipoErroIA.CHAVE_INVALIDA) {
                            main.post { callback(ResultadoAcao(false, erro = t.mensagem, tipo = t.tipo)) }
                            return@execute
                        }
                    }
                    if (modelo.isBlank()) {
                        main.post {
                            callback(
                                ResultadoAcao(
                                    false,
                                    erro = "Todos os modelos testados estão sem cota no Free Tier.",
                                    tipo = TipoErroIA.QUOTA
                                )
                            )
                        }
                        return@execute
                    }
                }

                val prompt = buildString {
                    append("Você é a Lua, assistente que controla um celular Android.\n")
                    append("Responda APENAS com um JSON válido, sem markdown e sem texto extra.\n")
                    append("Use um destes formatos:\n")
                    append("{\"acao\":\"abrir_app\",\"app\":\"WhatsApp\",\"pacote\":\"com.whatsapp\"}\n")
                    append("{\"acao\":\"digitar\",\"texto\":\"Minecraft\",\"alvo\":\"0\"}\n")
                    append("{\"acao\":\"dizer\",\"texto\":\"mensagem\"}\n")
                    append("{\"acao\":\"erro\",\"motivo\":\"motivo\"}\n")
                    append("Se pedir para abrir app, use abrir_app.\n")
                    append("Se pedir para escrever/digitar texto, use digitar. Opcional: alvo = id do campo da lista.\n")
                    append("NÃO invente coordenadas. Use só os campos listados no contexto.\n")
                    append("Comando do usuário: $comando\n")
                    if (contextoTela.isNotBlank()) append("Contexto: $contextoTela\n")
                }

                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$modelo:generateContent"
                )
                val body = JSONObject()
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", prompt))
                            )
                        )
                    )
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", apiKey)
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
                if (code !in 200..299) {
                    val t = interpretar(code, raw, modelo)
                    main.post { callback(ResultadoAcao(false, erro = t.mensagem, tipo = t.tipo)) }
                    return@execute
                }
                val out = JSONObject(raw)
                    .optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?.trim()
                    .orEmpty()
                main.post {
                    if (out.isEmpty())
                        callback(
                            ResultadoAcao(
                                false,
                                erro = "Resposta inesperada: ${raw.take(180)}",
                                tipo = TipoErroIA.RESPOSTA_INESPERADA
                            )
                        )
                    else
                        callback(ResultadoAcao(true, texto = out))
                }
            } catch (e: Exception) {
                main.post {
                    callback(
                        ResultadoAcao(
                            false,
                            erro = "Rede: ${e.message ?: e.javaClass.simpleName}",
                            tipo = TipoErroIA.REDE
                        )
                    )
                }
            }
        }
    }

    fun definirModelo(modelo: String) {
        modeloSelecionado = modelo
    }

    private fun listarModelos(apiKey: String): List<String> {
        val url = URL("https://generativelanguage.googleapis.com/v1beta/models")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 15000
            readTimeout = 20000
            setRequestProperty("x-goog-api-key", apiKey)
        }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

        if (code !in 200..299) {
            throw RuntimeException("ListModels HTTP $code: ${raw.take(300)}")
        }

        val arr = JSONObject(raw).optJSONArray("models") ?: JSONArray()
        val saida = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val m = arr.getJSONObject(i)
            val name = m.optString("name")
            val methods = m.optJSONArray("supportedGenerationMethods") ?: JSONArray()
            var gera = false
            for (j in 0 until methods.length()) {
                if (methods.getString(j) == "generateContent") {
                    gera = true
                    break
                }
            }
            if (!gera) continue
            val curto = name.removePrefix("models/")
            if (deveIgnorar(curto)) continue
            saida.add(curto)
        }
        return saida
    }

    /** Modelos que não servem para o Free Tier / chat da Lua. */
    private fun deveIgnorar(nome: String): Boolean {
        val s = nome.lowercase()
        return s.contains("embed") ||
            s.contains("imagen") ||
            s.contains("aqa") ||
            s.contains("tts") ||
            s.contains("robotics") ||
            s.contains("deep-research") ||
            s.contains("deep_research") ||
            s.contains("computer-use") ||
            s.contains("lyria") ||
            s.contains("veo") ||
            s.contains("gemini-1.0")
    }

    /**
     * Ordem: flash estáveis primeiro (Free Tier), depois flash preview,
     * depois pro leves, por último o resto.
     */
    private fun ordenarParaFreeTier(lista: List<String>): List<String> {
        fun score(n: String): Int {
            val s = n.lowercase()
            var p = 0
            if (s.contains("flash")) p += 100
            if (s.contains("flash-lite") || s.contains("flash_lite")) p += 20
            if (s.contains("gemini")) p += 10
            if (s.contains("pro") && !s.contains("flash")) p += 5
            // Preferir números de versão mais altos em flash
            Regex("""(\d+(?:\.\d+)?)""").findAll(s).forEach { m ->
                val v = m.groupValues[1].toDoubleOrNull() ?: 0.0
                if (s.contains("flash")) p += (v * 8).toInt()
                else p += (v * 2).toInt()
            }
            if (s.contains("latest")) p += 15
            if (s.contains("exp") || s.contains("preview")) p -= 8
            if (s.contains("thinking")) p -= 10
            // Penalizar legados conhecidos
            if (s.contains("1.5")) p -= 5
            if (s.contains("2.0-flash") || s == "gemini-2.0-flash") p -= 20
            return p
        }
        return lista.sortedByDescending { score(it) }
    }

    private fun pareceQuotaZero(msg: String): Boolean {
        val m = msg.lowercase()
        return m.contains("limit: 0") ||
            m.contains("limit\": 0") ||
            m.contains("free tier") ||
            m.contains("quota exceeded")
    }

    private fun generateContent(apiKey: String, modelo: String, texto: String): ResultadoTeste {
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$modelo:generateContent"
        )
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray().put(JSONObject().put("text", texto))
                    )
                )
            )

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("x-goog-api-key", apiKey)
        }
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
        return interpretar(code, raw, modelo)
    }

    private fun interpretar(code: Int, raw: String, modelo: String): ResultadoTeste {
        val lower = raw.lowercase()
        val msgApi = try {
            val j = JSONObject(raw)
            j.optJSONObject("error")?.optString("message")?.takeIf { it.isNotBlank() }
                ?: j.optString("message").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }

        return when {
            code in 200..299 ->
                ResultadoTeste(true, "Conectado ✓ · modelo: $modelo")

            code == 429 ->
                ResultadoTeste(
                    false,
                    "Limite/quota atingido (HTTP 429) em $modelo: ${msgApi ?: raw.take(220)}",
                    TipoErroIA.QUOTA
                )

            code == 400 || code == 404 -> {
                val detalhe = msgApi ?: raw.take(200)
                val tipo = when {
                    lower.contains("api key") || lower.contains("api_key") ||
                        (lower.contains("invalid") && lower.contains("key")) ->
                        TipoErroIA.CHAVE_INVALIDA
                    lower.contains("not found") || lower.contains("no longer available") ||
                        lower.contains("deprecated") ->
                        TipoErroIA.MODELO_INEXISTENTE
                    else -> TipoErroIA.CONFIGURACAO
                }
                ResultadoTeste(
                    false,
                    when (tipo) {
                        TipoErroIA.CHAVE_INVALIDA -> "Chave inválida: $detalhe"
                        TipoErroIA.MODELO_INEXISTENTE -> "Modelo indisponível ($modelo): $detalhe"
                        else -> "Erro da API (HTTP $code) em $modelo: $detalhe"
                    },
                    tipo
                )
            }

            code == 401 || code == 403 ->
                ResultadoTeste(
                    false,
                    "Chave sem permissão (HTTP $code): ${msgApi ?: raw.take(160)}",
                    TipoErroIA.CHAVE_INVALIDA
                )

            code >= 500 ->
                ResultadoTeste(
                    false,
                    "Servidor Gemini indisponível (HTTP $code): ${msgApi ?: raw.take(120)}",
                    TipoErroIA.REDE
                )

            else ->
                ResultadoTeste(
                    false,
                    "Falha HTTP $code em $modelo: ${msgApi ?: raw.take(160)}",
                    TipoErroIA.OUTRO
                )
        }
    }
}
