package br.app.ajudantetela

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Google Gemini — generateContent API.
 * Auth: header x-goog-api-key (NÃO Bearer).
 * URL: generativelanguage.googleapis.com/v1beta/models/{model}:generateContent
 */
class GeminiProvedor : ModeloIA {
    override val id = ConfigIA.PROVEDOR_GEMINI
    override val nome = "Gemini (Google)"

    // Modelo estável e amplamente disponível; pode ajustar depois nas configs
    private val modelo = "gemini-2.0-flash"

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit) {
        if (apiKey.isBlank()) {
            callback(ResultadoTeste(false, "Chave da API vazia.", TipoErroIA.CONFIGURACAO))
            return
        }
        executor.execute {
            try {
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$modelo:generateContent"
                )
                val body = JSONObject()
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", "Responda apenas com a palavra: ok"))
                            )
                        )
                    )

                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 25000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", apiKey)
                    // Gemini NÃO usa Authorization: Bearer
                }

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

                val resultado = interpretarResposta(code, raw)
                main.post { callback(resultado) }
            } catch (e: Exception) {
                main.post {
                    callback(
                        ResultadoTeste(
                            false,
                            "Problema de internet ou rede: ${e.message ?: e.javaClass.simpleName}",
                            TipoErroIA.REDE
                        )
                    )
                }
            }
        }
    }

    override fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    ) {
        executor.execute {
            try {
                val prompt = buildString {
                    append("Você é a Lua, assistente que ajuda a controlar um celular Android.\n")
                    append("Comando do usuário: $comando\n")
                    if (contextoTela.isNotBlank()) append("Contexto da tela:\n$contextoTela\n")
                    append("Responda de forma curta e objetiva.")
                }
                val url = URL(
                    "https://generativelanguage.googleapis.com/v1beta/models/$modelo:generateContent"
                )
                val body = JSONObject()
                    .put(
                        "contents",
                        JSONArray().put(
                            JSONObject().put(
                                "parts",
                                JSONArray().put(JSONObject().put("text", prompt))
                            )
                        )
                    )

                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("x-goog-api-key", apiKey)
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

                if (code !in 200..299) {
                    val t = interpretarResposta(code, raw)
                    main.post { callback(ResultadoAcao(false, erro = t.mensagem, tipo = t.tipo)) }
                    return@execute
                }
                val json = JSONObject(raw)
                val texto = json.optJSONArray("candidates")
                    ?.optJSONObject(0)
                    ?.optJSONObject("content")
                    ?.optJSONArray("parts")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?.trim()
                    .orEmpty()
                if (texto.isEmpty()) {
                    main.post {
                        callback(
                            ResultadoAcao(
                                false,
                                erro = "Resposta inesperada da API Gemini.",
                                tipo = TipoErroIA.RESPOSTA_INESPERADA
                            )
                        )
                    }
                } else {
                    main.post { callback(ResultadoAcao(true, texto = texto)) }
                }
            } catch (e: Exception) {
                main.post {
                    callback(
                        ResultadoAcao(
                            false,
                            erro = "Rede: ${e.message ?: e.javaClass.simpleName}",
                            tipo = TipoErroIA.REDE
                        )
                    )
                }
            }
        }
    }

    private fun interpretarResposta(code: Int, raw: String): ResultadoTeste {
        val lower = raw.lowercase()
        return when {
            code in 200..299 -> ResultadoTeste(true, "Conectado ✓ (Gemini / HTTP $code)")
            code == 400 && (lower.contains("api key") || lower.contains("api_key") ||
                lower.contains("invalid") || lower.contains("permission")) ->
                ResultadoTeste(false, "Chave inválida ou mal formatada (Gemini).", TipoErroIA.CHAVE_INVALIDA)
            code == 400 && (lower.contains("model") || lower.contains("not found")) ->
                ResultadoTeste(false, "Modelo inexistente ou indisponível ($modelo).", TipoErroIA.MODELO_INEXISTENTE)
            code == 400 ->
                ResultadoTeste(false, "Erro de configuração/argumento (HTTP 400): ${raw.take(140)}", TipoErroIA.CONFIGURACAO)
            code == 401 || code == 403 ->
                ResultadoTeste(false, "Chave sem permissão ou inválida (HTTP $code).", TipoErroIA.CHAVE_INVALIDA)
            code == 404 ->
                ResultadoTeste(false, "Modelo não encontrado ($modelo).", TipoErroIA.MODELO_INEXISTENTE)
            code == 429 ->
                ResultadoTeste(false, "Limite/quota atingido (HTTP 429). Aguarde e tente de novo.", TipoErroIA.QUOTA)
            code >= 500 ->
                ResultadoTeste(false, "Servidor Gemini indisponível (HTTP $code).", TipoErroIA.REDE)
            else ->
                ResultadoTeste(false, "Falha HTTP $code: ${raw.take(140)}", TipoErroIA.OUTRO)
        }
    }
}
