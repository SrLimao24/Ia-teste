package br.app.ajudantetela

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import br.app.ajudantetela.lab.LabConfig
import br.app.ajudantetela.lab.LabMotor
import br.app.ajudantetela.lab.LabRepositorio
import br.app.ajudantetela.lab.LabValidador
import br.app.ajudantetela.lab.StatusCompetencia
import br.app.ajudantetela.lab.StatusSessaoLab

/**
 * Interface amigavel do Lab. Logica operacional da Lua permanece intocada.
 */
class LabActivity : Activity() {

    private lateinit var corpo: LinearLayout
    private lateinit var statusLab: TextView
    private lateinit var progressoLab: TextView
    private lateinit var campoObjetivo: EditText
    private lateinit var statusNet: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0614")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0614"))
            setPadding(dp(16), dp(20), dp(16), dp(12))
        }

        root.addView(titulo("Lab da Lua", 24))
        root.addView(
            texto(
                "Aqui o laboratorio pesquisa e testa ideias para ENSINAR a Lua.\n" +
                    "A Lua continua sendo quem executa tarefas no celular.\n" +
                    "Nada aprendido aqui e aplicado a Lua sem a sua autorizacao."
            )
        )

        // Internet gate
        root.addView(secao("Acesso a internet do Lab"))
        root.addView(
            texto(
                "Por padrao a internet do Lab fica BLOQUEADA.\n" +
                    "Isso e so para o pesquisador do Lab — nao controla a Lua nem a chave da IA de missoes."
            )
        )
        statusNet = TextView(this).apply {
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(8))
        }
        root.addView(statusNet)
        atualizarStatusNet()
        root.addView(botao("Permitir ou bloquear pesquisa na Web") {
            val novo = !LabConfig.internetPermitida(this)
            if (novo) {
                AlertDialog.Builder(this)
                    .setTitle("Autorizar internet do Lab?")
                    .setMessage(
                        "O Lab podera pesquisar na Web para este treinamento.\n\n" +
                            "Isso NAO altera a Lua operacional.\n" +
                            "Voce pode bloquear de novo a qualquer momento."
                    )
                    .setPositiveButton("Permitir") { _, _ ->
                        LabConfig.setInternetPermitida(this, true)
                        atualizarStatusNet()
                        toast("Internet do Lab autorizada")
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            } else {
                LabConfig.setInternetPermitida(this, false)
                atualizarStatusNet()
                toast("Internet do Lab bloqueada")
            }
        })

        root.addView(secao("Pesquisa com API (opcional)"))
        root.addView(
            texto(
                "Se quiser, use uma API de pesquisa (ex.: Tavily).\n" +
                    "Sem chave, o Lab tenta pesquisa Web publica quando a internet estiver liberada.\n" +
                    "A chave fica so neste aparelho — nao vai no codigo do projeto."
            )
        )
        val campoKey = EditText(this).apply {
            hint = "Cole aqui a chave de pesquisa (opcional)"
            setText(LabConfig.searchApiKey(this@LabActivity))
            setTextColor(Color.parseColor("#E9D5FF"))
            setHintTextColor(Color.parseColor("#7A6B8F"))
            setBackgroundColor(Color.parseColor("#160E28"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(campoKey, lp(6))
        root.addView(botao("Salvar chave de pesquisa") {
            LabConfig.setSearchApiKey(this, campoKey.text.toString())
            if (LabConfig.temSearchKey(this)) {
                LabConfig.setSearchProvider(this, "tavily")
                toast("Chave salva. Provedor: API de pesquisa")
            } else {
                LabConfig.setSearchProvider(this, "webview")
                toast("Sem chave. Provedor: Web")
            }
        })

        root.addView(secao("O que voce quer ensinar a Lua?"))
        root.addView(
            texto("Escreva em linguagem normal. Exemplo: Ensine a Lua a mandar mensagens no WhatsApp")
        )
        campoObjetivo = EditText(this).apply {
            setText("Ensine a Lua a mandar mensagens no WhatsApp")
            setTextColor(Color.parseColor("#E9D5FF"))
            setHintTextColor(Color.parseColor("#7A6B8F"))
            setBackgroundColor(Color.parseColor("#160E28"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minLines = 2
        }
        root.addView(campoObjetivo, lp(6))

        statusLab = TextView(this).apply {
            text = "Laboratorio parado"
            textSize = 15f
            setTextColor(Color.parseColor("#C4B5FD"))
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        }
        progressoLab = TextView(this).apply {
            text = "Nenhum treinamento em andamento"
            textSize = 12f
            setTextColor(Color.parseColor("#9B8AB8"))
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(statusLab)
        root.addView(progressoLab)

        root.addView(botao("Comecar treinamento") {
            if (!LabConfig.internetPermitida(this)) {
                toast("Libere a internet do Lab para pesquisar (ou o treino usara so relatorios locais + simulador)")
            }
            val obj = campoObjetivo.text.toString().ifBlank {
                "Ensine a Lua a mandar mensagens no WhatsApp"
            }
            statusLab.text = "Iniciando..."
            LabMotor.iniciarSessao(
                this,
                obj,
                onProgresso = { p ->
                    statusLab.text = statusAmigavel(p.sessao.status, p.mensagemAmigavel)
                    progressoLab.text = "Etapa ${p.etapa} de cerca de ${p.etapaTotalEstimado}\n${p.mensagemAmigavel}"
                },
                onFim = { s ->
                    statusLab.text = "Treinamento desta rodada concluido"
                    progressoLab.text =
                        "Pesquisas: ${s.pesquisas} | Ideias: ${s.hipoteses} | Testes: ${s.experimentos}\n" +
                            "Nada foi enviado automaticamente para a Lua. Veja o resumo abaixo."
                    toast("Pronto — revise e valide se quiser")
                    render()
                }
            )
        })

        val scroll = ScrollView(this)
        corpo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(corpo)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::statusNet.isInitialized) atualizarStatusNet()
        if (::corpo.isInitialized) render()
    }

    private fun atualizarStatusNet() {
        if (LabConfig.internetPermitida(this)) {
            statusNet.text = "Internet do Lab: AUTORIZADA"
            statusNet.setTextColor(Color.parseColor("#6EE7B7"))
        } else {
            statusNet.text = "Internet do Lab: BLOQUEADA"
            statusNet.setTextColor(Color.parseColor("#FCA5A5"))
        }
    }

    private fun statusAmigavel(st: StatusSessaoLab, msg: String): String {
        val prefix = when (st) {
            StatusSessaoLab.CRIADA -> "Preparando"
            StatusSessaoLab.PESQUISANDO -> "Pesquisando"
            StatusSessaoLab.ANALISANDO -> "Analisando"
            StatusSessaoLab.EXPERIMENTANDO -> "Experimentando"
            StatusSessaoLab.VALIDANDO -> "Preparando conhecimento"
            StatusSessaoLab.CONCLUIDA -> "Concluido"
            StatusSessaoLab.PAUSADA -> "Pausado"
            StatusSessaoLab.FALHA -> "Interrompido"
        }
        return "$prefix — $msg"
    }

    private fun render() {
        corpo.removeAllViews()
        val rels = LabRepositorio.listarRelatorios(this)
        val comps = LabRepositorio.listarCompetencias(this)
        val sessoes = LabRepositorio.listarSessoes(this)
        val hip = LabRepositorio.listarHipoteses(this)
        val exps = LabRepositorio.listarExperimentos(this)
        val conhec = LabRepositorio.listarConhecimentosParaLua(this)
        val regs = LabRepositorio.listarRegistros(this)

        corpo.addView(secao("O que o Lab ja sabe sobre as missoes da Lua"))
        corpo.addView(
            texto(
                "Relatorios recebidos da Lua: ${rels.size}\n" +
                    "Esses relatos sao evidencias reais (sucesso e falha), nao so teoria."
            )
        )
        rels.take(4).forEach { r ->
            corpo.addView(
                card(
                    (if (r.sucesso) "Deu certo" else "Falhou ou parou") + "\n" + r.objetivo.take(70)
                )
            )
        }

        corpo.addView(secao("Ultimos treinamentos"))
        if (sessoes.isEmpty()) {
            corpo.addView(texto("Nenhum ainda. Escreva um objetivo e toque em Comecar treinamento."))
        }
        sessoes.take(4).forEach { s ->
            corpo.addView(
                card(
                    s.competenciaNome + "\n" +
                        "Pesquisas ${s.pesquisas} · Ideias ${s.hipoteses} · Testes ${s.experimentos}\n" +
                        s.log.takeLast(3).joinToString("\n")
                )
            )
        }

        corpo.addView(secao("Ideias em estudo (ainda nao sao verdade oficial)"))
        if (hip.isEmpty()) corpo.addView(texto("Nenhuma ideia registrada nesta fase."))
        hip.take(5).forEach { h -> corpo.addView(card(h.texto)) }

        corpo.addView(secao("Testes no ambiente de experimento"))
        corpo.addView(
            texto("Aqui o Lab tenta ver se uma ideia funciona de forma controlada, antes de confiar nela.")
        )
        exps.take(5).forEach { e ->
            corpo.addView(
                card(
                    (if (e.sucesso) "Teste ok" else "Teste falhou") + " — " + e.descricao + "\n" +
                        e.resultado.take(120)
                )
            )
        }

        corpo.addView(secao("Conhecimento pronto (so apos a sua autorizacao)"))
        corpo.addView(
            texto(
                "Quando voce validar, o Lab guarda uma estrategia estruturada para a Lua usar no futuro.\n" +
                    "Ainda NAO ligamos isso automaticamente na Lua operacional."
            )
        )
        comps.take(6).forEach { c ->
            val pronto = LabValidador.avaliarProntidao(this, c)
            corpo.addView(
                card(
                    c.nome + "\nEstado: " + c.status +
                        "\nPode validar? " + (if (pronto.ok) "Sim, revise e confirme" else "Ainda fraco") +
                        "\n" + pronto.motivos.take(3).joinToString("\n")
                )
            )
            if (c.status != StatusCompetencia.VALIDADA) {
                corpo.addView(botao("Autorizar conhecimento: " + c.nome.take(24)) {
                    LabValidador.gerarConhecimentoEstruturado(this, c)
                    toast("Conhecimento guardado para ponte futura com a Lua")
                    render()
                })
            }
        }
        if (conhec.isNotEmpty()) {
            corpo.addView(secao("Ja autorizado (aguardando ponte com a Lua)"))
            conhec.forEach { k ->
                corpo.addView(card(k.competencia + "\n" + k.estrategias.joinToString(" → ")))
            }
        }

        corpo.addView(secao("Diario recente do Lab"))
        regs.take(8).forEach { r ->
            corpo.addView(card(r.titulo + "\n" + r.corpo.take(160)))
        }
    }

    private fun titulo(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor("#E9D5FF"))
        typeface = Typeface.DEFAULT_BOLD
    }

    private fun secao(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.parseColor("#A78BFA"))
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(14), 0, dp(6))
    }

    private fun texto(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.parseColor("#C4B5FD"))
        setPadding(0, 0, 0, dp(8))
    }

    private fun card(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.parseColor("#E9D5FF"))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#160E28"))
            setStroke(dp(1), Color.parseColor("#3D2A5C"))
        }
        layoutParams = lp(8)
    }

    private fun botao(t: String, a: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#6D28D9"))
        }
        setOnClickListener { a() }
        layoutParams = lp(8)
    }

    private fun lp(b: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).also { it.bottomMargin = dp(b) }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
