package br.app.ajudantetela

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import br.app.ajudantetela.lab.LabAnalista
import br.app.ajudantetela.lab.LabRepositorio
import br.app.ajudantetela.lab.LabSimulador
import br.app.ajudantetela.lab.StatusCompetencia

/**
 * Interface do Lua Lab — isolada da missao operacional.
 */
class LabActivity : Activity() {

    private lateinit var corpo: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0614")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0614"))
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }

        root.addView(TextView(this).apply {
            text = "Lua Lab"
            textSize = 24f
            setTextColor(Color.parseColor("#E9D5FF"))
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Laboratorio de aprendizagem — nao e a Lua operacional"
            textSize = 12f
            setTextColor(Color.parseColor("#9B8AB8"))
            setPadding(0, dp(4), 0, dp(16))
        })

        val scroll = ScrollView(this)
        corpo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(corpo)
        root.addView(scroll, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.MATCH_PARENT
        ))
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::corpo.isInitialized) render()
    }

    private fun render() {
        corpo.removeAllViews()
        val rels = LabRepositorio.listarRelatorios(this)
        val comps = LabRepositorio.listarCompetencias(this)
        val regs = LabRepositorio.listarRegistros(this)
        val conhec = LabRepositorio.listarConhecimentosParaLua(this)

        corpo.addView(secao("Resumo"))
        corpo.addView(txt(
            "Relatorios: ${rels.size}\nCompetencias: ${comps.size}\nRegistros: ${regs.size}\n" +
                "Conhecimentos prontos para Lua: ${conhec.size}"
        ))

        corpo.addView(secao("Competencias"))
        if (comps.isEmpty()) {
            corpo.addView(txt("Nenhuma ainda. Execute missoes na Lua — os relatorios alimentam o Lab."))
        } else {
            comps.take(12).forEach { c ->
                corpo.addView(txt(
                    "${c.nome}\nstatus=${c.status} | relatorios=${c.relatorioIds.size} | " +
                        "exps=${c.experimentos}\n${c.conhecimentoResumo.take(120)}"
                ))
                corpo.addView(botao("Analisar ultimo relatorio (local + IA hipotese)") {
                    val rel = rels.firstOrNull { it.id in c.relatorioIds } ?: rels.firstOrNull()
                    if (rel == null) {
                        toast("Sem relatorio")
                        return@botao
                    }
                    val local = LabAnalista.analisarRelatorioLocal(rel)
                    LabRepositorio.adicionarRegistro(
                        this,
                        br.app.ajudantetela.lab.RegistroLab(
                            id = "loc_${System.currentTimeMillis()}",
                            tipo = br.app.ajudantetela.lab.TipoRegistroLab.HIPOTESE,
                            competenciaId = c.id,
                            titulo = "Analise local",
                            corpo = local,
                            confianca = 30,
                            timestamp = System.currentTimeMillis(),
                            origemRelatorioIds = listOf(rel.id)
                        )
                    )
                    toast("Analise local salva")
                    LabAnalista.pedirHipoteseIa(this, rel) { r ->
                        runOnUiThread {
                            toast(if (r.ok) "Hipotese IA registrada" else "IA: ${r.texto.take(80)}")
                            render()
                        }
                    }
                    render()
                })
                corpo.addView(botao("Experimento simulador WhatsApp") {
                    val traj = listOf(
                        LabSimulador.aplicarAcao(LabSimulador.EstadoSim.TELA_INICIAL, "abrir_app", "WhatsApp"),
                        LabSimulador.aplicarAcao(LabSimulador.EstadoSim.PESQUISA, "digitar", "Bela"),
                        LabSimulador.aplicarAcao(LabSimulador.EstadoSim.RESULTADOS, "clicar", "Bela"),
                        LabSimulador.aplicarAcao(LabSimulador.EstadoSim.PERFIL, "clicar", "mensagem"),
                        LabSimulador.aplicarAcao(LabSimulador.EstadoSim.CONVERSA, "digitar", "TESTE"),
                        LabSimulador.aplicarAcao(LabSimulador.EstadoSim.MENSAGEM_DIGITADA, "clicar", "Enviar")
                    )
                    // reconstruir traj com estados encadeados
                    var est = LabSimulador.EstadoSim.TELA_INICIAL
                    val passos = mutableListOf<LabSimulador.PassoSim>()
                    val script = listOf(
                        "abrir_app" to "WhatsApp",
                        "digitar" to "Bela",
                        "clicar" to "Bela",
                        "clicar" to "mensagem",
                        "digitar" to "TESTE",
                        "clicar" to "Enviar"
                    )
                    for ((ac, al) in script) {
                        val p = LabSimulador.aplicarAcao(est, ac, al)
                        passos.add(p)
                        if (p.para != null) est = p.para
                    }
                    val resumo = LabSimulador.avaliarTrajetoria(passos)
                    val ok = passos.any { it.para == LabSimulador.EstadoSim.MENSAGEM_ENVIADA }
                    LabAnalista.registrarDescobertaAposSim(this, c.id, resumo, ok)
                    LabRepositorio.atualizarCompetencia(
                        this,
                        c.copy(
                            experimentos = c.experimentos + 1,
                            status = StatusCompetencia.EM_EXPERIMENTO,
                            atualizadoEm = System.currentTimeMillis()
                        )
                    )
                    toast(if (ok) "Sim OK — descoberta registrada" else "Sim falhou")
                    render()
                })
                if (c.status != StatusCompetencia.VALIDADA) {
                    corpo.addView(botao("Validar conhecimento (manual)") {
                        LabAnalista.validarConhecimento(
                            this,
                            c,
                            estrategias = listOf(
                                "Abrir WhatsApp",
                                "Pesquisar contato pelo nome",
                                "Clicar item/ancestral clicavel (nao layout generico)",
                                "Abrir conversa",
                                "Digitar mensagem",
                                "Clicar Enviar e verificar campo vazio / evidencia de envio"
                            ),
                            evidencias = listOf(
                                "Conversa do destinatario",
                                "Campo de mensagem",
                                "Apos enviar: campo vazio ou bolha enviada"
                            ),
                            falhas = listOf(
                                "Clicar so no TextView do nome",
                                "Usar ViewGroup/RelativeLayout como alvo",
                                "Concluir sem evidencia de envio"
                            )
                        )
                        toast("Conhecimento validado para entrega futura a Lua")
                        render()
                    })
                }
            }
        }

        corpo.addView(secao("Ultimos relatorios"))
        rels.take(8).forEach { r ->
            corpo.addView(txt(
                "${if (r.sucesso) "OK" else "FALHA"} | ${r.competenciaSugerida}\n" +
                    r.objetivo.take(80) + "\n" + r.textoCompleto.take(200).replace("\n", " ")
            ))
        }

        corpo.addView(secao("Registros (experiencia / hipotese / descoberta / validado)"))
        regs.take(15).forEach { r ->
            corpo.addView(txt("[${r.tipo}] ${r.titulo} (conf ${r.confianca})\n${r.corpo.take(180)}"))
        }

        corpo.addView(secao("Conhecimento pronto para a Lua"))
        if (conhec.isEmpty()) corpo.addView(txt("Nenhum validado ainda."))
        else conhec.forEach { k ->
            corpo.addView(txt(
                "${k.competencia} (conf ${k.confianca})\n" +
                    k.estrategias.joinToString(" → ")
            ))
        }
    }

    private fun secao(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.parseColor("#A78BFA"))
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(16), 0, dp(8))
    }

    private fun txt(t: String) = TextView(this).apply {
        text = t.replace("\n", "
")
        textSize = 12f
        setTextColor(Color.parseColor("#D4C4F0"))
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.parseColor("#160E28"))
            setStroke(dp(1), Color.parseColor("#3D2A5C"))
        }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(8)
        layoutParams = lp
    }

    private fun botao(t: String, a: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#6D28D9"))
        }
        setOnClickListener { a() }
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        lp.bottomMargin = dp(8)
        layoutParams = lp
    }

    private fun toast(m: String) =
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
