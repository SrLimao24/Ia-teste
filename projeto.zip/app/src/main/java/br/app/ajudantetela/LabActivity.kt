package br.app.ajudantetela

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import br.app.ajudantetela.lab.LabAnalista
import br.app.ajudantetela.lab.LabConfig
import br.app.ajudantetela.lab.LabMotor
import br.app.ajudantetela.lab.LabRepositorio
import br.app.ajudantetela.lab.LabValidador
import br.app.ajudantetela.lab.RegistroLab
import br.app.ajudantetela.lab.StatusCompetencia
import br.app.ajudantetela.lab.TipoRegistroLab

class LabActivity : Activity() {

    private lateinit var corpo: LinearLayout
    private lateinit var statusSessao: TextView
    private lateinit var campoObjetivo: EditText
    private lateinit var campoSearchKey: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0614")
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0614"))
            setPadding(dp(16), dp(24), dp(16), dp(16))
        }
        root.addView(TextView(this).apply {
            text = "Lua Lab"
            textSize = 24f
            setTextColor(Color.parseColor("#E9D5FF"))
            typeface = Typeface.DEFAULT_BOLD
        })
        root.addView(TextView(this).apply {
            text = "Pesquisador/professor — isolado da Lua operacional"
            textSize = 12f
            setTextColor(Color.parseColor("#9B8AB8"))
            setPadding(0, dp(4), 0, dp(12))
        })

        campoSearchKey = EditText(this).apply {
            hint = "Chave API de pesquisa (Tavily) — opcional"
            setText(LabConfig.searchApiKey(this@LabActivity))
            setTextColor(Color.parseColor("#E9D5FF"))
            setHintTextColor(Color.parseColor("#7A6B8F"))
            setBackgroundColor(Color.parseColor("#160E28"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(campoSearchKey)
        root.addView(botao("Salvar chave de pesquisa") {
            LabConfig.setSearchApiKey(this, campoSearchKey.text.toString())
            toast(if (LabConfig.temSearchKey(this)) "Chave salva localmente" else "Chave limpa")
        })

        campoObjetivo = EditText(this).apply {
            hint = "Objetivo: ensine a Lua a mandar mensagens no WhatsApp"
            setText("Ensine a Lua a mandar mensagens no WhatsApp")
            setTextColor(Color.parseColor("#E9D5FF"))
            setHintTextColor(Color.parseColor("#7A6B8F"))
            setBackgroundColor(Color.parseColor("#160E28"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        root.addView(campoObjetivo, lp(8))
        statusSessao = TextView(this).apply {
            text = "Sessao: ocioso"
            textSize = 12f
            setTextColor(Color.parseColor("#C4B5FD"))
            setPadding(0, dp(6), 0, dp(6))
        }
        root.addView(statusSessao)
        root.addView(botao("Iniciar sessao de pesquisa/treino") {
            val obj = campoObjetivo.text.toString().ifBlank {
                "Ensine a Lua a mandar mensagens no WhatsApp"
            }
            statusSessao.text = "Sessao: iniciando..."
            LabMotor.iniciarSessao(
                this,
                obj,
                onProgresso = { p ->
                    statusSessao.text = "Sessao ${p.sessao.status}: ${p.mensagem}"
                },
                onFim = { s ->
                    statusSessao.text = "Sessao ${s.status} | pesq=${s.pesquisas} hip=${s.hipoteses} exp=${s.experimentos}"
                    toast("Sessao concluida")
                    render()
                }
            )
        })

        val scroll = ScrollView(this)
        corpo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(corpo)
        root.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        )
        setContentView(root)
        render()
    }

    override fun onResume() {
        super.onResume()
        if (::corpo.isInitialized) render()
    }

    private fun render() {
        corpo.removeAllViews()
        val rels = LabRepositorio.listarRelatorios(this)
        val comps = LabRepositorio.listarCompetencias(this)
        val regs = LabRepositorio.listarRegistros(this)
        val sessoes = LabRepositorio.listarSessoes(this)
        val hip = LabRepositorio.listarHipoteses(this)
        val exps = LabRepositorio.listarExperimentos(this)
        val conhec = LabRepositorio.listarConhecimentosParaLua(this)

        corpo.addView(secao("Resumo"))
        corpo.addView(
            txt(
                "Relatorios=${rels.size} Competencias=${comps.size}\n" +
                    "Sessoes=${sessoes.size} Hipoteses=${hip.size} Experimentos=${exps.size}\n" +
                    "Conhecimento validado=${conhec.size}\n" +
                    "Pesquisa API: " + (if (LabConfig.temSearchKey(this)) "configurada" else "stub (sem chave)")
            )
        )

        corpo.addView(secao("Ultimas sessoes"))
        if (sessoes.isEmpty()) corpo.addView(txt("Nenhuma sessao ainda."))
        sessoes.take(5).forEach { s ->
            corpo.addView(
                txt(
                    "${s.competenciaNome} [${s.status}]\n" +
                        "pesq=${s.pesquisas} hip=${s.hipoteses} exp=${s.experimentos}\n" +
                        s.log.takeLast(4).joinToString("\n")
                )
            )
        }

        corpo.addView(secao("Competencias"))
        comps.take(8).forEach { c ->
            corpo.addView(txt("${c.nome}\n${c.status} | rels=${c.relatorioIds.size} | exps=${c.experimentos}"))
            val pronto = LabValidador.avaliarProntidao(this, c)
            corpo.addView(txt("Prontidao: ${pronto.ok}\n" + pronto.motivos.joinToString("\n")))
            if (c.status != StatusCompetencia.VALIDADA) {
                corpo.addView(botao("Validar conhecimento para: ${c.nome.take(28)}") {
                    LabValidador.gerarConhecimentoEstruturado(this, c)
                    toast("CONHECIMENTO_VALIDADO gerado (ponte Lua ainda isolada)")
                    render()
                })
            }
        }

        corpo.addView(secao("Hipoteses"))
        hip.take(6).forEach { h -> corpo.addView(txt(h.texto)) }

        corpo.addView(secao("Experimentos"))
        exps.take(6).forEach { e ->
            corpo.addView(txt((if (e.sucesso) "OK" else "FALHA") + " " + e.descricao + "\n" + e.resultado.take(160)))
        }

        corpo.addView(secao("Relatorios da Lua"))
        rels.take(5).forEach { r ->
            corpo.addView(txt((if (r.sucesso) "OK" else "FALHA") + " " + r.objetivo.take(60)))
        }

        corpo.addView(secao("Registros recentes"))
        regs.take(10).forEach { r ->
            corpo.addView(txt("[" + r.tipo + "] " + r.titulo + "\n" + r.corpo.take(140)))
        }

        corpo.addView(secao("Conhecimento pronto (futuro consumo pela Lua)"))
        if (conhec.isEmpty()) corpo.addView(txt("Nenhum. Valide manualmente apos sessoes/experimentos."))
        else conhec.forEach { k ->
            corpo.addView(txt(k.competencia + " conf=" + k.confianca + "\n" + k.estrategias.joinToString(" -> ")))
        }
    }

    private fun secao(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.parseColor("#A78BFA"))
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(14), 0, dp(6))
    }

    private fun txt(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.parseColor("#D4C4F0"))
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(10).toFloat()
            setColor(Color.parseColor("#160E28"))
            setStroke(dp(1), Color.parseColor("#3D2A5C"))
        }
        layoutParams = lp(8)
    }

    private fun botao(t: String, a: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#6D28D9"))
        }
        setOnClickListener { a() }
        layoutParams = lp(8)
    }

    private fun lp(bottom: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).also { it.bottomMargin = dp(bottom) }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
