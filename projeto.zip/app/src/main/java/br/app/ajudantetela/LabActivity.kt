package br.app.ajudantetela

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import br.app.ajudantetela.lab.LabConfig
import br.app.ajudantetela.lab.LabMotor
import br.app.ajudantetela.lab.LabRelatorio
import br.app.ajudantetela.lab.LabRepositorio
import br.app.ajudantetela.lab.LabValidador
import br.app.ajudantetela.lab.LabConhecimentoLua
import br.app.ajudantetela.lab.LabMemoriaErros
import br.app.ajudantetela.lab.StatusCompetencia

/**
 * UI rolavel do Lab. Nao altera a Lua operacional.
 */
class LabActivity : Activity() {

    private lateinit var corpo: LinearLayout
    private lateinit var statusLab: TextView
    private lateinit var progressoLab: TextView
    private lateinit var areaTrabalho: TextView
    private lateinit var campoObjetivo: EditText
    private lateinit var statusNet: TextView
    private lateinit var areaRelatorio: TextView
    private var ultimoRelatorioTexto: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0614")

        // TODA a tela e um ScrollView vertical
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0614"))
            isFillViewport = true
            overScrollMode = ScrollView.OVER_SCROLL_ALWAYS
        }
        corpo = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(20), dp(16), dp(32))
        }
        scroll.addView(
            corpo,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        setContentView(scroll)
        montarTudo()
    }

    override fun onResume() {
        super.onResume()
        if (::statusNet.isInitialized) atualizarStatusNet()
        atualizarListas()
    }

    private fun montarTudo() {
        corpo.removeAllViews()

        corpo.addView(titulo("Lab da Lua", 24f))
        corpo.addView(
            texto(
                "Um laboratorio que pesquisa, testa e prepara conhecimentos para a Lua.\n" +
                    "A Lua continua sendo quem executa tarefas no celular.\n" +
                    "Nada daqui e aplicado a Lua sem a sua autorizacao."
            )
        )

        // INTERNET
        corpo.addView(secao("Internet do Lab"))
        corpo.addView(
            texto(
                "Permite que o laboratorio pesquise informacoes na Web.\n" +
                    "Isso afeta SOMENTE o Lab, nao a Lua operacional nem a chave da IA de missoes."
            )
        )
        statusNet = TextView(this).apply {
            textSize = 14f
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(8))
        }
        corpo.addView(statusNet)
        atualizarStatusNet()
        corpo.addView(botao("Permitir / bloquear Internet") {
            val novo = !LabConfig.internetPermitida(this)
            if (novo) {
                AlertDialog.Builder(this)
                    .setTitle("Autorizar internet do Lab?")
                    .setMessage(
                        "O Lab podera pesquisar na Web para este treinamento.\n\n" +
                            "Isso NAO altera a Lua operacional.\n" +
                            "Voce pode bloquear de novo a qualquer momento."
                    )
                    .setPositiveButton("Permitir") { _, _ ->
                        LabConfig.setInternetPermitida(this, true)
                        atualizarStatusNet()
                        toast("Internet do Lab autorizada")
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            } else {
                LabConfig.setInternetPermitida(this, false)
                atualizarStatusNet()
                toast("Internet do Lab bloqueada")
            }
        })

        // API opcional
        corpo.addView(secao("Acesso a pesquisa por API (opcional)"))
        corpo.addView(
            texto(
                "Se quiser, cole uma chave de API de pesquisa (ex.: Tavily).\n" +
                    "Sem chave, com internet liberada, o Lab tenta pesquisa Web publica.\n" +
                    "A chave fica so neste aparelho."
            )
        )
        val campoKey = EditText(this).apply {
            hint = "Chave de pesquisa (opcional)"
            setText(LabConfig.searchApiKey(this@LabActivity))
            setTextColor(Color.parseColor("#E9D5FF"))
            setHintTextColor(Color.parseColor("#7A6B8F"))
            setBackgroundColor(Color.parseColor("#160E28"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        corpo.addView(campoKey, lp(6))
        corpo.addView(botao("Salvar chave de pesquisa") {
            LabConfig.setSearchApiKey(this, campoKey.text.toString())
            if (LabConfig.temSearchKey(this)) {
                LabConfig.setSearchProvider(this, "tavily")
                toast("Chave salva")
            } else {
                LabConfig.setSearchProvider(this, "webview")
                toast("Sem chave — modo Web")
            }
        })

        // OBJETIVO
        corpo.addView(secao("Objetivo do treinamento"))
        corpo.addView(
            texto("Escreva o que voce quer que o Lab ensine a Lua. Ex.: Ensine a Lua a mandar mensagens no WhatsApp")
        )
        campoObjetivo = EditText(this).apply {
            setText("Ensine a Lua a mandar mensagens no WhatsApp")
            setTextColor(Color.parseColor("#E9D5FF"))
            setHintTextColor(Color.parseColor("#7A6B8F"))
            setBackgroundColor(Color.parseColor("#160E28"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minLines = 2
        }
        corpo.addView(campoObjetivo, lp(6))

        statusLab = TextView(this).apply {
            text = "Laboratorio parado"
            textSize = 15f
            setTextColor(Color.parseColor("#C4B5FD"))
            setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(4))
        }
        progressoLab = TextView(this).apply {
            text = "Nenhum treinamento em andamento"
            textSize = 12f
            setTextColor(Color.parseColor("#9B8AB8"))
            setPadding(0, 0, 0, dp(8))
        }
        corpo.addView(statusLab)
        corpo.addView(progressoLab)

        corpo.addView(botao("Comecar treinamento") {
            if (!LabConfig.internetPermitida(this)) {
                toast("Internet bloqueada: treino usara relatorios locais + simulador (sem Web)")
            }
            val obj = campoObjetivo.text.toString().ifBlank {
                "Ensine a Lua a mandar mensagens no WhatsApp"
            }
            statusLab.text = "Iniciando..."
            areaTrabalho.text = "Preparando sessao..."
            LabMotor.iniciarSessao(
                this,
                obj,
                onProgresso = { p ->
                    statusLab.text = statusAmigavel(p)
                    progressoLab.text =
                        "Etapa ${p.etapa} de cerca de ${p.etapaTotalEstimado}\n${p.mensagemAmigavel}"
                    areaTrabalho.text = textoTrabalho(obj, p)
                },
                onFim = { s ->
                    statusLab.text = "Treinamento desta rodada concluido"
                    progressoLab.text =
                        "Pesquisas: ${s.pesquisas} | Ideias: ${s.hipoteses} | Testes: ${s.experimentos}\n" +
                            "Nada foi enviado automaticamente para a Lua."
                    areaTrabalho.text =
                        "Objetivo: ${s.objetivo}\n\nSessao ${s.status}.\nUse Gerar relatorio do Lab para ver o detalhe completo."
                    toast("Pronto — gere o relatorio se quiser analisar")
                    atualizarListas()
                }
            )
        })

        // O QUE ESTA FAZENDO
        corpo.addView(secao("O que o Lab esta fazendo?"))
        corpo.addView(
            texto("Resumo operacional durante o treinamento (pergunta, motivo e proximo passo).")
        )
        areaTrabalho = cardView(
            "Laboratorio parado.\nQuando iniciar o treinamento, esta area mostra o trabalho atual."
        )
        corpo.addView(areaTrabalho)

        // RELATORIO DO LAB
        corpo.addView(secao("Relatorio do Lab"))
        corpo.addView(
            texto(
                "Diferente do relatorio da missao da Lua.\n" +
                    "Aqui o laboratorio descreve o que ELE pesquisou, testou e concluiu."
            )
        )
        areaRelatorio = cardView("Toque em Gerar relatorio do Lab apos um treinamento.")
        corpo.addView(areaRelatorio)
        corpo.addView(botao("Gerar relatorio do Lab") {
            ultimoRelatorioTexto = LabRelatorio.gerar(this)
            areaRelatorio.text = ultimoRelatorioTexto.take(3500) +
                if (ultimoRelatorioTexto.length > 3500) "\n\n... (relatorio completo no botao Copiar)" else ""
            toast("Relatorio gerado")
        })
        corpo.addView(botao("Copiar relatorio") {
            if (ultimoRelatorioTexto.isBlank()) {
                ultimoRelatorioTexto = LabRelatorio.gerar(this)
            }
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("relatorio_lab", ultimoRelatorioTexto))
            toast("Relatorio copiado")
        })

        // Listas dinamicas (container ids via tags)
        corpo.addView(secao("Relatorios da Lua"))
        corpo.addView(texto("Aqui ficam as missoes reais que a Lua executou. Se estiver vazio, rode uma missao na Lua e volte."))
        adicionarMarcador("lista_rels")

        corpo.addView(secao("Ultimos treinamentos"))
        adicionarMarcador("lista_sessoes")

        corpo.addView(secao("Analise do Lab"))
        corpo.addView(texto("Aqui o Lab tenta descobrir por que a Lua falhou (gerado ao receber o relatorio)."))
        adicionarMarcador("lista_analise")

        corpo.addView(secao("Pesquisa"))
        corpo.addView(texto("Aqui o Lab procura informacoes na Web para entender o problema (sem repetir a mesma pergunta)."))
        adicionarMarcador("lista_pesq")

        corpo.addView(secao("Ideias em estudo (hipoteses)"))
        corpo.addView(texto("Ainda nao sao verdade oficial — so candidatos a investigacao."))
        adicionarMarcador("lista_hip")

        corpo.addView(secao("Experimentos"))
        corpo.addView(texto("Aqui o Lab testa estrategias. Testes simulados NAO provam que funcionarao no celular."))
        adicionarMarcador("lista_exp")

        corpo.addView(secao("Conhecimento (candidatos)"))
        corpo.addView(texto("Estrategias que o Lab acredita poder ensinar. Ainda precisam da sua aprovacao."))
        adicionarMarcador("lista_conhec")

        corpo.addView(secao("Conhecimentos prontos para ensinar a Lua"))
        corpo.addView(texto("Somente ao tocar em Aprovar e ensinar o conhecimento entra na memoria que a Lua pode consultar."))
        adicionarMarcador("lista_ensinar")

        corpo.addView(secao("Diario recente"))
        adicionarMarcador("lista_diario")

        atualizarListas()
    }

    private fun adicionarMarcador(tag: String) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            this.tag = tag
        }
        corpo.addView(box)
    }

    private fun caixa(tag: String): LinearLayout? {
        for (i in 0 until corpo.childCount) {
            val v = corpo.getChildAt(i)
            if (v is LinearLayout && tag == v.tag) return v
        }
        return null
    }

    private fun atualizarListas() {
        val rels = LabRepositorio.listarRelatorios(this)
        val sessoes = LabRepositorio.listarSessoes(this)
        val hip = LabRepositorio.listarHipoteses(this)
        val exps = LabRepositorio.listarExperimentos(this)
        val conhec = LabRepositorio.listarConhecimentosParaLua(this)
        val comps = LabRepositorio.listarCompetencias(this)
        val regs = LabRepositorio.listarRegistros(this)

        fun preencher(tag: String, builder: LinearLayout.() -> Unit) {
            val box = caixa(tag) ?: return
            box.removeAllViews()
            box.builder()
        }

        preencher("lista_rels") {
            addView(texto("Armazenados agora: " + rels.size + " (ultimo id: " +
                LabRepositorio.ultimoRelatorioId(this@LabActivity).ifBlank { "nenhum" } + ")"))
            if (rels.isEmpty()) {
                addView(texto("Nenhum relatorio ainda. Execute uma missao na Lua e reabra o Lab."))
            }
            rels.take(8).forEach { r ->
                addView(
                    cardView(
                        (if (r.sucesso) "Deu certo" else "Falhou ou parou") + "
" +
                            r.objetivo.take(80) + "
" + r.id + " · " + r.competenciaSugerida
                    )
                )
            }
        }

        preencher("lista_analise") {
            val an = regs.filter { it.titulo.contains("Analise automatica", true) }
            if (an.isEmpty()) addView(texto("Nenhuma analise ainda."))
            an.take(4).forEach { addView(cardView(it.corpo.take(500))) }
            val mem = LabMemoriaErros.listar(this@LabActivity)
            if (mem.isNotEmpty()) {
                addView(texto("Memoria de erros (nao repetir):"))
                mem.take(6).forEach {
                    addView(cardView(it.estrategia + " | " + it.contexto))
                }
            }
        }

        preencher("lista_pesq") {
            val pq = regs.filter { it.tipo.name.contains("PESQUISA") }
            if (pq.isEmpty()) addView(texto("Nenhuma pesquisa ainda."))
            pq.take(8).forEach { addView(cardView(it.titulo + "
" + it.corpo.take(280))) }
        }

        preencher("lista_sessoes") {
            if (sessoes.isEmpty()) addView(texto("Nenhum treinamento ainda."))
            sessoes.take(5).forEach { s ->
                addView(
                    cardView(
                        s.competenciaNome + "\n" +
                            "Pesquisas ${s.pesquisas} · Ideias ${s.hipoteses} · Testes ${s.experimentos}\n" +
                            s.log.takeLast(4).joinToString("\n")
                    )
                )
            }
        }

        preencher("lista_hip") {
            if (hip.isEmpty()) addView(texto("Nenhuma ideia registrada."))
            hip.take(8).forEach { h -> addView(cardView(h.texto)) }
        }

        preencher("lista_exp") {
            if (exps.isEmpty()) addView(texto("Nenhum experimento ainda."))
            exps.take(6).forEach { e ->
                addView(
                    cardView(
                        (if (e.sucesso) "Teste ok" else "Teste falhou") + " — " + e.descricao + "\n" +
                            e.resultado.take(140)
                    )
                )
            }
        }

        preencher("lista_conhec") {
            comps.take(6).forEach { c ->
                val pronto = LabValidador.avaliarProntidao(this@LabActivity, c)
                addView(
                    cardView(
                        c.nome + "\nEstado: " + c.status +
                            "\nPode validar? " + (if (pronto.ok) "Revise e confirme" else "Ainda fraco") +
                            "\n" + pronto.motivos.take(3).joinToString("\n")
                    )
                )
                if (c.status != StatusCompetencia.VALIDADA) {
                    addView(botao("Autorizar conhecimento: " + c.nome.take(28)) {
                        val k = LabValidador.gerarConhecimentoEstruturado(this@LabActivity, c)
                        if (k == null) {
                            toast("Validacao recusada: falta evidencia real (veja prontidao)")
                        } else {
                            toast("Conhecimento validado (ainda NAO aplicado na Lua)")
                        }
                        atualizarListas()
                    })
                }
            }
            if (conhec.isNotEmpty()) {
                addView(texto("Ja autorizado:"))
                conhec.forEach { k ->
                    addView(cardView(k.competencia + "\n" + k.estrategias.joinToString(" → ")))
                }
            }
            if (comps.isEmpty()) addView(texto("Nenhuma competencia ainda."))
        }

        preencher("lista_ensinar") {
            val aprovados = LabConhecimentoLua.listar(this@LabActivity)
            val ens = regs.filter { it.titulo.contains("Plano de ensino", true) }
            if (ens.isEmpty() && aprovados.isEmpty()) {
                addView(texto("Nenhum candidato ainda. Rode uma missao e/ou treinamento."))
            }
            ens.take(3).forEach { e ->
                addView(cardView(e.corpo.take(400)))
                addView(botao("Aprovar e ensinar a Lua") {
                    LabConhecimentoLua.aprovar(
                        this@LabActivity,
                        LabConhecimentoLua.Item(
                            id = e.id,
                            oQueEnsinar = e.titulo + " / " + e.corpo.lines().firstOrNull {
                                it.contains("Nova estrategia", true) || it.contains("estrategia", true)
                            }.orEmpty().take(200),
                            quandoUsar = "Quando o objetivo for semelhante ao da competencia associada",
                            comoExecutar = e.corpo.take(500),
                            oQueEvitar = LabMemoriaErros.listar(this@LabActivity)
                                .take(5).joinToString("; ") { it.estrategia },
                            evidencias = e.origemRelatorioIds.joinToString(),
                            falhasConhecidas = LabMemoriaErros.listar(this@LabActivity)
                                .take(5).joinToString("; ") { it.estrategia },
                            confianca = 40,
                            data = System.currentTimeMillis(),
                            status = "aprovado"
                        )
                    )
                    toast("Conhecimento aprovado — a Lua podera consultar no proximo ciclo")
                    atualizarListas()
                })
            }
            if (aprovados.isNotEmpty()) {
                addView(texto("Ja aprovados para a Lua:"))
                aprovados.forEach { a ->
                    addView(cardView(a.oQueEnsinar.take(120) + "\nConfianca " + a.confianca + " · " + a.status))
                }
            }
        }

        preencher("lista_diario") {
            if (regs.isEmpty()) addView(texto("Diario vazio."))
            regs.take(12).forEach { r ->
                addView(cardView(r.titulo + "\n" + r.corpo.take(180)))
            }
        }
    }

    private fun textoTrabalho(objetivo: String, p: LabMotor.Progresso): String {
        return buildString {
            append("Objetivo:\n").append(objetivo).append("\n\n")
            append("Agora:\n").append(p.mensagemAmigavel).append("\n\n")
            if (p.perguntaAtual.isNotBlank()) {
                append("Pesquisando:\n").append(p.perguntaAtual).append("\n\n")
            }
            if (p.motivoAtual.isNotBlank()) {
                append("Motivo:\n").append(p.motivoAtual).append("\n\n")
            }
            if (p.proximoPasso.isNotBlank()) {
                append("Proximo passo:\n").append(p.proximoPasso)
            }
            if (p.perguntaAtual.isBlank() && p.motivoAtual.isBlank()) {
                append("Acompanhe o status acima enquanto o Lab trabalha.")
            }
        }
    }

    private fun statusAmigavel(p: LabMotor.Progresso): String {
        val st = p.sessao.status.name
        return when {
            st.contains("PESQUIS") -> "Pesquisando"
            st.contains("ANALIS") -> "Analisando"
            st.contains("EXPERIMENT") -> "Experimentando"
            st.contains("VALID") -> "Preparando conhecimento"
            st.contains("CONCLUID") -> "Concluido"
            else -> p.mensagemAmigavel.take(40)
        }
    }

    private fun atualizarStatusNet() {
        if (LabConfig.internetPermitida(this)) {
            statusNet.text = "Internet do Lab: AUTORIZADA"
            statusNet.setTextColor(Color.parseColor("#6EE7B7"))
        } else {
            statusNet.text = "Internet do Lab: BLOQUEADA"
            statusNet.setTextColor(Color.parseColor("#FCA5A5"))
        }
    }

    private fun titulo(t: String, size: Float) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(Color.parseColor("#E9D5FF"))
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 0, 0, dp(6))
    }

    private fun secao(t: String) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.parseColor("#A78BFA"))
        setTypeface(typeface, Typeface.BOLD)
        setPadding(0, dp(16), 0, dp(6))
    }

    private fun texto(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.parseColor("#C4B5FD"))
        setPadding(0, 0, 0, dp(8))
    }

    private fun cardView(t: String) = TextView(this).apply {
        text = t
        textSize = 12f
        setTextColor(Color.parseColor("#E9D5FF"))
        setPadding(dp(12), dp(10), dp(12), dp(10))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#160E28"))
            setStroke(dp(1), Color.parseColor("#3D2A5C"))
        }
        layoutParams = lp(8)
    }

    private fun botao(t: String, a: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 13f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(12), dp(12), dp(12))
        background = GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(Color.parseColor("#6D28D9"))
        }
        setOnClickListener { a() }
        layoutParams = lp(8)
    }

    private fun lp(b: Int) = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).also { it.bottomMargin = dp(b) }

    private fun toast(m: String) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
