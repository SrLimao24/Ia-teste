package br.app.ajudantetela.autofix

import android.content.Context

/**
 * Feature flag da ponte AGIR→VERIFICAR.
 * DESLIGADA por padrão até teste real no celular.
 */
object LuaAutoFixConfig {
    private const val PREFS = "lua_autofix_v1"
    private const val K_ENABLED = "enabled"

    fun isEnabled(ctx: Context): Boolean =
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getBoolean(K_ENABLED, false)

    fun setEnabled(ctx: Context, enabled: Boolean) {
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putBoolean(K_ENABLED, enabled).apply()
    }
}
