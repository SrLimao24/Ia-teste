package br.app.ajudantetela

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Tela principal — ativar acessibilidade e textos salvos.
 * Apenas apresentação visual; a lógica permanece a mesma.
 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var listaView: LinearLayout
    private lateinit var campo: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0B0614")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0B0614"))
            setPadding(dp(20), dp(28), dp(20), dp(24))
        }

        // Cabeçalho
        root.addView(TextView(this).apply {
            text = "🌙  Lua"
            textSize = 28f
            setTextColor(Color.parseColor("#E9D5FF"))
            typeface = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
            letterSpacing = 0.04f
        })
        root.addView(TextView(this).apply {
            text = "Assistente de tela"
            textSize = 14f
            setTextColor(Color.parseColor("#9B8AB8"))
            setPadding(0, dp(4), 0, dp(20))
        })

        // Card: serviço
        val cardServico = card()
        cardServico.addView(TextView(this).apply {
            text = "Acessibilidade"
            textSize = 13f
            setTextColor(Color.parseColor("#A78BFA"))
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.06f
        })
        status = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.parseColor("#E9D5FF"))
            setPadding(0, dp(8), 0, dp(14))
        }
        cardServico.addView(status)

        cardServico.addView(botaoPrimario("Abrir configurações de acessibilidade") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        cardServico.addView(TextView(this).apply {
            text = "Ative o serviço “Lua” (ou Ajudante de Tela) na lista e volte aqui."
            textSize = 12f
            setTextColor(Color.parseColor("#7A6B8F"))
            setPadding(0, dp(10), 0, 0)
        })
        root.addView(cardServico, margem(0, 0, 0, 16))

        // Card: textos
        val cardTextos = card()
        cardTextos.addView(TextView(this).apply {
            text = "Textos salvos"
            textSize = 13f
            setTextColor(Color.parseColor("#A78BFA"))
            setTypeface(typeface, Typeface.BOLD)
            letterSpacing = 0.06f
        })
        cardTextos.addView(TextView(this).apply {
            text = "Atalhos que a Lua pode colar ou usar no celular."
            textSize = 12f
            setTextColor(Color.parseColor("#7A6B8F"))
            setPadding(0, dp(4), 0, dp(12))
        })

        campo = EditText(this).apply {
            hint = "Novo texto…"
            textSize = 15f
            setTextColor(Color.parseColor("#F5EDFF"))
            setHintTextColor(Color.parseColor("#6B5A80"))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#160E24"))
                setStroke(dp(1), Color.parseColor("#3D2A55"))
            }
            setSingleLine(true)
        }
        cardTextos.addView(
            campo,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        )

        cardTextos.addView(botaoPrimario("Salvar texto") {
            val t = campo.text?.toString()?.trim().orEmpty()
            if (t.isEmpty()) {
                Toast.makeText(this@MainActivity, "Digite um texto.", Toast.LENGTH_SHORT).show()
                return@botaoPrimario
            }
            val lista = Textos.ler(this@MainActivity)
            lista.add(0, t)
            Textos.salvar(this@MainActivity, lista)
            campo.setText("")
            refazerLista()
            Toast.makeText(this@MainActivity, "Salvo", Toast.LENGTH_SHORT).show()
        })

        listaView = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, 0)
        }
        cardTextos.addView(listaView)
        root.addView(cardTextos, margem(0, 0, 0, 8))

        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0B0614"))
            addView(root)
        }
        setContentView(scroll)
        atualizarStatus()
        refazerLista()
    }

    override fun onResume() {
        super.onResume()
        if (::status.isInitialized) atualizarStatus()
    }

    private fun atualizarStatus() {
        val ativo = servicoAtivo()
        status.text = if (ativo) "Situação: ativo  ✓" else "Situação: ainda não ativado"
        status.setTextColor(
            Color.parseColor(if (ativo) "#6EE7B7" else "#F0ABFC")
        )
    }

    private fun refazerLista() {
        listaView.removeAllViews()
        val lista = Textos.ler(this)
        if (lista.isEmpty()) {
            listaView.addView(TextView(this).apply {
                text = "Nenhum texto salvo ainda."
                textSize = 13f
                setTextColor(Color.parseColor("#6B5A80"))
                setPadding(0, dp(8), 0, 0)
            })
            return
        }
        lista.forEachIndexed { i, t ->
            val linha = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(10), dp(8), dp(10))
                background = GradientDrawable().apply {
                    cornerRadius = dp(10).toFloat()
                    setColor(Color.parseColor("#160E24"))
                    setStroke(dp(1), Color.parseColor("#2E2040"))
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(8) }
            }
            val tv = TextView(this).apply {
                text = t
                textSize = 14f
                setTextColor(Color.parseColor("#E9D5FF"))
            }
            linha.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val apagar = TextView(this).apply {
                text = "Apagar"
                textSize = 13f
                setTextColor(Color.parseColor("#C4B5FD"))
                setPadding(dp(12), dp(6), dp(8), dp(6))
                setOnClickListener {
                    val l = Textos.ler(this@MainActivity)
                    if (i < l.size) {
                        l.removeAt(i)
                        Textos.salvar(this@MainActivity, l)
                        refazerLista()
                    }
                }
            }
            linha.addView(apagar)
            listaView.addView(linha)
        }
    }

    private fun servicoAtivo(): Boolean {
        val lista = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return lista.contains(packageName)
    }

    private fun card(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#140C22"))
                setStroke(dp(1), Color.parseColor("#3D2A55"))
            }
        }
    }

    private fun botaoPrimario(rotulo: String, acao: () -> Unit): TextView {
        return TextView(this).apply {
            text = rotulo
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(14), dp(14), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#7B5CFF"))
            }
            setOnClickListener { acao() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
    }

    private fun margem(l: Int, t: Int, r: Int, b: Int) =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            setMargins(dp(l), dp(t), dp(r), dp(b))
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
