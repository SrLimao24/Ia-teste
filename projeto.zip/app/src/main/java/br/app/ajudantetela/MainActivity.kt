package br.app.ajudantetela

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var listaView: LinearLayout
    private lateinit var campo: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val coluna = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }

        coluna.addView(texto("Ajudante de Tela", 28f, "#13232B", true))
        coluna.addView(texto("Toque na bolinha ✦ em qualquer app para abrir o menu: traduzir a tela, voltar, início, rolar, print e digitar textos salvos.", 16f, "#5A6D77", false))

        status = texto("", 16f, "#13232B", true)
        coluna.addView(status)

        coluna.addView(texto(
            "Como ativar:\n\n" +
                "1. Toque no botão abaixo.\n" +
                "2. Procure \"Ajudante de Tela\" (em Apps instalados ou Serviços baixados) e ative.\n" +
                "3. Se aparecer \"Configuração restrita\": vá em Configurações > Apps > Ajudante de Tela, toque nos três pontinhos ⋮ e em \"Permitir configurações restritas\". Depois volte ao passo 2.\n" +
                "4. Abra qualquer app e toque na bolinha ✦. Você pode arrastá-la.\n\n" +
                "Tudo é processado no aparelho. A internet só é usada para baixar o idioma na primeira vez.",
            15f, "#13232B", false
        ))

        val botao = TextView(this).apply {
            text = "Abrir configurações de acessibilidade"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#1B6E8A"))
            }
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        coluna.addView(botao, margem(top = 20))

        // ---- Textos salvos ----
        coluna.addView(texto("Textos salvos", 22f, "#13232B", true), margem(top = 32))
        coluna.addView(texto(
            "Para digitar por você. Toque num campo de texto, abra o menu ✦ e escolha o texto. Não salve senhas aqui.",
            14f, "#5A6D77", false
        ))

        campo = EditText(this).apply {
            hint = "Ex.: meu e-mail, endereço, resposta rápida"
            textSize = 16f
            setTextColor(Color.parseColor("#13232B"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            minLines = 2
            gravity = Gravity.TOP
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(8).toFloat()
                setColor(Color.WHITE)
                setStroke(dp(1), Color.parseColor("#D3DEE3"))
            }
        }
        coluna.addView(campo, margem(top = 12))

        val adicionar = TextView(this).apply {
            text = "Adicionar texto"
            textSize = 16f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#1B6E8A"))
            }
            setOnClickListener {
                val t = campo.text.toString().trim()
                if (t.isNotEmpty()) {
                    val l = Textos.ler(this@MainActivity)
                    l.add(t)
                    Textos.salvar(this@MainActivity, l)
                    campo.setText("")
                    refazerLista()
                }
            }
        }
        coluna.addView(adicionar, margem(top = 10))

        listaView = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        coluna.addView(listaView, margem(top = 12))
        refazerLista()

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#EDF2F4"))
            addView(coluna)
        })
    }

    override fun onResume() {
        super.onResume()
        val ativo = servicoAtivo()
        status.text = if (ativo) "Situação: ativo ✓" else "Situação: ainda não ativado"
        status.setTextColor(Color.parseColor(if (ativo) "#1E7A4F" else "#9A5B00"))
    }

    private fun refazerLista() {
        listaView.removeAllViews()
        val lista = Textos.ler(this)
        if (lista.isEmpty()) {
            listaView.addView(texto("Nenhum texto salvo ainda.", 14f, "#5A6D77", false))
            return
        }
        lista.forEachIndexed { i, t ->
            val linha = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = margem(top = 8)
            }
            val tv = TextView(this).apply {
                text = t
                textSize = 15f
                setTextColor(Color.parseColor("#13232B"))
            }
            linha.addView(tv, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            val apagar = TextView(this).apply {
                text = "Apagar"
                textSize = 14f
                setTextColor(Color.parseColor("#9A5B00"))
                setPadding(dp(12), dp(8), dp(4), dp(8))
                setOnClickListener {
                    val l = Textos.ler(this@MainActivity)
                    if (i < l.size) {
                        l.removeAt(i)
                        Textos.salvar(this@MainActivity, l)
                        refazerLista()
                    }
                }
            }
            linha.addView(apagar)
            listaView.addView(linha)
        }
    }

    private fun servicoAtivo(): Boolean {
        val lista = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        return lista.contains(packageName)
    }

    private fun texto(t: String, tamanho: Float, cor: String, negrito: Boolean): TextView {
        return TextView(this).apply {
            text = t
            textSize = tamanho
            setTextColor(Color.parseColor(cor))
            if (negrito) setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = margem(top = 14)
        }
    }

    private fun margem(top: Int): LinearLayout.LayoutParams {
        return LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(top)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
