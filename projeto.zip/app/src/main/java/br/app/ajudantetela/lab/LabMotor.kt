package br.app.ajudantetela.lab

import android.content.Context
import android.os.Handler
import android.os.Looper
import br.app.ajudantetela.ConfigIA

/**
 * Orquestra uma sessao de pesquisa/treinamento do Lab.
 * Roda passos em background thread simples (sem WorkManager nesta fase).
 * NAO altera a Lua operacional.
 */
object LabMotor {

    private val main = Handler(Looper.getMainLooper())

    data class Progresso(
        val sessao: SessaoLab,
        val mensagem: String
    )

    fun iniciarSessao(
        ctx: Context,
        objetivo: String,
        onProgresso: (Progresso) -> Unit,
        onFim: (SessaoLab) -> Unit
    ) {
        Thread {
            val compNome = LabRepositorio.sugerirCompetencia(objetivo)
            var sessao = SessaoLab(
                id = "ses_${System.currentTimeMillis()}",
                objetivo = objetivo,
                competenciaNome = compNome,
                status = StatusSessaoLab.CRIADA,
                iniciadaEm = System.currentTimeMillis(),
                atualizadaEm = System.currentTimeMillis(),
                pesquisas = 0,
                hipoteses = 0,
                experimentos = 0,
                log = listOf("Sessao criada: $objetivo"),
                fontes = emptyList()
            )
            LabRepositorio.salvarSessao(ctx, sessao)
            emitir(sessao, "Iniciando pesquisa...", onProgresso)

            // garantir competencia
            val comps = LabRepositorio.listarCompetencias(ctx)
            var comp = comps.firstOrNull { it.nome.equals(compNome, true) }
            if (comp == null) {
                comp = CompetenciaLab(
                    id = "comp_${System.currentTimeMillis()}",
                    nome = compNome,
                    descricao = objetivo,
                    status = StatusCompetencia.EM_PESQUISA,
                    relatorioIds = emptyList(),
                    experimentos = 0,
                    falhasIdentificadas = emptyList(),
                    estrategias = emptyList(),
                    conhecimentoResumo = "",
                    atualizadoEm = System.currentTimeMillis()
                )
                LabRepositorio.atualizarCompetencia(ctx, comp)
            }

            // 1) Analise de relatorios existentes
            sessao = sessao.copy(status = StatusSessaoLab.ANALISANDO)
            val rels = LabRepositorio.listarRelatorios(ctx)
                .filter { it.competenciaSugerida.equals(compNome, true) || it.objetivo.contains(objetivo.take(20), true) }
            val analises = rels.take(5).map { LabAnalista.analisarRelatorioLocal(it) }
            sessao = appendLog(sessao, "Analisados ${rels.size} relatorios relacionados")
            LabRepositorio.salvarSessao(ctx, sessao)
            emitir(sessao, "Analise de relatorios", onProgresso)

            // 2) Pesquisa web
            sessao = sessao.copy(status = StatusSessaoLab.PESQUISANDO)
            LabRepositorio.salvarSessao(ctx, sessao)
            emitir(sessao, "Pesquisando na web...", onProgresso)
            val resultados = LabPesquisador.executarRodadaPesquisa(
                ctx, sessao.id, comp.id, objetivo, compNome
            )
            val fontes = resultados.map { it.url }.filter { it.isNotBlank() }.distinct()
            sessao = sessao.copy(
                pesquisas = sessao.pesquisas + resultados.size,
                fontes = (sessao.fontes + fontes).distinct(),
                log = sessao.log + "Pesquisa: ${resultados.size} resultados (${LabPesquisaFabrica.criar(ctx).nome})"
            )
            LabRepositorio.salvarSessao(ctx, sessao)

            // 3) Hipoteses (local + opcional IA)
            val hipoteses = mutableListOf<String>()
            hipoteses += "Clique no texto do contato pode nao ter ACTION_CLICK; preferir ancestral clicavel."
            hipoteses += "Enviar pode nao alterar a arvore o suficiente; exigir evidencia pos-envio."
            if (analises.any { it.contains("layout", true) }) {
                hipoteses += "Alvos ViewGroup/RelativeLayout sao estrategias fracas."
            }
            hipoteses.forEach { h ->
                LabRepositorio.salvarHipotese(
                    ctx,
                    HipoteseLab(
                        id = "hip_${System.currentTimeMillis()}_${h.hashCode()}",
                        competenciaId = comp.id,
                        texto = h,
                        base = "relatorios+pesquisa",
                        status = "aberta",
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
            sessao = sessao.copy(
                hipoteses = sessao.hipoteses + hipoteses.size,
                log = sessao.log + "Hipoteses criadas: ${hipoteses.size}"
            )
            if (LabConfig.labIaEnabled(ctx) && ConfigIA.temChave(ctx) && rels.isNotEmpty()) {
                // sincroniza via latch simples
                val lock = Object()
                var done = false
                LabAnalista.pedirHipoteseIa(ctx, rels.first()) { r ->
                    synchronized(lock) {
                        done = true
                        lock.notifyAll()
                    }
                }
                synchronized(lock) {
                    if (!done) lock.wait(25000)
                }
                sessao = appendLog(sessao, "Consulta IA Lab (hipotese) concluida ou timeout")
            }
            LabRepositorio.salvarSessao(ctx, sessao)
            emitir(sessao, "Hipoteses prontas", onProgresso)

            // 4) Experimentos
            sessao = sessao.copy(status = StatusSessaoLab.EXPERIMENTANDO)
            LabRepositorio.salvarSessao(ctx, sessao)
            emitir(sessao, "Rodando experimentos no simulador...", onProgresso)
            val e1 = LabExperimentos.experimentoEnvioWhatsApp(
                ctx, comp.id, "", "Fluxo completo envio no simulador"
            )
            val e2 = LabExperimentos.experimentoCliqueLayoutGenerico(ctx, comp.id)
            sessao = sessao.copy(
                experimentos = sessao.experimentos + 2,
                log = sessao.log + "Exp envio=${e1.sucesso}; Exp layout=${e2.sucesso}"
            )
            LabRepositorio.atualizarCompetencia(
                ctx,
                comp.copy(
                    experimentos = comp.experimentos + 2,
                    status = StatusCompetencia.EM_EXPERIMENTO,
                    atualizadoEm = System.currentTimeMillis()
                )
            )
            LabRepositorio.salvarSessao(ctx, sessao)

            // 5) Validacao (criterios + NAO auto-promover sem botao humano nesta fase)
            sessao = sessao.copy(status = StatusSessaoLab.VALIDANDO)
            val pronto = LabValidador.avaliarProntidao(ctx, LabRepositorio.listarCompetencias(ctx).first { it.id == comp.id })
            sessao = appendLog(sessao, "Prontidao: ${pronto.ok} | ${pronto.motivos.joinToString("; ")}")
            sessao = sessao.copy(
                status = StatusSessaoLab.CONCLUIDA,
                atualizadaEm = System.currentTimeMillis(),
                log = sessao.log + "Sessao concluida. Conhecimento_VALIDADO ainda exige confirmacao manual no Lab."
            )
            LabRepositorio.salvarSessao(ctx, sessao)
            emitir(sessao, "Sessao concluida", onProgresso)
            main.post { onFim(sessao) }
        }.start()
    }

    private fun appendLog(s: SessaoLab, msg: String) =
        s.copy(log = s.log + msg, atualizadaEm = System.currentTimeMillis())

    private fun emitir(s: SessaoLab, msg: String, cb: (Progresso) -> Unit) {
        main.post { cb(Progresso(s, msg)) }
    }
}
