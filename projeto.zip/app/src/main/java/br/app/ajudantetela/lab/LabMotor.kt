package br.app.ajudantetela.lab

import android.content.Context
import android.os.Handler
import android.os.Looper
import br.app.ajudantetela.ConfigIA

/**
 * Orquestra treinamento do Lab com etapas legiveis e limites.
 * NAO altera a Lua operacional.
 */
object LabMotor {

    private val main = Handler(Looper.getMainLooper())

    data class Progresso(
        val sessao: SessaoLab,
        val mensagemAmigavel: String,
        val etapa: Int,
        val etapaTotalEstimado: Int,
        val perguntaAtual: String = "",
        val motivoAtual: String = "",
        val proximoPasso: String = ""
    )

    fun iniciarSessao(
        ctx: Context,
        objetivo: String,
        onProgresso: (Progresso) -> Unit,
        onFim: (SessaoLab) -> Unit
    ) {
        Thread {
            val inicio = System.currentTimeMillis()
            val maxPesq = LabConfig.maxPesquisasSessao(ctx)
            val maxCiclos = LabConfig.maxCiclosSessao(ctx)
            val maxMs = LabConfig.maxMinutosSessao(ctx) * 60_000L

            val compNome = LabRepositorio.sugerirCompetencia(objetivo)
            var sessao = SessaoLab(
                id = "ses_" + System.currentTimeMillis(),
                objetivo = objetivo,
                competenciaNome = compNome,
                status = StatusSessaoLab.CRIADA,
                iniciadaEm = inicio,
                atualizadaEm = inicio,
                pesquisas = 0,
                hipoteses = 0,
                experimentos = 0,
                log = listOf("Treinamento iniciado: $objetivo"),
                fontes = emptyList()
            )
            LabRepositorio.salvarSessao(ctx, sessao)

            fun emit(
                msg: String,
                etapa: Int,
                total: Int = 12,
                pergunta: String = "",
                motivo: String = "",
                proximo: String = ""
            ) {
                sessao = sessao.copy(atualizadaEm = System.currentTimeMillis())
                LabRepositorio.salvarSessao(ctx, sessao)
                main.post {
                    onProgresso(
                        Progresso(sessao, msg, etapa, total, pergunta, motivo, proximo)
                    )
                }
            }

            fun tempoEsgotado() = System.currentTimeMillis() - inicio > maxMs

            // competencia
            var comp = LabRepositorio.listarCompetencias(ctx)
                .firstOrNull { it.nome.equals(compNome, true) }
            if (comp == null) {
                comp = CompetenciaLab(
                    id = "comp_" + System.currentTimeMillis(),
                    nome = compNome,
                    descricao = objetivo,
                    status = StatusCompetencia.EM_PESQUISA,
                    relatorioIds = emptyList(),
                    experimentos = 0,
                    falhasIdentificadas = emptyList(),
                    estrategias = emptyList(),
                    conhecimentoResumo = "",
                    atualizadoEm = System.currentTimeMillis()
                )
                LabRepositorio.atualizarCompetencia(ctx, comp)
            }

            // 1 ANALISE relatorios reais
            sessao = sessao.copy(status = StatusSessaoLab.ANALISANDO)
            emit("Analisando o que a Lua ja tentou nas missoes reais...", 1)
            var rels = LabRepositorio.listarRelatorios(ctx)
            if (rels.isEmpty()) {
                sessao = sessao.copy(log = sessao.log + "AVISO: 0 relatorios no Lab — execute uma missao real na Lua primeiro")
            }
            val relsFilt = rels.filter {
                it.competenciaSugerida.equals(compNome, true) ||
                    it.objetivo.contains(objetivo.take(16), true) ||
                    objetivo.contains(it.objetivo.take(16), true)
            }
            if (relsFilt.isNotEmpty()) rels = relsFilt
            // se filtro vazio mas ha relatorios, usa os mais recentes
            if (relsFilt.isEmpty() && LabRepositorio.contarRelatorios(ctx) > 0) {
                rels = LabRepositorio.listarRelatorios(ctx).take(5)
                sessao = sessao.copy(log = sessao.log + "Usando relatorios recentes (filtro competencia vazio)")
            }
            val analisesDet = rels.take(5).map { LabAnaliseRelatorio.analisar(it) }
            val analises = analisesDet.map { it.textoCompleto }
            val resumoRels = analisesDet.joinToString(" | ") {
                it.tipoProblema + " " + it.problemaFormulado + " " + it.primeiroPontoFalha
            }.take(800)
            sessao = sessao.copy(
                log = sessao.log + "Relatorios no Lab: ${LabRepositorio.contarRelatorios(ctx)}; usados nesta sessao: ${rels.size}"
            )
            emit("Comparando relatos da Lua com o objetivo...", 2)

            // 2 PESQUISA iterativa
            sessao = sessao.copy(status = StatusSessaoLab.PESQUISANDO)
            val rodadas = mutableListOf<LabPesquisador.Rodada>()
            var ciclo = 0
            while (ciclo < maxCiclos && sessao.pesquisas < maxPesq && !tempoEsgotado()) {
                val tipoProb = resumoRels.lowercase().let { s ->
                    when {
                        s.contains("clique") || s.contains("sem efeito") || s.contains("bela") -> "clique"
                        s.contains("digitar") -> "digitacao"
                        s.contains("enviar") -> "confirmacao_envio"
                        else -> ""
                    }
                }
                val next = LabPesquisador.proximaPerguntaApos(
                    ctx, objetivo, compNome, rodadas, resumoRels, tipoProb
                ) ?: break
                val (perg, motivo) = next
                ciclo++
                emit(
                    "Pesquisando na Web...",
                    3 + ciclo,
                    pergunta = perg,
                    motivo = motivo,
                    proximo = "Analisar resultado e decidir se precisa de nova pergunta"
                )
                val rodada = LabPesquisador.executarUmaPesquisa(ctx, comp.id, perg, motivo)
                rodadas.add(rodada)
                val fontes = rodada.resultados.map { it.url }.filter { it.isNotBlank() }
                sessao = sessao.copy(
                    pesquisas = sessao.pesquisas + 1,
                    fontes = (sessao.fontes + fontes).distinct(),
                    log = sessao.log + "Pesquisa ${sessao.pesquisas + 1}: $motivo"
                )
                // pequena pausa entre pesquisas
                try { Thread.sleep(400) } catch (_: Exception) {}
            }
            if (tempoEsgotado() || sessao.pesquisas >= maxPesq || ciclo >= maxCiclos) {
                sessao = sessao.copy(
                    log = sessao.log + "Limite de sessao atingido (pesq/ciclos/tempo)."
                )
            }

            // 3 HIPOTESES
            emit("Formulando ideias a partir da pesquisa e dos erros da Lua...", 8)
            val hipoteses = mutableListOf<String>()
            hipoteses += "Clicar so no texto do contato pode nao abrir a conversa; preferir item/ancestral clicavel."
            hipoteses += "Apos Enviar, e preciso evidenciar envio (campo vazio ou bolha), nao so mudanca qualquer."
            if (resumoRels.contains("layout", true) || resumoRels.contains("ViewGroup", true)) {
                hipoteses += "Alvos genericos de layout (ViewGroup/RelativeLayout) tendem a falhar."
            }
            if (resumoRels.contains("sem efeito", true)) {
                hipoteses += "Estrategias sem mudanca de tela devem ser bloqueadas e substituidas."
            }
            hipoteses.forEach { h ->
                LabRepositorio.salvarHipotese(
                    ctx,
                    HipoteseLab(
                        id = "hip_" + System.currentTimeMillis() + "_" + h.hashCode(),
                        competenciaId = comp.id,
                        texto = h,
                        base = "relatorios+pesquisa",
                        status = "aberta",
                        timestamp = System.currentTimeMillis()
                    )
                )
            }
            sessao = sessao.copy(
                hipoteses = sessao.hipoteses + hipoteses.size,
                log = sessao.log + "Ideias registradas: ${hipoteses.size}"
            )
            if (LabConfig.labIaEnabled(ctx) && ConfigIA.temChave(ctx) && rels.isNotEmpty()) {
                emit("Consultando a IA do Lab (so para hipoteses, nao valida sozinha)...", 9)
                val lock = Object()
                var done = false
                LabAnalista.pedirHipoteseIa(ctx, rels.first()) {
                    synchronized(lock) { done = true; lock.notifyAll() }
                }
                synchronized(lock) { if (!done) lock.wait(20000) }
            }

            // 4 EXPERIMENTOS
            sessao = sessao.copy(status = StatusSessaoLab.EXPERIMENTANDO)
            emit("Testando ideias no ambiente de experimento (simulador)...", 10)
            val e1 = LabExperimentos.experimentoEnvioWhatsApp(
                ctx, comp.id, "", "Fluxo completo de envio no simulador"
            )
            val e2 = LabExperimentos.experimentoCliqueLayoutGenerico(ctx, comp.id)
            sessao = sessao.copy(
                experimentos = sessao.experimentos + 2,
                log = sessao.log + "Experimentos: envio=${e1.sucesso}, layout=${e2.sucesso}"
            )
            LabRepositorio.atualizarCompetencia(
                ctx,
                comp.copy(
                    experimentos = comp.experimentos + 2,
                    status = StatusCompetencia.EM_EXPERIMENTO,
                    atualizadoEm = System.currentTimeMillis()
                )
            )

            // 5 PREPARAR (sem auto-validar)
            sessao = sessao.copy(status = StatusSessaoLab.VALIDANDO)
            emit("Preparando resumo. Conhecimento so vira oficial se voce autorizar.", 11)
            val pronto = LabValidador.avaliarProntidao(
                ctx,
                LabRepositorio.listarCompetencias(ctx).first { it.id == comp.id }
            )
            sessao = sessao.copy(
                status = StatusSessaoLab.CONCLUIDA,
                atualizadaEm = System.currentTimeMillis(),
                log = sessao.log + "Prontidao=${pronto.ok}: ${pronto.motivos.joinToString("; ")}" +
                    " | Aguardando sua autorizacao para validar conhecimento."
            )
            LabRepositorio.salvarSessao(ctx, sessao)
            emit("Treinamento desta sessao concluido. Nada foi aplicado a Lua automaticamente.", 12)
            main.post { onFim(sessao) }
        }.start()
    }
}
