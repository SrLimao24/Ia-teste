package br.app.ajudantetela.autofix

enum class AttemptState {
    NOT_ATTEMPTED,
    ATTEMPTED,
    CONFIRMED,
    BLOCKED
}

data class AttemptKey(
    val actionType: String,
    val destination: String,
    val content: String
)

/**
 * Guard por missão: impede reexecução de ação duplicável na mesma missão.
 * Não é só um Set local anônimo — estados nomeados e explícitos.
 */
class AttemptGuard(
    private val states: MutableMap<AttemptKey, AttemptState> = mutableMapOf()
) {
    fun stateOf(key: AttemptKey): AttemptState =
        states[key] ?: AttemptState.NOT_ATTEMPTED

    fun markAttempted(key: AttemptKey) {
        states[key] = AttemptState.ATTEMPTED
    }

    fun markConfirmed(key: AttemptKey) {
        states[key] = AttemptState.CONFIRMED
    }

    fun block(key: AttemptKey) {
        states[key] = AttemptState.BLOCKED
    }

    fun mayExecuteDuplicateAction(key: AttemptKey): Boolean =
        stateOf(key) == AttemptState.NOT_ATTEMPTED
}
