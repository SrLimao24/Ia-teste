package br.app.ajudantetela

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Provedor Grok (xAI).
 * Endpoint: https://api.x.ai/v1/chat/completions
 * Auth: Bearer <API key>
 */
class GrokProvedor : ModeloIA {
    override val nome: String = "Grok (xAI)"

    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit) {
        if (apiKey.isBlank()) {
            callback(ResultadoTeste(false, "Chave da API vazia."))
            return
        }
        executor.execute {
            try {
                val body = JSONObject()
                    .put("model", "grok-3")
                    .put("max_tokens", 16)
                    .put(
                        "messages",
                        JSONArray().put(
                            JSONObject()
                                .put("role", "user")
                                .put("content", "Responda apenas: ok")
                        )
                    )

                val conn = (URL("https://api.x.ai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                }

                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val resposta = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

                val resultado = when {
                    code in 200..299 -> ResultadoTeste(true, "Conectado ✓ (HTTP $code)")
                    code == 401 || code == 403 -> ResultadoTeste(false, "Chave inválida ou sem permissão (HTTP $code)")
                    code == 429 -> ResultadoTeste(false, "Limite de requisições (HTTP 429). Tente depois.")
                    else -> ResultadoTeste(false, "Falha HTTP $code: ${resposta.take(120)}")
                }
                main.post { callback(resultado) }
            } catch (e: Exception) {
                main.post {
                    callback(ResultadoTeste(false, "Erro de rede: ${e.message ?: e.javaClass.simpleName}"))
                }
            }
        }
    }

    override fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    ) {
        // Placeholder — ciclo completo de controle virá na próxima etapa
        executor.execute {
            try {
                val system = """
                    Você é a Lua, assistente que controla um celular Android.
                    Responda de forma curta. Ainda estamos só testando a conexão.
                """.trimIndent()

                val body = JSONObject()
                    .put("model", "grok-3")
                    .put("max_tokens", 256)
                    .put(
                        "messages",
                        JSONArray()
                            .put(JSONObject().put("role", "system").put("content", system))
                            .put(JSONObject().put("role", "user").put("content", "Comando do usuário: $comando\n\nContexto da tela:\n$contextoTela"))
                    )

                val conn = (URL("https://api.x.ai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json")
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

                if (code !in 200..299) {
                    main.post { callback(ResultadoAcao(false, erro = "HTTP $code: ${raw.take(200)}")) }
                    return@execute
                }
                val json = JSONObject(raw)
                val texto = json.optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()
                    .orEmpty()
                main.post { callback(ResultadoAcao(true, texto = texto.ifEmpty { raw.take(300) })) }
            } catch (e: Exception) {
                main.post { callback(ResultadoAcao(false, erro = e.message ?: "erro")) }
            }
        }
    }
}

/** Fábrica simples — facilita trocar de provedor depois. */
object FabricaIA {
    fun criar(provedor: String): ModeloIA = when (provedor) {
        ConfigIA.PROVEDOR_GROK -> GrokProvedor()
        else -> GrokProvedor() // default
    }
}
