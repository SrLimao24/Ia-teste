package br.app.ajudantetela

import android.os.Handler
import android.os.Looper
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/**
 * Grok / xAI — OpenAI-compatible chat completions.
 * Auth: Authorization: Bearer <key>
 * URL: https://api.x.ai/v1/chat/completions
 */
class GrokProvedor : ModeloIA {
    override val id = ConfigIA.PROVEDOR_GROK
    override val nome = "Grok (xAI)"

    private val modelo = "grok-3"
    private val executor = Executors.newSingleThreadExecutor()
    private val main = Handler(Looper.getMainLooper())

    override fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit) {
        if (apiKey.isBlank()) {
            callback(ResultadoTeste(false, "Chave da API vazia.", TipoErroIA.CONFIGURACAO))
            return
        }
        executor.execute {
            try {
                val body = JSONObject()
                    .put("model", modelo)
                    .put("max_tokens", 16)
                    .put(
                        "messages",
                        JSONArray().put(
                            JSONObject().put("role", "user").put("content", "Responda apenas: ok")
                        )
                    )

                val conn = (URL("https://api.x.ai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json")
                    setRequestProperty("Accept", "application/json")
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }

                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""
                main.post { callback(interpretar(code, raw)) }
            } catch (e: Exception) {
                main.post {
                    callback(
                        ResultadoTeste(
                            false,
                            "Problema de internet: ${e.message ?: e.javaClass.simpleName}",
                            TipoErroIA.REDE
                        )
                    )
                }
            }
        }
    }

    override fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    ) {
        executor.execute {
            try {
                val body = JSONObject()
                    .put("model", modelo)
                    .put("max_tokens", 256)
                    .put(
                        "messages",
                        JSONArray()
                            .put(
                                JSONObject().put("role", "system").put(
                                    "content",
                                    "Você é a Lua, assistente que controla um celular Android. Responda de forma curta."
                                )
                            )
                            .put(
                                JSONObject().put("role", "user").put(
                                    "content",
                                    "Comando: $comando\n\nTela:\n$contextoTela"
                                )
                            )
                    )

                val conn = (URL("https://api.x.ai/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 45000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $apiKey")
                    setRequestProperty("Content-Type", "application/json")
                }
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body.toString()) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.let { BufferedReader(InputStreamReader(it, Charsets.UTF_8)).readText() } ?: ""

                if (code !in 200..299) {
                    val t = interpretar(code, raw)
                    main.post { callback(ResultadoAcao(false, erro = t.mensagem, tipo = t.tipo)) }
                    return@execute
                }
                val texto = JSONObject(raw)
                    .optJSONArray("choices")
                    ?.optJSONObject(0)
                    ?.optJSONObject("message")
                    ?.optString("content")
                    ?.trim()
                    .orEmpty()
                main.post {
                    if (texto.isEmpty())
                        callback(ResultadoAcao(false, erro = "Resposta inesperada da xAI.", tipo = TipoErroIA.RESPOSTA_INESPERADA))
                    else
                        callback(ResultadoAcao(true, texto = texto))
                }
            } catch (e: Exception) {
                main.post {
                    callback(ResultadoAcao(false, erro = "Rede: ${e.message}", tipo = TipoErroIA.REDE))
                }
            }
        }
    }

    private fun interpretar(code: Int, raw: String): ResultadoTeste {
        val lower = raw.lowercase()
        return when {
            code in 200..299 -> ResultadoTeste(true, "Conectado ✓ (Grok/xAI / HTTP $code)")
            code == 400 && (lower.contains("incorrect api key") || lower.contains("invalid")) ->
                ResultadoTeste(false, "Chave inválida para xAI (não use chave de outro provedor).", TipoErroIA.CHAVE_INVALIDA)
            code == 401 || code == 403 ->
                ResultadoTeste(false, "Chave inválida ou sem permissão (HTTP $code).", TipoErroIA.CHAVE_INVALIDA)
            code == 404 ->
                ResultadoTeste(false, "Modelo inexistente ($modelo).", TipoErroIA.MODELO_INEXISTENTE)
            code == 429 ->
                ResultadoTeste(false, "Limite/quota atingido (HTTP 429).", TipoErroIA.QUOTA)
            else ->
                ResultadoTeste(false, "Falha HTTP $code: ${raw.take(140)}", TipoErroIA.OUTRO)
        }
    }
}
