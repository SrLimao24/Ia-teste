package br.app.ajudantetela

/**
 * Contrato abstrato de provedor de IA.
 * Grok, OpenAI, Claude etc. implementam esta interface.
 */
interface ModeloIA {
    val nome: String

    /** Chamada mínima para validar chave + rede. */
    fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit)

    /**
     * Futuro: envia o contexto da tarefa e recebe uma ação estruturada.
     * Ainda não usado no ciclo de controle do celular.
     */
    fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    )
}

data class ResultadoTeste(
    val ok: Boolean,
    val mensagem: String
)

data class ResultadoAcao(
    val ok: Boolean,
    val texto: String = "",
    val erro: String = ""
)
