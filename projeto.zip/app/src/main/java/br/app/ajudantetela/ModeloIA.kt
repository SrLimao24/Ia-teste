package br.app.ajudantetela

/**
 * Contrato de provedor de IA.
 * Cada implementação usa endpoint, auth e formato próprios.
 */
interface ModeloIA {
    val id: String
    val nome: String

    fun testarConexao(apiKey: String, callback: (ResultadoTeste) -> Unit)

    fun pedirAcao(
        apiKey: String,
        comando: String,
        contextoTela: String,
        callback: (ResultadoAcao) -> Unit
    )
}

enum class TipoErroIA {
    NENHUM,
    CHAVE_INVALIDA,
    MODELO_INEXISTENTE,
    QUOTA,
    REDE,
    CONFIGURACAO,
    RESPOSTA_INESPERADA,
    OUTRO
}

data class ResultadoTeste(
    val ok: Boolean,
    val mensagem: String,
    val tipo: TipoErroIA = if (ok) TipoErroIA.NENHUM else TipoErroIA.OUTRO
)

data class ResultadoAcao(
    val ok: Boolean,
    val texto: String = "",
    val erro: String = "",
    val tipo: TipoErroIA = if (ok) TipoErroIA.NENHUM else TipoErroIA.OUTRO
)
