package br.app.ajudantetela

import android.content.ComponentName
import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * Botão flutuante (✦) com menu de ações:
 * traduzir a tela, voltar/início/recentes/notificações, rolar, print e digitar textos salvos.
 * Tudo roda no aparelho.
 */
class TelaService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var botao: OlhoView? = null
    private var menu: View? = null          // pode ser LinearLayout ou FrameLayout radial
    private var painel: LinearLayout? = null
    private var painelTexto: TextView? = null
    private var ultimoResultado = ""
    private var ocupado = false
    private var botaoLp: WindowManager.LayoutParams? = null

    // ----- Modo Ensinar Lua -----
    private var ensinando = false
    private var nomeHabilidade = ""
    private val passosAprendidos = mutableListOf<Habilidades.Passo>()
    private var ultimoEvento = ""

    // ----- Execução de habilidades -----
    private var executando = false
    private var execucaoCancelada = false
    private var passosEmExecucao: List<Habilidades.Passo> = emptyList()
    private var indiceExecucao = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        criarBotao()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!ensinando || event == null) return
        val pacote = event.packageName?.toString() ?: return
        if (pacote == packageName) return

        val fonte = event.source ?: return
        if (!fonte.isVisibleToUser || fonte.isPassword) return

        val tipo = when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> "tap"
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> "long_press"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> "type"
            else -> return
        }

        val r = Rect()
        fonte.getBoundsInScreen(r)
        val texto = fonte.text?.toString()?.trim().orEmpty()
        val descricao = fonte.contentDescription?.toString()?.trim().orEmpty()
        val classe = fonte.className?.toString().orEmpty()
        val assinatura = "$tipo|$pacote|$texto|$descricao|$classe|${r.left},${r.top},${r.right},${r.bottom}"
        if (assinatura == ultimoEvento) return
        ultimoEvento = assinatura

        // Em texto digitado, não guardamos o conteúdo real. A habilidade
        // futura poderá tratar o campo como variável {texto}.
        passosAprendidos.add(
            Habilidades.Passo(
                acao = tipo,
                app = pacote,
                texto = if (tipo == "type") "" else texto,
                descricao = descricao,
                classe = classe,
                esquerda = r.left, topo = r.top,
                direita = r.right, baixo = r.bottom
            )
        )
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removerTudo()
        super.onDestroy()
    }

    // ---------- Botão flutuante (Olho da Lua) ----------

    private fun criarBotao() {
        if (botao != null) return
        val b = OlhoView(this).apply {
            estado = OlhoView.Estado.NORMAL
        }
        val tamanho = dp(64)
        val lp = WindowManager.LayoutParams(
            tamanho, tamanho,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(280)
        }
        botaoLp = lp

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moveu = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moveu = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moveu = true
                    if (moveu && menu == null) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moveu) aoToque()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, lp)
        botao = b
    }

    private fun aoToque() {
        if (executando) {
            pararExecucao("Execução interrompida pelo usuário")
            return
        }
        if (menu != null) fecharMenu() else abrirMenu()
    }

    // ---------- Menu Radial (Prime Lua) ----------

    private fun abrirMenu() {
        if (menu != null) return
        val comandos = listOf(
            Triple("Traduzir", "#00E5FF") { aoTraduzir() },
            Triple(if (ensinando) "Parar" else "Ensinar", "#7B5CFF") {
                if (ensinando) pararEnsino() else iniciarEnsino()
            },
            Triple("Habilidades", "#FF8A00") { abrirHabilidades() },
            Triple("Textos", "#1B6E8A") { abrirTextos() },
            Triple("IA", "#FF2A4A") { abrirConfigIA() },
            Triple("Voltar", "#28404B") { global(GLOBAL_ACTION_BACK) },
            Triple("Início", "#28404B") { global(GLOBAL_ACTION_HOME) },
            Triple("Recentes", "#28404B") { global(GLOBAL_ACTION_RECENTS) },
            Triple("Notif.", "#28404B") { global(GLOBAL_ACTION_NOTIFICATIONS) },
            Triple("Subir", "#28404B") { rolar(false) },
            Triple("Descer", "#28404B") { rolar(true) },
            Triple("Print", "#28404B") { tirarPrint() }
        )
        mostrarMenuRadial(comandos)
    }

    private fun mostrarMenuRadial(itens: List<Triple<String, String, () -> Unit>>) {
        fecharMenu()
        val b = botao ?: return
        val lpBotao = botaoLp ?: return

        // Container maior para caber campo de comando + radial
        val largura = dp(320)
        val altura = dp(420)
        val diametro = dp(280)
        val raio = diametro / 2f
        val itemSize = dp(48)

        val container = FrameLayout(this)

        // ---- Campo de comando (topo) ----
        val barraComando = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#E60A0A12"))
                setStroke(dp(1), Color.parseColor("#44FF6A1A"))
            }
        }

        val campoComando = EditText(this).apply {
            hint = "O que você quer que eu faça?"
            textSize = 14f
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#6A7A85"))
            setBackgroundColor(Color.parseColor("#1A2228"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setSingleLine(false)
            maxLines = 3
            minLines = 1
            // evita que o teclado feche o overlay de forma estranha
            isFocusable = true
            isFocusableInTouchMode = true
        }

        val btnExecutar = TextView(this).apply {
            text = "▶  Executar"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor("#FF6A1A"))
            }
            setOnClickListener {
                val cmd = campoComando.text?.toString()?.trim().orEmpty()
                if (cmd.isEmpty()) {
                    aviso("Digite um comando primeiro.")
                    return@setOnClickListener
                }
                confirmarEExecutarComando(cmd)
            }
        }

        barraComando.addView(
            campoComando,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        )
        barraComando.addView(
            btnExecutar,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )

        val lpBarra = FrameLayout.LayoutParams(
            largura - dp(16),
            FrameLayout.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            topMargin = dp(4)
        }
        container.addView(barraComando, lpBarra)

        // ---- Área radial (abaixo do campo) ----
        val radial = FrameLayout(this)
        val fundo = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#CC0A0A12"))
                setStroke(dp(1), Color.parseColor("#33FF6A1A"))
            }
        }
        radial.addView(fundo, FrameLayout.LayoutParams(diametro, diametro))

        val n = itens.size
        val anguloInicial = -90.0
        for (i in itens.indices) {
            val (rotulo, cor, acao) = itens[i]
            val angulo = Math.toRadians(anguloInicial + i * (360.0 / n))
            val cx = raio + (raio * 0.72f * kotlin.math.cos(angulo)).toFloat() - itemSize / 2
            val cy = raio + (raio * 0.72f * kotlin.math.sin(angulo)).toFloat() - itemSize / 2

            val item = TextView(this).apply {
                text = rotulo
                textSize = 10f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#E616252D"))
                    setStroke(dp(1), Color.parseColor(cor))
                }
                alpha = 0f
                scaleX = 0.3f
                scaleY = 0.3f
                setOnClickListener {
                    fecharMenu()
                    acao()
                }
            }
            val ilp = FrameLayout.LayoutParams(itemSize, itemSize).apply {
                leftMargin = cx.toInt()
                topMargin = cy.toInt()
            }
            radial.addView(item, ilp)
            item.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setStartDelay((i * 25).toLong())
                .setDuration(200)
                .start()
        }

        val lpRadial = FrameLayout.LayoutParams(diametro, diametro).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            bottomMargin = dp(4)
        }
        container.addView(radial, lpRadial)

        // Posicionar o container centrado no olho (um pouco mais acima para caber o campo)
        val centroX = lpBotao.x + (botao?.width ?: dp(64)) / 2
        val centroY = lpBotao.y + (botao?.height ?: dp(64)) / 2

        val lp = WindowManager.LayoutParams(
            largura, altura,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            // NOT_TOUCH_MODAL permite digitação no EditText
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (centroX - largura / 2).coerceAtLeast(0)
            y = (centroY - altura + diametro / 2).coerceAtLeast(0)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        botao?.estado = OlhoView.Estado.ABERTO
        wm.addView(container, lp)
        menu = container

        // Foco no campo após um instante
        main.postDelayed({
            try {
                campoComando.requestFocus()
            } catch (_: Exception) {}
        }, 200)
    }

    /** Confirmação obrigatória antes de processar o comando do usuário. */
    private fun confirmarEExecutarComando(comando: String) {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#FF6A1A"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Confirmar comando"
            textSize = 15f
            setTextColor(Color.parseColor("#FF8A00"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "« $comando »"
            textSize = 14f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(12))
        })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnCancelar = botaoTexto("Cancelar", "#28404B") {
            fecharPainel()
        }
        val btnConfirmar = botaoTexto("Confirmar", "#FF6A1A") {
            fecharPainel()
            processarComandoUsuario(comando)
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnCancelar, pesoLp())
        linha.addView(btnConfirmar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(32),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        wm.addView(raiz, lp)
        painel = raiz
    }

    /**
     * Entrada do ciclo futuro de IA.
     * Por enquanto apenas registra o comando e avisa — a integração com
     * Claude/OpenAI/Grok será o próximo passo.
     */
    // ---------- Configuração de IA ----------

    private fun abrirConfigIA() {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#FF2A4A"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "🌙 Inteligência Artificial"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(8))
        })

        raiz.addView(TextView(this).apply {
            text = "Provedor"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val provedorAtual = ConfigIA.provedor(this)
        raiz.addView(TextView(this).apply {
            text = ConfigIA.nomeProvedor(provedorAtual)
            textSize = 14f
            setTextColor(Color.parseColor("#FF8A00"))
            setPadding(0, dp(2), 0, dp(4))
        })

        val modeloSalvo = ConfigIA.modelo(this, provedorAtual)
        val labelModelo = TextView(this).apply {
            text = if (modeloSalvo.isNotEmpty()) "Modelo: $modeloSalvo"
            else "Modelo: (teste a conexão para detectar)"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(6))
        }
        raiz.addView(labelModelo)

        // Troca de provedor
        val linhaProv = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun botaoProv(id: String, rotulo: String): TextView {
            val ativo = ConfigIA.provedor(this@TelaService) == id
            return botaoTexto(rotulo, if (ativo) "#FF6A1A" else "#28404B") {
                ConfigIA.salvarProvedor(this@TelaService, id)
                fecharPainel()
                abrirConfigIA()
            }
        }
        val pesoP = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
        }
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_GEMINI, "Gemini"), pesoP())
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_GROK, "Grok"), pesoP())
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_OPENAI, "OpenAI"), pesoP())
        raiz.addView(linhaProv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        // Chave
        raiz.addView(TextView(this).apply {
            text = "Chave da API (${ConfigIA.nomeProvedor(ConfigIA.provedor(this@TelaService))})"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val campoKey = EditText(this).apply {
            hint = "Cole a chave deste provedor (só no aparelho)"
            textSize = 13f
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            setBackgroundColor(Color.parseColor("#0F1A20"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            val salva = ConfigIA.apiKey(this@TelaService)
            if (salva.isNotEmpty()) setText(salva)
        }
        raiz.addView(
            campoKey,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8); topMargin = dp(4) }
        )

        // Lista de modelos (preenchida após listar/testar)
        val areaModelos = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (provedorAtual == ConfigIA.PROVEDOR_GEMINI) android.view.View.VISIBLE
            else android.view.View.GONE
        }
        raiz.addView(areaModelos)

        val statusTxt = TextView(this).apply {
            text = "Status: ${ConfigIA.ultimoStatus(this@TelaService)}"
            textSize = 13f
            setTextColor(
                if (ConfigIA.ultimoStatus(this@TelaService).startsWith("Conectado"))
                    Color.parseColor("#4CAF50")
                else Color.parseColor("#97AAB3")
            )
            setPadding(0, dp(4), 0, dp(10))
        }
        raiz.addView(statusTxt)

        fun preencherModelos(lista: List<String>, selecionado: String) {
            areaModelos.removeAllViews()
            if (lista.isEmpty()) return
            areaModelos.addView(TextView(this@TelaService).apply {
                text = "Modelos (toque para escolher)"
                textSize = 12f
                setTextColor(Color.parseColor("#97AAB3"))
                setPadding(0, 0, 0, dp(4))
            })
            // Mostra até 8 melhores
            lista.take(8).forEach { nomeMod ->
                val ativo = nomeMod == selecionado
                val btn = botaoTexto(
                    if (ativo) "● $nomeMod" else nomeMod,
                    if (ativo) "#FF6A1A" else "#28404B"
                ) {
                    ConfigIA.salvarModelo(this@TelaService, ConfigIA.PROVEDOR_GEMINI, nomeMod)
                    labelModelo.text = "Modelo: $nomeMod"
                    // re-destaca
                    preencherModelos(lista, nomeMod)
                    aviso("Modelo selecionado: $nomeMod")
                }
                areaModelos.addView(
                    btn,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(4) }
                )
            }
        }

        val linha1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnSalvar = botaoTexto("Salvar chave", "#1B6E8A") {
            val k = campoKey.text?.toString()?.trim().orEmpty()
            val p = ConfigIA.provedor(this@TelaService)
            ConfigIA.salvarApiKey(this@TelaService, p, k)
            aviso(if (k.isEmpty()) "Chave removida" else "Chave salva para ${ConfigIA.nomeProvedor(p)}")
        }
        val btnTestar = botaoTexto("Testar conexão", "#FF6A1A") {
            val k = campoKey.text?.toString()?.trim().orEmpty()
            if (k.isEmpty()) {
                aviso("Cole a chave deste provedor primeiro.")
                return@botaoTexto
            }
            val p = ConfigIA.provedor(this@TelaService)
            ConfigIA.salvarApiKey(this@TelaService, p, k)
            statusTxt.text = "Status: testando ${ConfigIA.nomeProvedor(p)}…"
            statusTxt.setTextColor(Color.parseColor("#FF8A00"))

            val modeloIA = FabricaIA.criar(p)
            // Se Gemini e usuário já escolheu um modelo, testa só ele primeiro
            if (modeloIA is GeminiProvedor) {
                val escolhidoUi = ConfigIA.modelo(this@TelaService, p)
                if (escolhidoUi.isNotEmpty()) {
                    modeloIA.definirModelo(escolhidoUi)
                }
            }
            modeloIA.testarConexao(k) { r ->
                ConfigIA.salvarStatus(
                    this@TelaService,
                    if (r.ok) "Conectado" else "Não conectado"
                )
                if (modeloIA is GeminiProvedor) {
                    if (modeloIA.modeloSelecionado.isNotEmpty()) {
                        ConfigIA.salvarModelo(this@TelaService, p, modeloIA.modeloSelecionado)
                        labelModelo.text = "Modelo: ${modeloIA.modeloSelecionado}"
                    }
                    if (modeloIA.modelosDisponiveis.isNotEmpty()) {
                        preencherModelos(
                            modeloIA.modelosDisponiveis,
                            modeloIA.modeloSelecionado.ifEmpty { ConfigIA.modelo(this@TelaService, p) }
                        )
                    }
                }
                statusTxt.text = "Status: ${r.mensagem}"
                statusTxt.setTextColor(
                    if (r.ok) Color.parseColor("#4CAF50") else Color.parseColor("#FF2A4A")
                )
                aviso(r.mensagem.take(80))
            }
        }
        val peso = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha1.addView(btnSalvar, peso())
        linha1.addView(btnTestar, peso())
        raiz.addView(linha1)

        raiz.addView(botaoTexto("Fechar", "#28404B") { fecharMenu() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        })

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(raiz)
        }
        val scroll = rolagemLimitada(0.75)
        scroll.addView(outer)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(28),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(scroll, lp)
        menu = scroll
        painel = null
        main.postDelayed({ campoKey.requestFocus() }, 200)
    }

    private fun processarComandoUsuario(comando: String) {
        if (executando || ensinando) {
            aviso("Aguarde a operação atual terminar.")
            return
        }
        if (!ConfigIA.temChave(this)) {
            aviso("Configure a chave da IA primeiro (menu → IA).")
            abrirConfigIA()
            return
        }
        aviso("Consultando a IA…")
        botao?.estado = OlhoView.Estado.EXECUTANDO

        val chave = ConfigIA.apiKey(this)
        val provedor = ConfigIA.provedor(this)
        val modelo = FabricaIA.criar(provedor)

        // Contexto mínimo da tela atual
        val pacoteAtual = rootInActiveWindow?.packageName?.toString() ?: ""
        val contexto = "App em primeiro plano: $pacoteAtual"

        modelo.pedirAcao(chave, comando, contexto) { resultado ->
            if (!resultado.ok) {
                botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
                abrirPainel("A IA falhou:\n\n${resultado.erro}")
                return@pedirAcao
            }
            val acao = InterpreteAcao.parse(resultado.texto)
            if (acao == null) {
                botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
                abrirPainel(
                    "A IA respondeu, mas não em JSON estruturado:\n\n${resultado.texto.take(500)}"
                )
                return@pedirAcao
            }
            executarAcaoIA(acao, comando, resultado.texto)
        }
    }

    /**
     * Ciclo mínimo: interpreta a ação estruturada e executa no aparelho.
     * v1 suporta principalmente abrir_app.
     */
    private fun executarAcaoIA(acao: AcaoIA, comandoOriginal: String, bruto: String) {
        when (acao.tipo) {
            "abrir_app", "open_app", "abrir", "open" -> {
                val alvo = acao.pacote.ifEmpty { acao.app }
                val pacote = InterpreteAcao.resolverPacote(alvo) ?: alvo
                if (pacote.isBlank()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("A IA não informou qual app abrir.\n\n$bruto")
                    return
                }
                val ok = abrirAplicativo(pacote)
                botao?.estado = OlhoView.Estado.NORMAL
                if (ok) {
                    aviso("Abrindo $pacote…")
                    main.postDelayed({
                        abrirPainel(
                            "Comando: $comandoOriginal\n\n" +
                            "Ação: abrir_app\n" +
                            "Pacote: $pacote\n\n" +
                            "✓ Executado"
                        )
                    }, 600)
                } else {
                    abrirPainel(
                        "Não consegui abrir o app.\n" +
                        "Pacote tentado: $pacote\n\n" +
                        "Verifique se o aplicativo está instalado."
                    )
                }
            }
            "dizer", "falar", "info", "mensagem" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel(acao.texto.ifEmpty { acao.motivo }.ifEmpty { bruto })
            }
            "concluir", "ok", "done" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                aviso(acao.motivo.ifEmpty { "Concluído" })
            }
            "erro", "error" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel("A IA reportou erro:\n\n${acao.motivo.ifEmpty { bruto }}")
            }
            else -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel(
                    "Ação ainda não suportada: ${acao.tipo}\n\n" +
                    "Resposta da IA:\n${bruto.take(400)}\n\n" +
                    "Neste ciclo mínimo só executo abrir_app."
                )
            }
        }
    }

    private fun abrirAplicativo(pacote: String): Boolean {
        return try {
            val launch = packageManager.getLaunchIntentForPackage(pacote)
            if (launch == null) {
                // tenta busca parcial entre apps instalados
                val apps = packageManager.getInstalledApplications(0)
                val match = apps.firstOrNull {
                    it.packageName.equals(pacote, true) ||
                        it.packageName.contains(pacote, true)
                }
                if (match != null) {
                    val i = packageManager.getLaunchIntentForPackage(match.packageName) ?: return false
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(i)
                    true
                } else false
            } else {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                true
            }
        } catch (e: Exception) {
            aviso("Erro ao abrir app: ${e.message}")
            false
        }
    }


    // Mantém a API antiga usada por Habilidades e Textos (lista vertical)
    private fun mostrarMenu(titulo: String, itens: List<Triple<String, String, () -> Unit>>) {
        fecharMenu()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(6), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        raiz.addView(TextView(this).apply {
            text = titulo
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val conteudo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var i = 0
        while (i < itens.size) {
            val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0 until 2) {
                if (i + j >= itens.size) break
                val (rotulo, cor, acao) = itens[i + j]
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(8)
                }
                linha.addView(botaoTexto(rotulo, cor, acao), lp)
            }
            conteudo.addView(linha)
            i += 2
        }
        val rolagem = rolagemLimitada(0.55)
        rolagem.addView(conteudo)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        menu = raiz
        botao?.estado = OlhoView.Estado.ABERTO
    }

    private fun fecharMenu() {
        menu?.let { v ->
            try {
                // animação rápida de saída
                v.animate().alpha(0f).setDuration(150).withEndAction {
                    try { wm.removeView(v) } catch (_: Exception) {}
                }.start()
            } catch (_: Exception) {
                try { wm.removeView(v) } catch (_: Exception) {}
            }
        }
        menu = null
        // Restaura estado visual do olho
        botao?.estado = when {
            executando -> OlhoView.Estado.EXECUTANDO
            ensinando -> OlhoView.Estado.ENSINANDO
            else -> OlhoView.Estado.NORMAL
        }
    }

    private fun iniciarEnsino() {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Ensinar Lua"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "Dê um nome para a habilidade. Depois faça a tarefa normalmente. A Lua vai registrar cliques e campos de texto."
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(10))
        })

        val campo = EditText(this).apply {
            hint = "Ex.: enviar mensagem"
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            setBackgroundColor(Color.parseColor("#0F1A20"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        raiz.addView(campo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnCancelar = botaoTexto("Cancelar", "#28404B") {
            fecharPainel()
        }
        val btnComecar = botaoTexto("Começar", "#1B6E8A") {
            val nome = campo.text.toString().trim()
            if (nome.isEmpty()) {
                aviso("Dê um nome para a habilidade.")
            } else {
                nomeHabilidade = nome
                passosAprendidos.clear()
                ultimoEvento = ""
                ensinando = true
                botao?.estado = OlhoView.Estado.ENSINANDO
                fecharPainel()
                aviso("Ensino iniciado. Faça a tarefa normalmente.")
            }
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnCancelar, pesoLp())
        linha.addView(btnComecar, pesoLp())
        raiz.addView(linha)

        // FLAG_NOT_TOUCH_MODAL permite digitação; removemos FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(raiz, lp)
        painel = raiz
        campo.requestFocus()
    }

    private fun pararEnsino() {
        fecharMenu()
        fecharPainel()
        ensinando = false
        ultimoEvento = ""
        val passos = passosAprendidos.toList()
        passosAprendidos.clear()

        if (passos.isEmpty()) {
            aviso("A Lua não registrou nenhuma ação.")
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            return
        }

        val nomeAtual = nomeHabilidade

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Salvar habilidade?"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "A Lua registrou ${passos.size} passos em \"$nomeAtual\".\nDeseja salvar para reutilizar depois?"
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(12))
        })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnDescartar = botaoTexto("Descartar", "#28404B") {
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            fecharPainel()
            aviso("Habilidade descartada")
        }
        val btnSalvar = botaoTexto("Salvar", "#1B6E8A") {
            Habilidades.adicionar(this@TelaService, Habilidades.Habilidade(nomeAtual, passos))
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            fecharPainel()
            aviso("Habilidade aprendida ✓")
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnDescartar, pesoLp())
        linha.addView(btnSalvar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
    }

    private fun abrirHabilidades() {
        val lista = Habilidades.ler(this)
        val itens = mutableListOf<Triple<String, String, () -> Unit>>()
        if (lista.isEmpty()) {
            itens.add(Triple("Nenhuma habilidade ainda", "#5A6D77") { abrirMenu() })
        } else {
            lista.forEach { h ->
                // Ação principal: executar
                itens.add(Triple("▶ ${h.nome} (${h.passos.size} passos)", "#1B6E8A") {
                    iniciarExecucao(h)
                })
                // Detalhes (opcional)
                itens.add(Triple("   ver passos de ${h.nome}", "#5A6D77") {
                    mostrarHabilidade(h)
                })
            }
            itens.add(Triple("◀ Menu", "#5A6D77") { abrirMenu() })
        }
        mostrarMenu("Habilidades aprendidas", itens)
    }

    private fun mostrarHabilidade(h: Habilidades.Habilidade) {
        val resumo = buildString {
            append(h.nome).append("\n\n")
            h.passos.forEachIndexed { i, p ->
                val alvo = p.texto.ifEmpty { p.descricao.ifEmpty { p.classe } }
                append(i + 1).append(". ").append(p.acao)
                if (alvo.isNotEmpty()) append(" → ").append(alvo)
                append("\n")
            }
        }
        fecharMenu()
        abrirPainel(resumo.trim())
    }

    // ---------- Executor de habilidades (local, sem IA) ----------

    private fun iniciarExecucao(h: Habilidades.Habilidade) {
        if (executando || ensinando) {
            aviso("Aguarde a operação atual terminar.")
            return
        }
        if (h.passos.isEmpty()) {
            aviso("Essa habilidade não tem passos.")
            return
        }
        fecharMenu()
        fecharPainel()
        executando = true
        execucaoCancelada = false
        passosEmExecucao = h.passos
        indiceExecucao = 0
        botao?.estado = OlhoView.Estado.EXECUTANDO
        aviso("Executando: ${h.nome}")
        // Pequeno atraso para o menu sumir e a tela estabilizar
        main.postDelayed({ executarProximoPasso() }, 600)
    }

    private fun pararExecucao(motivo: String = "Execução interrompida") {
        executando = false
        execucaoCancelada = true
        passosEmExecucao = emptyList()
        indiceExecucao = 0
        botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
        aviso(motivo)
    }

    private fun executarProximoPasso() {
        if (!executando || execucaoCancelada) return

        if (indiceExecucao >= passosEmExecucao.size) {
            executando = false
            botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
            aviso("Habilidade concluída ✓")
            return
        }

        val passo = passosEmExecucao[indiceExecucao]
        val ok = executarPasso(passo)
        indiceExecucao++

        if (!ok) {
            // Continua mesmo assim (versão 1 é tolerante). Depois podemos parar em falha.
        }

        // Próximo passo após um intervalo
        main.postDelayed({ executarProximoPasso() }, 900)
    }

    private fun executarPasso(passo: Habilidades.Passo): Boolean {
        return when (passo.acao) {
            "tap" -> {
                val no = encontrarNo(passo)
                if (no != null) {
                    val r = Rect()
                    no.getBoundsInScreen(r)
                    // Tenta performAction primeiro; se falhar, tenta clique por gesto simples via centro
                    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        true
                    } else {
                        // fallback: alguns nós não respondem a ACTION_CLICK
                        no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                        false
                    }
                } else {
                    aviso("Não encontrei o alvo do toque")
                    false
                }
            }
            "long_press" -> {
                val no = encontrarNo(passo)
                if (no != null && no.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                    true
                } else {
                    aviso("Não encontrei o alvo do toque longo")
                    false
                }
            }
            "type" -> {
                // Por enquanto o texto gravado está vazio (decisão de privacidade).
                // Apenas tenta focar um campo editável.
                val no = encontrarNoEditavel(passo)
                if (no != null) {
                    no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    true
                } else {
                    false
                }
            }
            else -> false
        }
    }

    /** Procura um nó que combine com o passo gravado. */
    private fun encontrarNo(passo: Habilidades.Passo): AccessibilityNodeInfo? {
        val raiz = rootInActiveWindow ?: return null
        val candidatos = mutableListOf<AccessibilityNodeInfo>()
        coletarNos(raiz, candidatos, 0)

        // 1) Texto exato (se houver)
        if (passo.texto.isNotEmpty()) {
            candidatos.firstOrNull {
                it.isVisibleToUser && (it.text?.toString()?.trim() == passo.texto)
            }?.let { return it }
        }

        // 2) Content description
        if (passo.descricao.isNotEmpty()) {
            candidatos.firstOrNull {
                it.isVisibleToUser && (it.contentDescription?.toString()?.trim() == passo.descricao)
            }?.let { return it }
        }

        // 3) Classe + bounds aproximados
        if (passo.classe.isNotEmpty()) {
            val centroX = (passo.esquerda + passo.direita) / 2
            val centroY = (passo.topo + passo.baixo) / 2
            candidatos
                .filter { it.isVisibleToUser && it.className?.toString() == passo.classe }
                .minByOrNull {
                    val r = Rect()
                    it.getBoundsInScreen(r)
                    val cx = (r.left + r.right) / 2
                    val cy = (r.top + r.bottom) / 2
                    (cx - centroX).toLong() * (cx - centroX) + (cy - centroY).toLong() * (cy - centroY)
                }?.let { return it }
        }

        // 4) Qualquer nó clicável com texto/descrição parecidos
        return candidatos.firstOrNull {
            it.isVisibleToUser && it.isClickable &&
                (passo.texto.isNotEmpty() && it.text?.toString()?.contains(passo.texto) == true ||
                 passo.descricao.isNotEmpty() && it.contentDescription?.toString()?.contains(passo.descricao) == true)
        }
    }

    private fun encontrarNoEditavel(passo: Habilidades.Passo): AccessibilityNodeInfo? {
        val raiz = rootInActiveWindow ?: return null
        val candidatos = mutableListOf<AccessibilityNodeInfo>()
        coletarNos(raiz, candidatos, 0)

        // Preferência: campo já focado
        candidatos.firstOrNull { it.isFocused && it.isEditable && it.isVisibleToUser }?.let { return it }

        // Depois: qualquer EditText visível
        return candidatos.firstOrNull {
            it.isVisibleToUser && it.isEditable &&
                (it.className?.toString()?.contains("EditText") == true ||
                 it.className?.toString()?.contains("TextField") == true)
        }
    }

    private fun coletarNos(n: AccessibilityNodeInfo?, saida: MutableList<AccessibilityNodeInfo>, prof: Int) {
        if (n == null || prof > 45) return
        saida.add(n)
        for (i in 0 until n.childCount) {
            coletarNos(n.getChild(i), saida, prof + 1)
        }
    }

    private fun abrirTextos() {
        val lista = Textos.ler(this)
        val itens = mutableListOf<Triple<String, String, () -> Unit>>()
        lista.forEach { t ->
            val rotulo = if (t.length > 28) t.take(28).replace('\n', ' ') + "…" else t.replace('\n', ' ')
            itens.add(Triple(rotulo, "#1B6E8A") { digitar(t) })
        }
        itens.add(Triple("◀ Menu", "#5A6D77") { abrirMenu() })
        val titulo = if (lista.isEmpty()) "Nenhum texto salvo. Adicione no app." else "Toque num texto para digitar"
        mostrarMenu(titulo, itens)
    }

    // ---------- Ações ----------

    private fun global(acao: Int) {
        fecharMenu()
        main.postDelayed({ performGlobalAction(acao) }, 200)
    }

    private fun tirarPrint() {
        fecharMenu()
        botao?.visibility = View.INVISIBLE
        main.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            main.postDelayed({ botao?.visibility = View.VISIBLE }, 1500)
        }, 300)
    }

    private fun rolar(frente: Boolean) {
        fecharMenu()
        val raiz = rootInActiveWindow
        if (raiz == null) {
            aviso("Não consegui ler a tela.")
            return
        }
        val rolaveis = mutableListOf<AccessibilityNodeInfo>()
        acharRolaveis(raiz, rolaveis, 0)
        val alvo = rolaveis.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height().toLong()
        }
        val acao = if (frente) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (alvo == null || !alvo.performAction(acao)) aviso("Não há nada para rolar aqui.")
    }

    private fun acharRolaveis(n: AccessibilityNodeInfo?, saida: MutableList<AccessibilityNodeInfo>, prof: Int) {
        if (n == null || prof > 40) return
        if (n.isScrollable && n.isVisibleToUser) saida.add(n)
        for (i in 0 until n.childCount) acharRolaveis(n.getChild(i), saida, prof + 1)
    }

    private fun digitar(texto: String) {
        fecharMenu()
        val campo = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (campo == null || !campo.isEditable) {
            aviso("Toque primeiro num campo de texto e abra o menu de novo.")
            return
        }
        if (campo.isPassword) {
            aviso("Por segurança, não digito em campos de senha.")
            return
        }
        // Substitui o conteúdo atual (não concatena)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, texto)
        }
        if (!campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            aviso("Esse campo não aceitou o texto.")
        }
    }

    private fun aviso(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- Traduzir a tela ----------

    private fun aoTraduzir() {
        fecharMenu()
        if (ocupado) return
        ocupado = true
        abrirPainel("Lendo a tela…")

        val texto = lerArvore()
        if (texto.length >= 20) {
            processar(texto)
        } else {
            capturarEOcr()
        }
    }

    private fun lerArvore(): String {
        val raiz = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        percorrer(raiz, sb, 0)
        return sb.toString().trim()
    }

    private fun percorrer(n: AccessibilityNodeInfo?, sb: StringBuilder, prof: Int) {
        if (n == null || prof > 40 || sb.length > 6000) return
        if (n.isVisibleToUser && !n.isPassword) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append('\n')
        }
        for (i in 0 until n.childCount) percorrer(n.getChild(i), sb, prof + 1)
    }

    private fun capturarEOcr() {
        atualizarPainel("Lendo a imagem da tela…")
        botao?.visibility = View.INVISIBLE
        painel?.visibility = View.INVISIBLE
        main.postDelayed({
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                ContextCompat.getMainExecutor(this),
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val buffer = r.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, r.colorSpace)
                            ?.copy(Bitmap.Config.ARGB_8888, false)
                        buffer.close()
                        mostrarTudo()
                        if (bmp == null) {
                            falha("Não consegui capturar a tela.")
                        } else {
                            ocr(bmp)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        mostrarTudo()
                        falha("A captura de tela falhou (código $errorCode). Alguns apps bloqueiam captura.")
                    }
                }
            )
        }, 250)
    }

    private fun ocr(bmp: Bitmap) {
        val reconhecedor = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        reconhecedor.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val t = r.text.trim()
                if (t.isEmpty()) falha("Não encontrei texto na tela.") else processar(t)
            }
            .addOnFailureListener { falha("Erro ao ler a imagem.") }
    }

    private fun processar(texto: String) {
        atualizarPainel("Detectando o idioma…")
        LanguageIdentification.getClient().identifyLanguage(texto.take(500))
            .addOnSuccessListener { codigo ->
                if (codigo == "und") {
                    mostrarResultado(texto, "Não identifiquei o idioma. Texto lido:")
                } else if (codigo == "pt") {
                    mostrarResultado(texto, "Já está em português:")
                } else {
                    val origem = TranslateLanguage.fromLanguageTag(codigo)
                    if (origem == null) {
                        mostrarResultado(texto, "Idioma ($codigo) sem tradução offline. Texto lido:")
                    } else {
                        traduzir(texto, origem)
                    }
                }
            }
            .addOnFailureListener { falha("Erro ao detectar o idioma.") }
    }

    private fun traduzir(texto: String, origem: String) {
        atualizarPainel("Baixando o idioma (só na primeira vez)…")
        val tradutor = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(origem)
                .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                .build()
        )
        tradutor.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                atualizarPainel("Traduzindo…")
                val saida = StringBuilder()
                traduzirPartes(tradutor, dividir(texto), 0, saida) {
                    tradutor.close()
                    mostrarResultado(saida.toString().trim(), "Tradução:")
                }
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Não consegui baixar o idioma. Verifique a internet.")
            }
    }

    private fun dividir(texto: String): List<String> {
        val partes = mutableListOf<String>()
        var atual = StringBuilder()
        for (linha in texto.lines()) {
            if (atual.isNotEmpty() && atual.length + linha.length > 900) {
                partes.add(atual.toString())
                atual = StringBuilder()
            }
            atual.append(linha).append('\n')
        }
        if (atual.isNotEmpty()) partes.add(atual.toString())
        return partes
    }

    private fun traduzirPartes(
        tradutor: Translator,
        partes: List<String>,
        i: Int,
        saida: StringBuilder,
        fim: () -> Unit
    ) {
        if (i >= partes.size) {
            fim()
            return
        }
        tradutor.translate(partes[i])
            .addOnSuccessListener {
                saida.append(it).append('\n')
                traduzirPartes(tradutor, partes, i + 1, saida, fim)
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Erro ao traduzir.")
            }
    }

    // ---------- Painel de resultado ----------

    private fun abrirPainel(msg: String) {
        if (painel != null) {
            atualizarPainel(msg)
            painel?.visibility = View.VISIBLE
            return
        }
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        val texto = TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
        }
        val rolagem = rolagemLimitada(0.45)
        rolagem.addView(texto)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val copiar = botaoTexto("Copiar", "#1B6E8A") { copiarResultado() }
        val fechar = botaoTexto("Fechar", "#28404B") { fecharPainel() }
        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                topMargin = dp(12); marginEnd = dp(8)
            }
        }
        linha.addView(copiar, pesoLp())
        linha.addView(fechar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
        painelTexto = texto
    }

    private fun rolagemLimitada(fracao: Double): ScrollView {
        val limite = (resources.displayMetrics.heightPixels * fracao).toInt()
        return object : ScrollView(this@TelaService) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(limite, View.MeasureSpec.AT_MOST))
            }
        }
    }

    private fun botaoTexto(rotulo: String, cor: String, acao: () -> Unit): TextView {
        return TextView(this).apply {
            text = rotulo
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            maxLines = 2
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor(cor))
            }
            setOnClickListener { acao() }
        }
    }

    private fun atualizarPainel(msg: String) {
        painelTexto?.text = msg
    }

    private fun mostrarResultado(texto: String, titulo: String) {
        ultimoResultado = texto
        atualizarPainel("$titulo\n\n$texto")
        ocupado = false
    }

    private fun falha(msg: String) {
        atualizarPainel(msg)
        ocupado = false
    }

    private fun copiarResultado() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("tela", ultimoResultado))
        aviso("Copiado")
    }

    private fun fecharPainel() {
        painel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        painel = null
        painelTexto = null
        ocupado = false
    }

    private fun mostrarTudo() {
        botao?.visibility = View.VISIBLE
        painel?.visibility = View.VISIBLE
    }

    private fun removerTudo() {
        fecharMenu()
        fecharPainel()
        botao?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        botao = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
