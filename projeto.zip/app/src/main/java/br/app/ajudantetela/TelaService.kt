package br.app.ajudantetela

import android.content.ComponentName
import android.animation.ValueAnimator
import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.LinearInterpolator
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * Botão flutuante (✦) com menu de ações:
 * traduzir a tela, voltar/início/recentes/notificações, rolar, print e digitar textos salvos.
 * Tudo roda no aparelho.
 */
class TelaService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var botao: OlhoView? = null
    private var menu: View? = null          // pode ser LinearLayout ou FrameLayout radial
    private var painel: LinearLayout? = null
    private var painelTexto: TextView? = null
    private var ultimoResultado = ""
    private var ocupado = false
    private var botaoLp: WindowManager.LayoutParams? = null
    private var posBotaoAntesMenuX = 0
    private var posBotaoAntesMenuY = 0
    private var haloExecucao: View? = null
    private var animHolograma: ValueAnimator? = null
    private var hologramaView: ImageView? = null

    // ----- Modo Ensinar Lua -----
    private var ensinando = false
    private var nomeHabilidade = ""
    private val passosAprendidos = mutableListOf<Habilidades.Passo>()
    private var ultimoEvento = ""

    // ----- Execução de habilidades -----
    private var executando = false
    private var execucaoCancelada = false
    private var passosEmExecucao: List<Habilidades.Passo> = emptyList()
    private var indiceExecucao = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        criarBotao()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!ensinando || event == null) return
        val pacote = event.packageName?.toString() ?: return
        if (pacote == packageName) return

        val fonte = event.source ?: return
        if (!fonte.isVisibleToUser || fonte.isPassword) return

        val tipo = when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> "tap"
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> "long_press"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> "type"
            else -> return
        }

        val r = Rect()
        fonte.getBoundsInScreen(r)
        val texto = fonte.text?.toString()?.trim().orEmpty()
        val descricao = fonte.contentDescription?.toString()?.trim().orEmpty()
        val classe = fonte.className?.toString().orEmpty()
        val assinatura = "$tipo|$pacote|$texto|$descricao|$classe|${r.left},${r.top},${r.right},${r.bottom}"
        if (assinatura == ultimoEvento) return
        ultimoEvento = assinatura

        // Em texto digitado, não guardamos o conteúdo real. A habilidade
        // futura poderá tratar o campo como variável {texto}.
        passosAprendidos.add(
            Habilidades.Passo(
                acao = tipo,
                app = pacote,
                texto = if (tipo == "type") "" else texto,
                descricao = descricao,
                classe = classe,
                esquerda = r.left, topo = r.top,
                direita = r.right, baixo = r.bottom
            )
        )
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removerTudo()
        super.onDestroy()
    }

    // ---------- Botão flutuante (Olho da Lua) ----------

    private fun criarBotao() {
        if (botao != null) return
        val b = OlhoView(this).apply {
            estado = OlhoView.Estado.NORMAL
        }
        val tamanho = dp(64)
        val lp = WindowManager.LayoutParams(
            tamanho, tamanho,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(280)
        }
        botaoLp = lp

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moveu = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moveu = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moveu = true
                    if (moveu && menu == null) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moveu) aoToque()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, lp)
        botao = b
    }

    private fun aoToque() {
        if (executando) {
            pararExecucao("Execução interrompida pelo usuário")
            return
        }
        if (menu != null) fecharMenu() else abrirMenu()
    }

    // ---------- Menu Radial (Prime Lua) ----------

    private fun abrirMenu() {
        if (menu != null) return
        val comandos = listOf(
            Triple("Traduzir", "#00E5FF") { aoTraduzir() },
            Triple(if (ensinando) "Parar" else "Ensinar", "#7B5CFF") {
                if (ensinando) pararEnsino() else iniciarEnsino()
            },
            Triple("Habilidades", "#FF8A00") { abrirHabilidades() },
            Triple("Textos", "#1B6E8A") { abrirTextos() },
            Triple("IA", "#FF2A4A") { abrirConfigIA() },
            Triple("Voltar", "#28404B") { global(GLOBAL_ACTION_BACK) },
            Triple("Início", "#28404B") { global(GLOBAL_ACTION_HOME) },
            Triple("Recentes", "#28404B") { global(GLOBAL_ACTION_RECENTS) },
            Triple("Notif.", "#28404B") { global(GLOBAL_ACTION_NOTIFICATIONS) },
            Triple("Subir", "#28404B") { rolar(false) },
            Triple("Descer", "#28404B") { rolar(true) },
            Triple("Print", "#28404B") { tirarPrint() }
        )
        mostrarMenuRadial(comandos)
    }

    private fun mostrarMenuRadial(itens: List<Triple<String, String, () -> Unit>>) {
        fecharMenu()
        val b = botao ?: return
        val lpBotao = botaoLp ?: return

        // Tela do menu: holograma grande + órbita BEM aberta
        val largura = dp(340)
        val altura = dp(460)
        val diametro = dp(300)
        val raio = diametro / 2f
        val itemSize = dp(52)
        // Órbita externa: botões longe do centro (não colados)
        val fatorOrbita = 0.82f

        val container = FrameLayout(this)

        // Campo de comando no topo
        val barraComando = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#F0180C2E"))
                setStroke(dp(1), Color.parseColor("#99C77DFF"))
            }
        }
        val campoComando = EditText(this).apply {
            hint = "O que você quer que eu faça?"
            textSize = 14f
            setTextColor(Color.parseColor("#F5EDFF"))
            setHintTextColor(Color.parseColor("#9B8AB8"))
            setBackgroundColor(Color.parseColor("#1A0A2E"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            maxLines = 3
            isFocusable = true
            isFocusableInTouchMode = true
        }
        val btnExecutar = TextView(this).apply {
            text = "✦  Executar"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#7B5CFF"))
            }
            setOnClickListener {
                val cmd = campoComando.text?.toString()?.trim().orEmpty()
                if (cmd.isEmpty()) {
                    aviso("Digite um comando primeiro.")
                    return@setOnClickListener
                }
                confirmarEExecutarComando(cmd)
            }
        }
        barraComando.addView(
            campoComando,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        )
        barraComando.addView(
            btnExecutar,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        container.addView(
            barraComando,
            FrameLayout.LayoutParams(
                largura - dp(20),
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = dp(6)
            }
        )

        // Órbita ampla — anel fino + botões espaçados
        val radial = FrameLayout(this)
        val anel = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#220A0618"))
                setStroke(dp(1), Color.parseColor("#55E9D5FF"))
            }
        }
        radial.addView(anel, FrameLayout.LayoutParams(diametro, diametro))

        val n = itens.size.coerceAtLeast(1)
        val anguloInicial = -90.0
        for (i in itens.indices) {
            val (rotulo, _, acao) = itens[i]
            val angulo = Math.toRadians(anguloInicial + i * (360.0 / n))
            val cx = raio + (raio * fatorOrbita * kotlin.math.cos(angulo)).toFloat() - itemSize / 2
            val cy = raio + (raio * fatorOrbita * kotlin.math.sin(angulo)).toFloat() - itemSize / 2

            val item = TextView(this).apply {
                text = rotulo
                textSize = 10f
                setTextColor(Color.parseColor("#F8F0FF"))
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#F01A0A30"))
                    setStroke(dp(2), Color.parseColor("#C4B5FD"))
                }
                alpha = 0f
                scaleX = 0.2f
                scaleY = 0.2f
                setOnClickListener {
                    fecharMenu()
                    acao()
                }
            }
            radial.addView(
                item,
                FrameLayout.LayoutParams(itemSize, itemSize).apply {
                    leftMargin = cx.toInt()
                    topMargin = cy.toInt()
                }
            )
            item.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setStartDelay((i * 28).toLong())
                .setDuration(240)
                .start()
        }

        container.addView(
            radial,
            FrameLayout.LayoutParams(diametro, diametro).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(10)
            }
        )

        val lp = WindowManager.LayoutParams(
            largura, altura,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        posBotaoAntesMenuX = lpBotao.x
        posBotaoAntesMenuY = lpBotao.y
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val bw = botao?.width ?: dp(64)
        val bh = botao?.height ?: dp(64)
        // Núcleo no centro do carrossel (área inferior)
        lpBotao.x = (screenW - bw) / 2
        lpBotao.y = (screenH - bh) / 2 + dp(48)
        try { wm.updateViewLayout(b, lpBotao) } catch (_: Exception) {}

        botao?.estado = OlhoView.Estado.ABERTO
        wm.addView(container, lp)
        menu = container

        main.postDelayed({
            try { campoComando.requestFocus() } catch (_: Exception) {}
        }, 200)
    }

    /** Confirmação obrigatória antes de processar o comando do usuário. */
    private fun confirmarEExecutarComando(comando: String) {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#FF6A1A"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Confirmar comando"
            textSize = 15f
            setTextColor(Color.parseColor("#FF8A00"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "« $comando »"
            textSize = 14f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(12))
        })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnCancelar = botaoTexto("Cancelar", "#28404B") {
            fecharPainel()
        }
        val btnConfirmar = botaoTexto("Confirmar", "#FF6A1A") {
            fecharPainel()
            processarComandoUsuario(comando)
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnCancelar, pesoLp())
        linha.addView(btnConfirmar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(32),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        wm.addView(raiz, lp)
        painel = raiz
    }

    /**
     * Entrada do ciclo futuro de IA.
     * Por enquanto apenas registra o comando e avisa — a integração com
     * Claude/OpenAI/Grok será o próximo passo.
     */
    // ---------- Configuração de IA ----------

    private fun abrirConfigIA() {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#FF2A4A"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "🌙 Inteligência Artificial"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(8))
        })

        raiz.addView(TextView(this).apply {
            text = "Provedor"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val provedorAtual = ConfigIA.provedor(this)
        raiz.addView(TextView(this).apply {
            text = ConfigIA.nomeProvedor(provedorAtual)
            textSize = 14f
            setTextColor(Color.parseColor("#FF8A00"))
            setPadding(0, dp(2), 0, dp(4))
        })

        val modeloSalvo = ConfigIA.modelo(this, provedorAtual)
        val labelModelo = TextView(this).apply {
            text = if (modeloSalvo.isNotEmpty()) "Modelo: $modeloSalvo"
            else "Modelo: (teste a conexão para detectar)"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(6))
        }
        raiz.addView(labelModelo)

        // Troca de provedor
        val linhaProv = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun botaoProv(id: String, rotulo: String): TextView {
            val ativo = ConfigIA.provedor(this@TelaService) == id
            return botaoTexto(rotulo, if (ativo) "#FF6A1A" else "#28404B") {
                ConfigIA.salvarProvedor(this@TelaService, id)
                fecharPainel()
                abrirConfigIA()
            }
        }
        val pesoP = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
        }
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_GEMINI, "Gemini"), pesoP())
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_GROK, "Grok"), pesoP())
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_OPENAI, "OpenAI"), pesoP())
        raiz.addView(linhaProv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        // Chave
        raiz.addView(TextView(this).apply {
            text = "Chave da API (${ConfigIA.nomeProvedor(ConfigIA.provedor(this@TelaService))})"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val campoKey = EditText(this).apply {
            hint = "Cole a chave deste provedor (só no aparelho)"
            textSize = 13f
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            setBackgroundColor(Color.parseColor("#0F1A20"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            val salva = ConfigIA.apiKey(this@TelaService)
            if (salva.isNotEmpty()) setText(salva)
        }
        raiz.addView(
            campoKey,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8); topMargin = dp(4) }
        )

        // Lista de modelos (preenchida após listar/testar)
        val areaModelos = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (provedorAtual == ConfigIA.PROVEDOR_GEMINI) android.view.View.VISIBLE
            else android.view.View.GONE
        }
        raiz.addView(areaModelos)

        val statusTxt = TextView(this).apply {
            text = "Status: ${ConfigIA.ultimoStatus(this@TelaService)}"
            textSize = 13f
            setTextColor(
                if (ConfigIA.ultimoStatus(this@TelaService).startsWith("Conectado"))
                    Color.parseColor("#4CAF50")
                else Color.parseColor("#97AAB3")
            )
            setPadding(0, dp(4), 0, dp(10))
        }
        raiz.addView(statusTxt)

        fun preencherModelos(lista: List<String>, selecionado: String) {
            areaModelos.removeAllViews()
            if (lista.isEmpty()) return
            areaModelos.addView(TextView(this@TelaService).apply {
                text = "Modelos (toque para escolher)"
                textSize = 12f
                setTextColor(Color.parseColor("#97AAB3"))
                setPadding(0, 0, 0, dp(4))
            })
            // Mostra até 8 melhores
            lista.take(8).forEach { nomeMod ->
                val ativo = nomeMod == selecionado
                val btn = botaoTexto(
                    if (ativo) "● $nomeMod" else nomeMod,
                    if (ativo) "#FF6A1A" else "#28404B"
                ) {
                    ConfigIA.salvarModelo(this@TelaService, ConfigIA.PROVEDOR_GEMINI, nomeMod)
                    labelModelo.text = "Modelo: $nomeMod"
                    // re-destaca
                    preencherModelos(lista, nomeMod)
                    aviso("Modelo selecionado: $nomeMod")
                }
                areaModelos.addView(
                    btn,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(4) }
                )
            }
        }

        val linha1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnSalvar = botaoTexto("Salvar chave", "#1B6E8A") {
            val k = campoKey.text?.toString()?.trim().orEmpty()
            val p = ConfigIA.provedor(this@TelaService)
            ConfigIA.salvarApiKey(this@TelaService, p, k)
            aviso(if (k.isEmpty()) "Chave removida" else "Chave salva para ${ConfigIA.nomeProvedor(p)}")
        }
        val btnTestar = botaoTexto("Testar conexão", "#FF6A1A") {
            val k = campoKey.text?.toString()?.trim().orEmpty()
            if (k.isEmpty()) {
                aviso("Cole a chave deste provedor primeiro.")
                return@botaoTexto
            }
            val p = ConfigIA.provedor(this@TelaService)
            ConfigIA.salvarApiKey(this@TelaService, p, k)
            statusTxt.text = "Status: testando ${ConfigIA.nomeProvedor(p)}…"
            statusTxt.setTextColor(Color.parseColor("#FF8A00"))

            val modeloIA = FabricaIA.criar(p)
            // Se Gemini e usuário já escolheu um modelo, testa só ele primeiro
            if (modeloIA is GeminiProvedor) {
                val escolhidoUi = ConfigIA.modelo(this@TelaService, p)
                if (escolhidoUi.isNotEmpty()) {
                    modeloIA.definirModelo(escolhidoUi)
                }
            }
            modeloIA.testarConexao(k) { r ->
                ConfigIA.salvarStatus(
                    this@TelaService,
                    if (r.ok) "Conectado" else "Não conectado"
                )
                if (modeloIA is GeminiProvedor) {
                    if (modeloIA.modeloSelecionado.isNotEmpty()) {
                        ConfigIA.salvarModelo(this@TelaService, p, modeloIA.modeloSelecionado)
                        labelModelo.text = "Modelo: ${modeloIA.modeloSelecionado}"
                    }
                    if (modeloIA.modelosDisponiveis.isNotEmpty()) {
                        preencherModelos(
                            modeloIA.modelosDisponiveis,
                            modeloIA.modeloSelecionado.ifEmpty { ConfigIA.modelo(this@TelaService, p) }
                        )
                    }
                }
                statusTxt.text = "Status: ${r.mensagem}"
                statusTxt.setTextColor(
                    if (r.ok) Color.parseColor("#4CAF50") else Color.parseColor("#FF2A4A")
                )
                aviso(r.mensagem.take(80))
            }
        }
        val peso = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha1.addView(btnSalvar, peso())
        linha1.addView(btnTestar, peso())
        raiz.addView(linha1)

        raiz.addView(botaoTexto("Fechar", "#28404B") { fecharMenu() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        })

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(raiz)
        }
        val scroll = rolagemLimitada(0.75)
        scroll.addView(outer)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(28),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(scroll, lp)
        menu = scroll
        painel = null
        main.postDelayed({ campoKey.requestFocus() }, 200)
    }

    private fun processarComandoUsuario(comando: String) {
        if (executando || ensinando) {
            aviso("Aguarde a operação atual terminar.")
            return
        }

        // Digitar isolado (só se não for objetivo composto tipo "abra e escreva")
        if (pareceComandoEscrever(comando) && !pareceObjetivoComposto(comando)) {
            val texto = extrairTextoParaEscrever(comando)
            executarDigitarAutonomo(texto, comando)
            return
        }

        if (!ConfigIA.temChave(this)) {
            aviso("Configure a chave da IA primeiro (menu → IA).")
            abrirConfigIA()
            return
        }

        // Loop contínuo: observar → decidir → agir → observar…
        // abrir_app / clicar / digitar NÃO encerram a missão sozinhos.
        executarCicloMissao(comando)
    }

    private val MENSAGEM_PADRAO_MISSAO = "TESTE, LUA ESTEVE AQUI"
    private val MAX_PASSOS_MISSAO = 16

    private fun pareceComandoMissao(comando: String): Boolean = pareceObjetivoComposto(comando)

    /** Objetivos com mais de uma etapa implícita (abrir + pesquisar, mensagem, etc.). */
    private fun pareceObjetivoComposto(comando: String): Boolean {
        val c = comando.lowercase()
        val verbos = listOf(
            "abra", "abrir", "vá", "va ", "pesquise", "pesquisar", "procure", "buscar",
            "envie", "enviar", "mande", "mandar", "digite", "escreva", "clique", "toque",
            "abra o", "abra a"
        )
        val nVerbos = verbos.count { c.contains(it) }
        if (nVerbos >= 2) return true
        if (c.contains(" e ") && nVerbos >= 1) return true
        if (c.contains("mensagem") || c.contains("pesquise") || c.contains("pesquisar")) return true
        return false
    }

    /** Contato: "envie mensagem para Heitor" → Heitor */
    private fun extrairContatoDaMissao(comando: String): String {
        val c = comando.trim()
        // Remove ruidos de app do final: "usando o WhatsApp", "no Telegram", "via Messenger"
        val semApp = c
            .replace(
                Regex(
                    """(?i)\s*(usando|pelo|pela|via|no|na)\s+(o\s+|a\s+)?(whatsapp|telegram|instagram|messenger|messages)\s*$"""
                ),
                ""
            )
            .trim()
        fun limparNome(raw: String): String {
            var s = raw.trim()
            s = s.replace(Regex("""(?i)\s*(usando|pelo|via|no|na)\s+.*$"""), "").trim()
            s = s.replace(Regex("""(?i)\s*(uma\s+)?mensagem.*$"""), "").trim()
            s = s.replace(Regex("""(?i)^(o|a|um|uma)\s+"""), "").trim()
            // so primeiro nome token se ainda tiver lixo longo
            if (s.length > 30) s = s.split(Regex("\s+")).firstOrNull().orEmpty()
            return s.trim()
        }
        Regex("""(?i)(?:mande|envie|enviar|mandar)\s+(?:uma\s+)?mensagem\s+para\s+([A-Za-zÀ-ú][A-Za-zÀ-ú0-9]+)""")
            .find(semApp)?.groupValues?.getOrNull(1)?.let { return limparNome(it) }
        Regex("""(?i)mensagem\s+para\s+([A-Za-zÀ-ú][A-Za-zÀ-ú0-9]+)""")
            .find(semApp)?.groupValues?.getOrNull(1)?.let { return limparNome(it) }
        Regex("""(?i)(?:para|pro|pra)\s+([A-Za-zÀ-ú][A-Za-zÀ-ú0-9]+)""")
            .find(semApp)?.groupValues?.getOrNull(1)?.let {
                val n = limparNome(it)
                if (n.lowercase() !in listOf("o", "a", "whatsapp", "telegram", "instagram")) return n
            }
        return ""
    }

    private fun extrairAppDaMissao(comando: String): String {
        val c = comando.trim()
        Regex(
            """(?i)(?:usando|pelo|pela|via|no|na)\s+(?:o\s+|a\s+)?(WhatsApp|Telegram|Instagram|Messenger|Messages)"""
        ).find(c)?.groupValues?.getOrNull(1)?.let { return it }
        val re = Regex(
            """(?i)(?:vá\s+até|va\s+até|vá\s+ate|va\s+ate|abra(?:\s+o)?|abrir(?:\s+o)?)\s+([A-Za-zÀ-ú0-9 ]+?)(?:\s+e\s+|\s+para\s+|\s*$)"""
        )
        re.find(c)?.groupValues?.getOrNull(1)?.trim()?.let {
            if (it.isNotEmpty() && !it.equals("o", true)) return it
        }
        for (nome in listOf("WhatsApp", "Telegram", "Instagram", "Messenger", "Messages")) {
            if (c.contains(nome, ignoreCase = true)) return nome
        }
        return ""
    }

    /**
     * Ciclo orientado a OBJETIVO:
     * observar → "qual ação me aproxima do objetivo?" → uma ação → observar de novo.
     * Sem "primeiro campo = digitar mensagem".
     */

    /**
     * Interpretacao estruturada do comando (somente o que o usuario disse).
     * Nao inventa app/contato/texto ausentes.
     */
    data class IntencaoMissao(
        val comandoBruto: String,
        val aplicativo: String,
        val alvoPessoa: String,
        val acaoPrincipal: String,
        val preRequisito: String,
        val resultadoEsperado: String,
        val evidenciasSucesso: List<String>,
        val textoMensagem: String
    ) {
        fun resumoPrompt(): String = buildString {
            appendLine("INTERPRETACAO_DO_COMANDO (nao invente alem disso):")
            appendLine("- comando: $comandoBruto")
            appendLine("- aplicativo: ${aplicativo.ifEmpty { "(nao especificado no comando)" }}")
            appendLine("- alvo/pessoa: ${alvoPessoa.ifEmpty { "(nao especificado)" }}")
            appendLine("- acao_principal: $acaoPrincipal")
            appendLine("- pre_requisito: $preRequisito")
            appendLine("- resultado_esperado: $resultadoEsperado")
            appendLine("- evidencias_de_sucesso: ${evidenciasSucesso.joinToString("; ")}")
            if (textoMensagem.isNotEmpty()) appendLine("- texto_sugerido_pelo_usuario: $textoMensagem")
            appendLine("- NUNCA junte palavras do comando em uma unica busca (ex.: nao pesquisar \"Bela usando WhatsApp\").")
        }
    }

    private fun interpretarComando(comando: String): IntencaoMissao {
        val c = comando.trim()
        val cl = c.lowercase()
        val app = extrairAppDaMissao(c)
        val pessoa = extrairContatoDaMissao(c)
        val textoUser = extrairTextoExplicitodaMissaoSafe(c)

        val acaoPrincipal = when {
            listOf("mensagem", "mande", "envie", "enviar", "mandar").any { cl.contains(it) } -> "enviar_mensagem"
            listOf("pesquise", "pesquisar", "busque", "buscar").any { cl.contains(it) } -> "pesquisar"
            listOf("abra", "abrir", "abra o", "abra a").any { cl.contains(it) } &&
                !listOf("mensagem", "mande", "envie").any { cl.contains(it) } -> "abrir_app"
            listOf("digite", "escreva", "escrever").any { cl.contains(it) } -> "digitar"
            else -> "cumprir_objetivo_descrito"
        }

        val pre = when (acaoPrincipal) {
            "enviar_mensagem" -> when {
                pessoa.isNotEmpty() && app.isNotEmpty() ->
                    "estar no app $app e na conversa com $pessoa"
                pessoa.isNotEmpty() -> "estar na conversa correta com $pessoa"
                else -> "estar no contexto correto para enviar mensagem"
            }
            "pesquisar" -> "estar na tela onde a pesquisa do app faz sentido"
            "abrir_app" -> "conseguir abrir o aplicativo pedido"
            else -> "estado da tela compativel com o objetivo"
        }

        val resultado = when (acaoPrincipal) {
            "enviar_mensagem" -> "mensagem enviada na conversa correta (nao apenas digitada)"
            "pesquisar" -> "pesquisa realizada e resultados visiveis"
            "abrir_app" -> "aplicativo aberto em primeiro plano"
            "digitar" -> "texto inserido no campo adequado"
            else -> "objetivo do comando cumprido de forma observavel"
        }

        val evidencias = when (acaoPrincipal) {
            "enviar_mensagem" -> listOf(
                "conversa do destinatario aberta (nome visivel quando possivel)",
                "campo de mensagem presente",
                "apos enviar: evidencias de envio ou mensagem na thread (nao so mudanca generica da arvore)"
            )
            "pesquisar" -> listOf("campo/resultados de pesquisa visiveis")
            "abrir_app" -> listOf("pacote/app alvo em primeiro plano")
            else -> listOf("estado final compativel com o comando")
        }

        return IntencaoMissao(
            comandoBruto = c,
            aplicativo = app,
            alvoPessoa = pessoa,
            acaoPrincipal = acaoPrincipal,
            preRequisito = pre,
            resultadoEsperado = resultado,
            evidenciasSucesso = evidencias,
            textoMensagem = textoUser.ifEmpty {
                if (acaoPrincipal == "enviar_mensagem") MENSAGEM_PADRAO_MISSAO else ""
            }
        )
    }

    /** Texto entre aspas no comando; vazio se nao houver. */
    private fun extrairTextoExplicitodaMissaoSafe(comando: String): String {
        Regex("\"([^\"]{1,200})\"").find(comando)?.groupValues?.getOrNull(1)?.trim()
            ?.takeIf { it.isNotEmpty() }?.let { return it }
        Regex("'([^']{1,200})'").find(comando)?.groupValues?.getOrNull(1)?.trim()
            ?.takeIf { it.isNotEmpty() }?.let { return it }
        return ""
    }

    private fun executarCicloMissao(comandoOriginal: String) {
        if (!ConfigIA.temChave(this)) {
            aviso("Configure a chave da IA (menu → IA) para missões.")
            abrirConfigIA()
            return
        }
        val intencao = interpretarComando(comandoOriginal)
        val appAlvo = intencao.aplicativo
        val contato = intencao.alvoPessoa
        val mensagem = intencao.textoMensagem.ifEmpty { MENSAGEM_PADRAO_MISSAO }

        fecharMenu()
        botao?.estado = OlhoView.Estado.EXECUTANDO
        executando = true
        // v1.2.1 (0.5a): provedor criado UMA vez por missão e reutilizado em todos os passos
        val provedorMissao = FabricaIA.criar(ConfigIA.provedor(this))
        if (provedorMissao is GeminiProvedor) {
            val salvo = ConfigIA.modelo(this, ConfigIA.provedor(this))
            if (salvo.isNotEmpty()) provedorMissao.definirModelo(salvo)
        }
        val titulo = when {
            contato.isNotEmpty() && appAlvo.isNotEmpty() -> "$appAlvo → $contato"
            appAlvo.isNotEmpty() -> appAlvo
            contato.isNotEmpty() -> contato
            else -> intencao.acaoPrincipal
        }
        aviso("Missão: $titulo")

        val historico = mutableListOf<String>()
        var passo = 0
        var consultasIa = 0
        val errosRecuperacoes = mutableListOf<String>()
        var ultimaAcaoChave = ""
        var tentativasMesmaSituacao = 0
        var avisoIaEfeito = ""
        val MAX_RECUPERACOES = 3
        val experienciasErro = mutableListOf<String>()
        val estrategiasJaTentadas = mutableSetOf<String>()
        val experienciasSucesso = mutableListOf<String>()
        // Recompensa simples (registro local da missao; uso inteligente depois)
        val recompensas = mutableListOf<String>()
        var pontosRecompensa = 0

        // Aprendizagem simbolica durante a missao (nao permanente)
        data class ExpMissao(
            val contexto: String,
            val acao: String,
            val alvo: String,
            val mudouUi: Boolean,
            val progresso: Boolean,
            val detalhe: String
        )
        val experienciasEstruturadas = mutableListOf<ExpMissao>()
        val assinaturasRecentes = mutableListOf<String>()
        var ultimasAcoes = mutableListOf<String>()
        var avisoLoop = ""
        var ultimoProgressoReal = "(nenhum ainda)"

        fun contextoAtualCurto(): String {
            val raiz = rootInActiveWindow
            val pkg = raiz?.packageName?.toString()?.substringAfterLast('.').orEmpty()
            val campos = InterpreteAcao.listarCamposEditaveis(raiz).size
            return "pkg=$pkg campos=$campos"
        }

        fun detectarLoopOscilacao(sig: String): Boolean {
            assinaturasRecentes.add(sig)
            while (assinaturasRecentes.size > 8) assinaturasRecentes.removeAt(0)
            if (assinaturasRecentes.size < 4) return false
            val a = assinaturasRecentes[assinaturasRecentes.size - 1]
            val b = assinaturasRecentes[assinaturasRecentes.size - 2]
            val c = assinaturasRecentes[assinaturasRecentes.size - 3]
            val d = assinaturasRecentes[assinaturasRecentes.size - 4]
            // A-B-A-B
            if (a == c && b == d && a != b) return true
            // mesma assinatura 3x seguidas com acoes iguais
            if (a == b && b == c) return true
            val voltarCount = ultimasAcoes.takeLast(5).count { it.startsWith("voltar") || it.startsWith("home") }
            if (voltarCount >= 3) return true
            return false
        }

        fun progressoAposAcao(acao: AcaoIA, mudou: Boolean): Pair<Boolean, String> {
            if (!mudou) return false to "sem_mudanca_ui"
            val (objOk, detObj) = evidenciasObjetivoCumprido()
            if (objOk) return true to "objetivo_quase_ou_cumprido: $detObj"
            val raiz = rootInActiveWindow
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            val elems = InterpreteAcao.listarElementosInterativos(raiz, 30)
            val textos = elems.joinToString(" ") { (it.texto + " " + it.descricao).lowercase() }
            when (intencao.acaoPrincipal) {
                "enviar_mensagem" -> {
                    val contatoVisivel = contato.isEmpty() || textos.contains(contato.lowercase())
                    val temCampo = campos.isNotEmpty()
                    when (acao.tipo) {
                        "abrir_app", "abrir", "open" -> {
                            val ok = appAlvo.isEmpty() || textos.contains(appAlvo.lowercase()) ||
                                (raiz?.packageName?.toString().orEmpty().contains("whatsapp", true) == true)
                            return ok to if (ok) "app_aberto" else "abriu_algo_mas_nao_app_alvo"
                        }
                        "clicar", "tocar", "click", "tap" -> {
                            // abrir conversa: contato + campo mensagem = progresso
                            if (contatoVisivel && temCampo) return true to "parece_conversa_aberta"
                            if (contatoVisivel && !temCampo) return true to "contato_visivel_sem_campo_ainda"
                            if (temCampo && acao.alvo.contains("bela", true)) return true to "campo_apos_clique"
                            // enviar: campo vazio apos enviar seria progresso — heuristica
                            if (acao.alvo.contains("enviar", true) || acao.alvo.contains("send", true)) {
                                val campoVazio = campos.none { (it.texto).isNotBlank() }
                                return campoVazio to if (campoVazio) "campo_vazio_apos_enviar" else "enviar_sem_evidencia_envio"
                            }
                            // so mudou UI sem aproximar
                            return false to "mudanca_ui_sem_progresso_objetivo"
                        }
                        "digitar", "escrever" -> return true to "texto_inserido"
                        "voltar", "back", "home" -> return false to "navegacao_sem_garantia_de_progresso"
                        else -> return mudou to "mudanca_generica"
                    }
                }
                else -> {
                    if (acao.tipo in listOf("voltar", "back", "home")) {
                        return false to "navegacao_sem_garantia"
                    }
                    return mudou to "mudanca_ui"
                }
            }
        }

        fun resumoEstadoMissao(contextoTela: String): String = buildString {
            appendLine("=== RESUMO_MISSAO (aprendizagem em andamento) ===")
            appendLine("Objetivo: $comandoOriginal")
            appendLine(intencao.resumoPrompt().trimEnd())
            appendLine("Ultimo progresso real: $ultimoProgressoReal")
            appendLine("Pontos recompensa: $pontosRecompensa")
            appendLine("Estrategias bloqueadas: ${estrategiasJaTentadas.joinToString(" | ").ifEmpty { "(nenhuma)" }}")
            if (experienciasEstruturadas.isNotEmpty()) {
                appendLine("EXPERIENCIAS (contexto → acao → resultado):")
                experienciasEstruturadas.takeLast(8).forEach { e ->
                    appendLine(
                        "- [${e.contexto}] ${e.acao}/${e.alvo} | mudouUi=${e.mudouUi} progresso=${e.progresso} | ${e.detalhe}"
                    )
                }
            }
            appendLine("Falhas recentes:")
            experienciasErro.takeLast(4).forEach { appendLine("- $it") }
            appendLine("Sucessos recentes:")
            experienciasSucesso.takeLast(4).forEach { appendLine("- $it") }
            if (avisoLoop.isNotEmpty()) appendLine("AVISO_LOOP: $avisoLoop")
            appendLine("Tela atual (resumo):")
            appendLine(contextoTela.take(1200))
            appendLine("=== FIM_RESUMO_MISSAO ===")
        }

        fun estrategiaAprendidaResumo(): String {
            if (experienciasEstruturadas.isEmpty()) return "Nenhuma experiencia estruturada nesta missao."
            return buildString {
                val ruins = experienciasEstruturadas.filter { !it.progresso }
                val boas = experienciasEstruturadas.filter { it.progresso }
                if (ruins.isNotEmpty()) {
                    appendLine("O que nao funcionou:")
                    ruins.takeLast(5).forEach {
                        appendLine("- Em ${it.contexto}: ${it.acao} "${it.alvo}" → ${it.detalhe}")
                    }
                }
                if (boas.isNotEmpty()) {
                    appendLine("O que funcionou:")
                    boas.takeLast(5).forEach {
                        appendLine("- Em ${it.contexto}: ${it.acao} "${it.alvo}" → ${it.detalhe}")
                    }
                }
            }.trim()
        }

        fun registrarRecompensa(estrategia: String, resultado: String, delta: Int) {
            pontosRecompensa += delta
            val sinal = if (delta >= 0) "+$delta" else "$delta"
            recompensas.add("estrategia=$estrategia | resultado=$resultado | recompensa=$sinal")
        }

        historico.add("[0] interpretacao: acao=${intencao.acaoPrincipal} app=${appAlvo.ifEmpty{"?"}} alvo=${contato.ifEmpty{"?"}}")

        fun evidenciasObjetivoCumprido(): Pair<Boolean, String> {
            val raiz = rootInActiveWindow
            val pkg = raiz?.packageName?.toString()?.lowercase().orEmpty()
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            val elems = InterpreteAcao.listarElementosInterativos(raiz, 40)
            val textos = elems.joinToString(" ") {
                ((it.texto) + " " + (it.descricao)).lowercase()
            }
            return when (intencao.acaoPrincipal) {
                "enviar_mensagem" -> {
                    val contatoOk = contato.isEmpty() || textos.contains(contato.lowercase())
                    val temCampo = campos.isNotEmpty()
                    val campoComTexto = campos.any { it.texto.isNotBlank() }
                    val det = "contatoVisivel=$contatoOk campoMsg=$temCampo campoComTexto=$campoComTexto pkg=$pkg"
                    // sucesso de MISSAO: conversa correta e mensagem nao pendente no campo
                    // (heuristica local; nao e garantia absoluta)
                    when {
                        contato.isNotEmpty() && !contatoOk ->
                            false to "destinatario nao evidenciado ($det)"
                        !temCampo ->
                            false to "sem campo de mensagem — talvez nao esteja na conversa ($det)"
                        campoComTexto ->
                            false to "ainda ha texto no campo — envio nao confirmado ($det)"
                        contatoOk && temCampo && !campoComTexto ->
                            true to "conversa ok e campo vazio apos envio ($det)"
                        else ->
                            false to "evidencias insuficientes de envio ($det)"
                    }
                }
                "abrir_app" -> {
                    val ok = appAlvo.isEmpty() || pkg.contains(appAlvo.lowercase().take(4)) ||
                        textos.contains(appAlvo.lowercase())
                    ok to "pkg=$pkg appAlvo=$appAlvo"
                }
                "pesquisar" -> {
                    val ok = campos.isNotEmpty() || textos.contains("result") || textos.contains("pesquisa")
                    ok to "campos=${campos.size}"
                }
                else -> {
                    // sem evidencia forte: nao confirmar automaticamente
                    false to "objetivo generico — IA/usuario devem validar; sem auto-sucesso"
                }
            }
        }



        fun snapshotTela(): String {
            val raiz = rootInActiveWindow
            val pkg = raiz?.packageName?.toString() ?: ""
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            val nCampos = campos.size
            val foco = campos.any { it.focado }
            val elems = InterpreteAcao.listarElementosInterativos(raiz, 24)
            val sig = elems.take(12).joinToString("|") {
                (it.texto.ifEmpty { it.descricao }).take(28)
            }
            val janela = raiz?.className?.toString()?.substringAfterLast('.') ?: ""
            return "$pkg#$janela#c$nCampos#f$foco#$sig"
        }

        /** Evidencias locais extras apos uma acao (sem chamar IA). */
        fun evidenciasLocais(): String {
            val raiz = rootInActiveWindow ?: return "root=null"
            val pkg = raiz.packageName?.toString() ?: "?"
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            val nEdit = campos.size
            val focado = campos.firstOrNull { it.focado }
            return "pkg=$pkg camposEdit=$nEdit foco=" +
                (focado?.resumo()?.take(60) ?: "nenhum")
        }

        fun chaveAcao(acao: AcaoIA): String =
            "${acao.tipo}|${acao.alvo}|${acao.texto}|${acao.app}"

        fun finalizar(ok: Boolean, motivo: String) {
            executando = false
            botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
            val relatorio = montarRelatorioMissao(
                ok = ok,
                objetivo = comandoOriginal,
                app = appAlvo,
                contato = contato,
                motivo = motivo,
                historico = historico.toList(),
                consultasIa = consultasIa,
                erros = errosRecuperacoes.toList(),
                aprendizado = buildString {
                    appendLine("Interpretacao: ${intencao.acaoPrincipal} | app=${intencao.aplicativo} | alvo=${intencao.alvoPessoa}")
                    appendLine("Resultado esperado: ${intencao.resultadoEsperado}")
                    appendLine()
                    appendLine("ESTRATEGIA APRENDIDA")
                    appendLine(estrategiaAprendidaResumo())
                    appendLine()
                    if (experienciasErro.isNotEmpty()) {
                        appendLine("Experiencias de erro:")
                        experienciasErro.takeLast(8).forEach { appendLine("- $it") }
                    }
                    if (experienciasSucesso.isNotEmpty()) {
                        appendLine("Progressos:")
                        experienciasSucesso.takeLast(8).forEach { appendLine("- $it") }
                    }
                    appendLine("RECOMPENSAS (total $pontosRecompensa):")
                    if (recompensas.isEmpty()) appendLine("- nenhuma registrada")
                    else recompensas.forEach { appendLine("- $it") }
                }.trim()
            )
            abrirRelatorioMissao(relatorio)
        }
        fun observarEstruturado(): String {
            val raiz = rootInActiveWindow
            val pkg = raiz?.packageName?.toString() ?: "(desconhecido)"
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            val elems = InterpreteAcao.listarElementosInterativos(raiz, 40)
            return buildString {
                append("PACOTE_ATUAL: $pkg\n")
                append("APP_ALVO: $appAlvo\n")
                if (contato.isNotEmpty()) append("CONTATO_ALVO: $contato\n")
                append("MENSAGEM_A_ENVIAR: $mensagem\n")
                append("CAMPOS_CANDIDATOS (${campos.size}):\n")
                if (campos.isEmpty()) append("  (nenhum)\n")
                else campos.take(10).forEach { append("  ").append(it.resumo()).append('\n') }
                append("ELEMENTOS_NA_TELA (${elems.size}):\n")
                if (elems.isEmpty()) append("  (nenhum)\n")
                else elems.take(25).forEach { append("  ").append(it.resumo()).append('\n') }
            }
        }

        fun executarUma(acao: AcaoIA): String {
            return when (acao.tipo) {
                "abrir_app", "open_app", "abrir", "open" -> {
                    val alvo = acao.app.ifEmpty { acao.pacote }.ifEmpty { appAlvo }
                    val app = InterpreteAcao.resolverNoDispositivo(this, alvo)
                    if (app == null) "falha: app $alvo não encontrado"
                    else if (abrirAplicativo(app.pacote)) "abriu ${app.rotulo}"
                    else "falha ao abrir ${app.rotulo}"
                }
                "home", "inicio", "início" -> {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    "HOME"
                }
                "voltar", "back" -> {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    "VOLTAR"
                }
                "digitar", "escrever", "type", "input" -> {
                    val txt = acao.texto.ifEmpty { mensagem }
                    val campos = InterpreteAcao.listarCamposEditaveis(rootInActiveWindow)
                    val campo = InterpreteAcao.escolherCampo(campos, acao.alvo)
                        ?: return "falha: nenhum campo para digitar"
                    if (escreverNoCampo(campo, txt)) "digitou \"$txt\" em ${campo.resumo()}"
                    else "falha ao digitar"
                }
                "clicar", "tocar", "click", "tap" -> {
                    val alvo = acao.alvo.ifEmpty { acao.texto }
                    if (alvo.isEmpty()) return "falha: clicar sem alvo"
                    val ok = clicarPorTextoOuDesc(alvo)
                    if (ok) "clicou \"$alvo\"" else "falha ao clicar \"$alvo\""
                }
                "concluir", "ok", "done", "sucesso" -> "CONCLUIDO"
                "esperar", "wait" -> "esperou"
                "erro", "error" -> "erro: ${acao.motivo}"
                else -> "desconhecida: ${acao.tipo}"
            }
        }

        fun promptProximoPasso(contexto: String): String {
            return buildString {
                appendLine("Você é o cérebro da Lua, agente Android genérico.")
                appendLine("Use OBJETIVO + elementos da tela. Sem coordenadas. Uma ação por vez.")
                appendLine()
                appendLine("REGRAS:")
                appendLine("0) abrir_app, clicar e digitar são etapas INTERMEDIÁRIAS.")
                appendLine("   NÃO use concluir só porque abriu um app, digitou ou a arvore mudou.")
                appendLine("   Só concluir quando o RESULTADO ESPERADO estiver evidenciavel.")
                appendLine("   ACAO EXECUTADA != ACAO BEM-SUCEDIDA != MISSAO CONCLUIDA.")
                appendLine("1) Estou no lugar certo para o objetivo?")
                appendLine("2) Se não: uma ação que aproxime.")
                appendLine("3) Se sim: uma ação que avance.")
                appendLine("4) Se a última ação gerou tela inesperada, observe o novo estado e corrija o rumo.")
                appendLine()
                appendLine("OBJETIVO:")
                appendLine(comandoOriginal)
                appendLine()
                appendLine(intencao.resumoPrompt())
                appendLine()
                appendLine("DETALHES:")
                appendLine("- App preferido (se houver): $appAlvo")
                if (contato.isNotEmpty()) {
                    appendLine("- Destinatário: $contato")
                    appendLine("- Mensagem final só no contexto da conversa com $contato: $mensagem")
                    appendLine("- Na busca, digitar o NOME ($contato) é válido; a mensagem final é outra coisa.")
                } else {
                    appendLine("- Se o objetivo incluir texto a pesquisar/escrever, use digitar com esse texto.")
                    appendLine("- Mensagem padrão se for envio de mensagem: $mensagem")
                }
                appendLine()
                appendLine(resumoEstadoMissao(contexto))
                appendLine()
                appendLine("REGRAS_DE_APRENDIZAGEM:")
                appendLine("- MUDANCA na arvore NAO e progresso. So progresso conta se aproximar o resultado_esperado.")
                appendLine("- Nao escolha estrategia que ja falhou no MESMO contexto, salvo mudanca relevante de tela.")
                appendLine("- Evite loops (voltar/voltar/voltar ou oscilar entre duas telas).")
                appendLine("- Preferir estrategias que ja tiveram progresso=true nesta missao.")
                if (avisoIaEfeito.isNotEmpty()) {
                    appendLine()
                    appendLine("AVISO IMPORTANTE: $avisoIaEfeito")
                }
                if (avisoLoop.isNotEmpty()) {
                    appendLine("AVISO_LOOP: $avisoLoop — escolha abordagem completamente diferente.")
                }
                appendLine()
                appendLine("Responda SOMENTE JSON de UMA ação:")
                appendLine("""{"acao":"abrir_app|home|voltar|clicar|digitar|concluir|erro","alvo":"...","texto":"...","app":"...","motivo":"estou no lugar certo? e por que esta ação aproxima"}""")
                appendLine("motivo obrigatório.")
            }
        }

        fun proximoPasso() {
            if (!executando) return
            passo++
            if (passo > MAX_PASSOS_MISSAO) {
                finalizar(false, "Limite de $MAX_PASSOS_MISSAO passos. Objetivo não concluído.")
                return
            }
            aviso("Missão $passo/$MAX_PASSOS_MISSAO — raciocinando…")
            val contexto = observarEstruturado()
            historico.add("[$passo] observou")
            aviso("[$passo] observou")
            val sigAgora = snapshotTela()
            if (detectarLoopOscilacao(sigAgora)) {
                avisoLoop = "Oscilacao/repeticao de estados detectada. Parar de repetir a mesma navegacao."
                historico.add("[$passo] LOOP detectado localmente")
                // bloquear voltar/home repetido
                estrategiasJaTentadas.add("voltar||")
                estrategiasJaTentadas.add("home||")
            }

            // Decisoes locais antes da IA (economizar quota)
            val (objOk, detObj) = evidenciasObjetivoCumprido()
            if (objOk && intencao.acaoPrincipal == "enviar_mensagem") {
                // ainda exige evidencia forte de envio para auto-sucesso
                if (detObj.contains("campo_vazio") || detObj.contains("conversa")) {
                    // nao auto-finaliza so por conversa aberta
                }
            }

            val chave = ConfigIA.apiKey(this)
            val pedido = promptProximoPasso(contexto)

            consultasIa++
            provedorMissao.pedirAcao(chave, pedido, contexto) { res ->
                if (!executando) return@pedirAcao
                if (!res.ok) {
                    historico.add("[$passo] IA falhou: ${res.erro}")
                    errosRecuperacoes.add("IA: " + (res.erro))
                    if (passo >= 3) {
                        finalizar(false, "IA indisponível: ${res.erro}")
                    } else {
                        main.postDelayed({ proximoPasso() }, 1000)
                    }
                    return@pedirAcao
                }
                val acao = InterpreteAcao.parse(res.texto)
                if (acao == null) {
                    historico.add("[$passo] resposta inválida: ${res.texto.take(100)}")
                    main.postDelayed({ proximoPasso() }, 900)
                    return@pedirAcao
                }
                val motivo = acao.motivo.ifEmpty { "-" }
                historico.add("[$passo] decidiu ${acao.tipo}: $motivo")
                aviso("[$passo] decidiu ${acao.tipo}")

                when (acao.tipo) {
                    "concluir", "ok", "done", "sucesso" -> {
                        val (okObj, detObj) = evidenciasObjetivoCumprido()
                        historico.add("[$passo] VERIFICAR_OBJETIVO: $detObj")
                        if (okObj) {
                            registrarRecompensa("concluir", "missao_sucesso_verificado", 3)
                            finalizar(true, "Objetivo verificado. " + (motivo.ifEmpty { detObj }))
                        } else {
                            errosRecuperacoes.add("concluir rejeitado: $detObj")
                            registrarRecompensa("concluir", "objetivo_nao_confirmado", -1)
                            avisoIaEfeito =
                                "Nao conclua ainda. Objetivo nao confirmado localmente: $detObj. " +
                                "Continue ate evidencias de: ${intencao.resultadoEsperado}"
                            tentativasMesmaSituacao++
                            if (tentativasMesmaSituacao >= MAX_RECUPERACOES) {
                                finalizar(false, "Objetivo nao verificado apos tentativas: $detObj")
                            } else {
                                main.postDelayed({ proximoPasso() }, 500L)
                            }
                        }
                        return@pedirAcao
                    }
                    "erro", "error" -> {
                        finalizar(false, motivo.ifEmpty { "IA reportou erro." })
                        return@pedirAcao
                    }
                }

                                val isClick = acao.tipo in listOf("clicar", "tocar", "click", "tap")
                val isIntermediaria = acao.tipo in listOf(
                    "clicar", "tocar", "click", "tap",
                    "digitar", "escrever", "type", "input",
                    "abrir_app", "open_app", "abrir", "open",
                    "home", "voltar", "back"
                )
                val chave = chaveAcao(acao)

                // Bloqueio local: nao executar estrategia ja marcada como falha
                if (chave in estrategiasJaTentadas) {
                    tentativasMesmaSituacao++
                    val msg = "IA repetiu estrategia ja falha: $chave (bloqueado localmente)"
                    historico.add("[$passo] $msg")
                    errosRecuperacoes.add(msg)
                    experienciasErro.add(
                        "bloqueio_local estrategia=$chave | motivo=ja_falhou_nesta_missao | ciclo=$tentativasMesmaSituacao/$MAX_RECUPERACOES"
                    )
                    if (tentativasMesmaSituacao >= MAX_RECUPERACOES) {
                        finalizar(false, "IA insistiu em estrategias ja falhas ($MAX_RECUPERACOES ciclos).")
                        return@pedirAcao
                    }
                    avisoIaEfeito =
                        "PROIBIDO repetir: $chave. Estrategias falhas: ${estrategiasJaTentadas.joinToString(" | ")}. " +
                        "Proponha acao/alvo DIFERENTES agora."
                    main.postDelayed({ proximoPasso() }, 400L)
                    return@pedirAcao
                }

                // OBSERVAR (antes) → AGIR → VERIFICAR (depois)
                val antes = snapshotTela()
                val resultado = executarUma(acao)
                historico.add("[$passo] executou ${acao.tipo} → $resultado")
                aviso("[$passo] executou")
                aviso(resultado.take(60))

                if (resultado == "CONCLUIDO") {
                    val (okObj, detObj) = evidenciasObjetivoCumprido()
                    historico.add("[$passo] VERIFICAR_OBJETIVO: $detObj")
                    if (okObj) {
                        registrarRecompensa("concluir", "missao_sucesso_verificado", 3)
                        finalizar(true, "Concluído e verificado. $detObj")
                    } else {
                        registrarRecompensa("concluir", "objetivo_nao_confirmado", -1)
                        avisoIaEfeito = "Concluir bloqueado: $detObj"
                        main.postDelayed({ proximoPasso() }, 500L)
                    }
                    return@pedirAcao
                }

                if (resultado.startsWith("desconhecida:")) {
                    errosRecuperacoes.add(resultado)
                    historico.add("[$passo] acao invalida — encerrando")
                    finalizar(false, "Acao nao suportada: ${acao.tipo}")
                    return@pedirAcao
                }
                if (resultado.startsWith("erro:")) {
                    errosRecuperacoes.add(resultado)
                    finalizar(false, resultado)
                    return@pedirAcao
                }
                if (resultado.startsWith("falha")) {
                    estrategiasJaTentadas.add(chave)
                    tentativasMesmaSituacao++
                    val reg = "acao=${acao.tipo} alvo=${acao.alvo} | resultado_exec=$resultado | ciclo=$tentativasMesmaSituacao/$MAX_RECUPERACOES"
                    experienciasErro.add(reg)
                    errosRecuperacoes.add(resultado)
                    historico.add("[$passo] VERIFICAR: falha imediata — recuperacao $tentativasMesmaSituacao/$MAX_RECUPERACOES")
                    if (tentativasMesmaSituacao >= MAX_RECUPERACOES) {
                        finalizar(false, "Duas ou mais falhas de execucao sem progresso: $chave")
                        return@pedirAcao
                    }
                    avisoIaEfeito =
                        "Execucao falhou ($resultado). Estrategias ja tentadas: ${estrategiasJaTentadas.joinToString(", ")}. Escolha outra."
                    main.postDelayed({ proximoPasso() }, 600L)
                    return@pedirAcao
                }

                val delay = when (acao.tipo) {
                    "abrir_app", "open_app", "abrir" -> 1800L
                    "home", "voltar", "back" -> 1000L
                    "digitar", "escrever" -> 900L
                    "clicar", "tocar", "click", "tap" -> 1000L
                    else -> 800L
                }

                fun concluirVerificacao(depois: String, mudou: Boolean, estabilizou: Boolean) {
                    if (!executando) return
                    val evid = evidenciasLocais()
                    historico.add(
                        "[$passo] VERIFICAR: " +
                            (if (mudou) "mudanca detectada na arvore" else "sem mudanca relevante na arvore") +
                            (if (estabilizou) " (apos estabilizar)" else "") +
                            " | $evid"
                    )
                    val digitarOk = acao.tipo in listOf("digitar", "escrever", "type", "input") &&
                        resultado.startsWith("digitou")
                    if (isIntermediaria && !mudou && !digitarOk) {
                        estrategiasJaTentadas.add(chave)
                        tentativasMesmaSituacao++
                        val registro = buildString {
                            append("acao=").append(acao.tipo)
                            append(" alvo=").append(acao.alvo.ifEmpty { acao.app.ifEmpty { "-" } })
                            append(" | antes=").append(antes.take(80))
                            append(" | depois=").append(depois.take(80))
                            append(" | esperado=progresso_na_tela")
                            append(" | observado=sem_mudanca_na_arvore")
                            append(" | estrategia_tentada=").append(chave)
                            append(" | ciclo_recuperacao=")
                            append(tentativasMesmaSituacao).append("/").append(MAX_RECUPERACOES)
                        }
                        experienciasErro.add(registro)
                        registrarRecompensa(chave, "sem_efeito", -1)
                        errosRecuperacoes.add(
                            "Sem efeito: " + acao.tipo + " " + acao.alvo +
                                " (recuperacao " + tentativasMesmaSituacao + "/" + MAX_RECUPERACOES + ")"
                        )
                        historico.add(
                            "[" + passo + "] ERRO registrado — recuperacao " +
                                tentativasMesmaSituacao + "/" + MAX_RECUPERACOES
                        )
                        if (tentativasMesmaSituacao >= MAX_RECUPERACOES) {
                            finalizar(
                                false,
                                "Missao interrompida apos " + MAX_RECUPERACOES +
                                    " recuperacoes sem progresso (ultima: " + acao.tipo + " / " + acao.alvo + ")."
                            )
                            return
                        }
                        avisoIaEfeito = buildString {
                            append("VERIFICACAO LOCAL FALHOU. Acao ")
                            append(acao.tipo)
                            if (acao.alvo.isNotEmpty()) append(" em ").append(acao.alvo)
                            append(" nao mudou a tela. Evidencias: ").append(evid)
                            append(". Estrategias JA TENTADAS (nao repetir iguais): ")
                            append(estrategiasJaTentadas.joinToString(", "))
                            append(". ")
                            if (isClick) append("Considere: ancestral/container, foto, pesquisa, voltar. ")
                            append("Escolha uma estrategia DIFERENTE.")
                        }
                        main.postDelayed({ proximoPasso() }, 500L)
                        return
                    }
                    val ctx = contextoAtualCurto()
                    val (prog, detProg) = progressoAposAcao(acao, mudou)
                    experienciasEstruturadas.add(
                        ExpMissao(ctx, acao.tipo, acao.alvo.ifEmpty { acao.app }, mudou, prog, detProg)
                    )
                    ultimasAcoes.add(acao.tipo + ":" + acao.alvo)
                    while (ultimasAcoes.size > 12) ultimasAcoes.removeAt(0)

                    if (mudou && prog) {
                        experienciasSucesso.add(
                            "progresso: " + acao.tipo + " alvo=" +
                                acao.alvo.ifEmpty { acao.app } + " | " + detProg
                        )
                        ultimoProgressoReal = acao.tipo + "/" + acao.alvo + " → " + detProg
                        if (estrategiasJaTentadas.isNotEmpty()) {
                            registrarRecompensa(chave, "recuperacao_com_progresso", 2)
                        } else {
                            registrarRecompensa(chave, "progresso_objetivo", 2)
                        }
                        ultimaAcaoChave = ""
                        tentativasMesmaSituacao = 0
                        avisoIaEfeito = ""
                        avisoLoop = ""
                    } else if (mudou && !prog) {
                        // mudou UI mas nao aproximou — NAO tratar como sucesso
                        registrarRecompensa(chave, "mudanca_sem_progresso", -1)
                        historico.add("[$passo] mudanca_ui SEM progresso: $detProg")
                        if (acao.tipo in listOf("voltar", "back", "home")) {
                            estrategiasJaTentadas.add(chave)
                            avisoLoop = "Navegacao repetida sem progresso"
                        }
                        // se mesma chave muda sem progresso 2x, bloquear
                        tentativasMesmaSituacao++
                        if (tentativasMesmaSituacao >= MAX_RECUPERACOES) {
                            finalizar(false, "Mudancas sem progresso real apos $MAX_RECUPERACOES tentativas.")
                            return
                        }
                        avisoIaEfeito =
                            "A acao mudou a tela mas NAO aproximou o objetivo ($detProg). " +
                            "Nao repita. Estrategias bloqueadas: ${estrategiasJaTentadas.joinToString(", ")}"
                    } else if (!mudou) {
                        // already handled in !mudou branch above for intermediaria
                    }
                    proximoPasso()
                }

                main.postDelayed({
                    if (!executando) return@postDelayed
                    val depoisA = snapshotTela()
                    val mudouA = antes != depoisA
                    if (!mudouA && isIntermediaria) {
                        main.postDelayed({
                            if (!executando) return@postDelayed
                            val depoisB = snapshotTela()
                            concluirVerificacao(depoisB, antes != depoisB, estabilizou = true)
                        }, 400L)
                    } else {
                        concluirVerificacao(depoisA, mudouA, estabilizou = false)
                    }
                }, delay)

            }
        }

        main.postDelayed({ proximoPasso() }, 400)
    }

    private fun clicarPorTextoOuDesc(alvo: String): Boolean {
        val raiz = rootInActiveWindow ?: return false
        val low = alvo.lowercase().trim()
        if (low.isEmpty()) return false

        // 1) achar no com o texto (mesmo se nao clickable)
        fun acharTexto(n: AccessibilityNodeInfo?, prof: Int): AccessibilityNodeInfo? {
            if (n == null || prof > 50) return null
            if (n.isVisibleToUser && n.isEnabled) {
                val t = n.text?.toString()?.lowercase().orEmpty()
                val d = n.contentDescription?.toString()?.lowercase().orEmpty()
                if (t == low || d == low || t.contains(low) || d.contains(low)) return n
            }
            for (i in 0 until n.childCount) {
                acharTexto(n.getChild(i), prof + 1)?.let { return it }
            }
            return null
        }
        val textoNo = acharTexto(raiz, 0) ?: return false

        // 2) preferir ancestral clickable (lista/conversa) antes do TextView
        val cadeia = mutableListOf<AccessibilityNodeInfo>()
        var cur: AccessibilityNodeInfo? = textoNo
        var hops = 0
        while (cur != null && hops < 8) {
            cadeia.add(cur)
            cur = cur.parent
            hops++
        }
        // score: clickable layouts perto do texto
        var melhor: AccessibilityNodeInfo? = null
        var melhorScore = -1
        for ((i, no) in cadeia.withIndex()) {
            if (!no.isEnabled || !no.isVisibleToUser) continue
            var sc = 0
            if (no.isClickable) sc += 50
            if (i in 1..4 && no.isClickable) sc += 30 - i * 3
            val cls = no.className?.toString().orEmpty()
            if (cls.contains("Layout") || cls.contains("Item") || cls.contains("Row")) sc += 10
            if (cls.contains("TextView") && !no.isClickable) sc -= 20
            if (sc > melhorScore) {
                melhorScore = sc
                melhor = no
            }
        }
        val alvoNo = melhor ?: textoNo
        return try {
            if (alvoNo.isClickable) {
                alvoNo.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else {
                alvoNo.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                alvoNo.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
        } catch (_: Exception) {
            false
        }
    }

    private fun clicarNoBounds(el: ElementoUI): Boolean {
        val raiz = rootInActiveWindow ?: return false
        val cx = (el.esquerda + el.direita) / 2
        val cy = (el.topo + el.baixo) / 2
        fun buscar(n: AccessibilityNodeInfo?, prof: Int): AccessibilityNodeInfo? {
            if (n == null || prof > 50) return null
            if (n.isVisibleToUser && n.isClickable) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.contains(cx, cy)) return n
            }
            for (i in 0 until n.childCount) {
                buscar(n.getChild(i), prof + 1)?.let { return it }
            }
            return null
        }
        val no = buscar(raiz, 0) ?: return false
        return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }


    private fun montarRelatorioMissao(
        ok: Boolean,
        objetivo: String,
        app: String,
        contato: String,
        motivo: String,
        historico: List<String>,
        consultasIa: Int,
        erros: List<String>,
        aprendizado: String
    ): String = buildString {
        appendLine("MISSAO")
        appendLine("Objetivo: $objetivo")
        appendLine("Aplicativo: $app")
        if (contato.isNotEmpty()) appendLine("Contato: $contato")
        appendLine("Resultado: ${if (ok) "SUCESSO" else "FALHA"}")
        appendLine()
        appendLine("RESUMO")
        appendLine("- Etapas registradas: ${historico.size}")
        appendLine("- Consultas a IA: $consultasIa")
        appendLine("- Erros/recuperacoes: ${erros.size}")
        appendLine("- $motivo")
        appendLine()
        appendLine("PASSOS")
        if (historico.isEmpty()) appendLine("- (nenhum)")
        else historico.forEachIndexed { i, h -> appendLine("${i + 1}. $h") }
        appendLine()
        appendLine("ERROS / RECUPERACOES")
        if (erros.isEmpty()) appendLine("- Nenhum")
        else erros.forEach { appendLine("- $it") }
        appendLine()
        appendLine("APRENDIZADO")
        appendLine(if (aprendizado.isNotEmpty()) "- $aprendizado" else "- Nenhum nesta missao")
    }

    private fun abrirRelatorioMissao(relatorio: String) {
        fecharPainel()
        fecharMenu()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#140C22"))
                setStroke(dp(1), Color.parseColor("#7B5CFF"))
            }
        }
        raiz.addView(TextView(this).apply {
            text = "Relatorio da missao"
            textSize = 16f
            setTextColor(Color.parseColor("#E9D5FF"))
            setPadding(0, 0, 0, dp(8))
        })
        val scroll = ScrollView(this)
        scroll.addView(TextView(this).apply {
            text = relatorio
            textSize = 12f
            setTextColor(Color.parseColor("#D4C4F0"))
            setTextIsSelectable(true)
        })
        raiz.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(320)
            )
        )
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        val btnCopiar = TextView(this).apply {
            text = "Copiar relatorio"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#7B5CFF"))
            }
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("missao_lua", relatorio))
                aviso("Relatorio copiado")
            }
        }
        val btnFechar = TextView(this).apply {
            text = "Fechar"
            textSize = 14f
            setTextColor(Color.parseColor("#E9D5FF"))
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#2E2040"))
            }
            setOnClickListener { fecharPainel() }
        }
        linha.addView(
            btnCopiar,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
        )
        linha.addView(
            btnFechar,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(6)
            }
        )
        raiz.addView(linha)
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try {
            wm.addView(raiz, lp)
            painel = raiz
        } catch (_: Exception) {
            aviso(relatorio.take(120))
        }
    }

    private fun pareceComandoEscrever(comando: String): Boolean {
        val c = comando.lowercase()
        return c.contains("escreva") || c.contains("escrever") ||
            c.contains("digite") || c.contains("digitar") ||
            c.contains("type ") || c.startsWith("type")
    }

    /**
     * Extrai o texto a digitar do comando do usuário.
     * Ex.: "escreva TESTE 123 neste campo" → "TESTE 123"
     * Se não houver texto explícito → padrão do laboratório.
     */
    private fun extrairTextoParaEscrever(comando: String): String {
        val padrao = "TESTE, LUA ESTEVE AQUI"
        val c = comando.trim()
        // aspas
        val aspas = Regex("[\"“”']([^\"“”']+)[\"“”']").find(c)
        if (aspas != null) {
            val t = aspas.groupValues[1].trim()
            if (t.isNotEmpty()) return t
        }
        // escreva|digite <texto> [neste campo|aqui|...]
        val re = Regex(
            """(?i)(?:escreva|escrever|digite|digitar|type)\s+(.+?)(?:\s+(?:neste|nesse|no)\s+campo|\s+aqui)?\s*$"""
        )
        val m = re.find(c)
        if (m != null) {
            var t = m.groupValues[1].trim()
                .removePrefix("o texto").trim()
                .removePrefix(":").trim()
            // remove "neste campo" residual
            t = t.replace(Regex("""(?i)\s*(neste|nesse)\s+campo\s*$"""), "").trim()
            if (t.isNotEmpty() &&
                !t.equals("neste campo", true) &&
                !t.equals("nesse campo", true) &&
                !t.equals("aqui", true)
            ) return t
        }
        return padrao
    }

    /**
     * Observa a árvore → escolhe EditText → clique/foco → SET_TEXT.
     * Sem coordenadas fixas; sem depender da IA.
     */
    private fun executarDigitarAutonomo(texto: String, comandoOriginal: String) {
        botao?.estado = OlhoView.Estado.EXECUTANDO
        aviso("Observando a tela…")
        fecharMenu()

        main.post {
            val raiz = rootInActiveWindow
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            if (campos.isEmpty()) {
                botao?.estado = OlhoView.Estado.NORMAL
                val diag = InterpreteAcao.diagnosticoArvore(raiz)
                abrirPainel(
                    "Não encontrei campo de texto na tela.\n\n" +
                    "Texto que seria escrito:\n$texto\n\n" +
                    "—— Diagnóstico (o que a Lua viu) ——\n$diag"
                )
                return@post
            }
            val escolhido = InterpreteAcao.escolherCampo(campos, "")
            if (escolhido == null) {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel("Campos encontrados (${campos.size}), mas nenhum utilizável.")
                return@post
            }
            aviso("Campo encontrado — digitando…")
            // Pequeno atraso para o usuário ver o estado + garantir árvore estável
            main.postDelayed({
                val ok = escreverNoCampo(escolhido, texto)
                botao?.estado = OlhoView.Estado.NORMAL
                if (ok) {
                    aviso("Pronto")
                    abrirPainel(
                        "✓ Laboratório de digitação\n\n" +
                        "Comando: $comandoOriginal\n" +
                        "Texto: $texto\n" +
                        "Campo: ${escolhido.resumo()}\n\n" +
                        "Fluxo: observar → identificar → clicar → digitar"
                    )
                } else {
                    abrirPainel(
                        "Encontrei o campo, mas falhei ao digitar.\n\n" +
                        "Campo: ${escolhido.resumo()}\n" +
                        "Texto: $texto"
                    )
                }
            }, 250)
        }
    }

    private fun executarAcaoIA(acao: AcaoIA, comandoOriginal: String, bruto: String) {
        removerHaloExecucao()
        when (acao.tipo) {
            "abrir_app", "open_app", "abrir", "open" -> {
                val alvo = acao.app.ifEmpty { acao.pacote }
                if (alvo.isBlank()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("A IA não informou qual app abrir.\n\n$bruto")
                    return
                }
                val encontrado = InterpreteAcao.resolverNoDispositivo(this, alvo)
                    ?: InterpreteAcao.resolverNoDispositivo(this, acao.pacote)
                botao?.estado = OlhoView.Estado.NORMAL
                if (encontrado == null) {
                    abrirPainel(
                        "Não encontrei o app \"$alvo\" entre os instalados.\n\n" +
                        "Sugestão da IA: ${acao.pacote.ifEmpty { "(nenhuma)" }}\n\n" +
                        "Confira o nome e tente de novo."
                    )
                    return
                }
                val ok = abrirAplicativo(encontrado.pacote)
                if (ok) {
                    aviso("Abrindo ${encontrado.rotulo}…")
                    main.postDelayed({
                        abrirPainel(
                            "Comando: $comandoOriginal\n\n" +
                            "Ação: abrir_app\n" +
                            "App: ${encontrado.rotulo}\n" +
                            "Pacote: ${encontrado.pacote}\n\n" +
                            "✓ Executado"
                        )
                    }, 600)
                } else {
                    abrirPainel(
                        "Encontrei o app, mas não consegui abrir.\n" +
                        "App: ${encontrado.rotulo}\n" +
                        "Pacote: ${encontrado.pacote}"
                    )
                }
            }
            "digitar", "escrever", "type", "input" -> {
                val texto = acao.texto
                if (texto.isEmpty()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("A IA pediu digitar, mas não enviou o texto.\n\n$bruto")
                    return
                }
                val campos = InterpreteAcao.listarCamposEditaveis(rootInActiveWindow)
                if (campos.isEmpty()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel(
                        "Não há campo de texto editável visível na tela.\n" +
                        "Abra uma tela com um campo (ex.: busca) e tente de novo.\n\n" +
                        "Texto que seria escrito: $texto"
                    )
                    return
                }
                val escolhido = InterpreteAcao.escolherCampo(campos, acao.alvo)
                if (escolhido == null) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("Não consegui escolher um campo.\nCampos: ${campos.size}")
                    return
                }
                val ok = escreverNoCampo(escolhido, texto)
                botao?.estado = OlhoView.Estado.NORMAL
                if (ok) {
                    aviso("Texto inserido")
                    main.postDelayed({
                        abrirPainel(
                            "Comando: $comandoOriginal\n\n" +
                            "Ação: digitar\n" +
                            "Texto: $texto\n" +
                            "Campo: ${escolhido.resumo()}\n\n" +
                            "✓ Executado"
                        )
                    }, 400)
                } else {
                    abrirPainel(
                        "Falha ao escrever no campo.\n" +
                        "Campo: ${escolhido.resumo()}\n" +
                        "Texto: $texto"
                    )
                }
            }
            "dizer", "falar", "info", "mensagem" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel(acao.texto.ifEmpty { acao.motivo }.ifEmpty { bruto })
            }
            "concluir", "ok", "done" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                aviso(acao.motivo.ifEmpty { "Concluído" })
            }
            "erro", "error" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel("A IA reportou erro:\n\n${acao.motivo.ifEmpty { bruto }}")
            }
            else -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel(
                    "Ação ainda não suportada: ${acao.tipo}\n\n" +
                    "Resposta da IA:\n${bruto.take(400)}\n\n" +
                    "Ações deste ciclo: abrir_app, digitar."
                )
            }
        }
    }

    /**
     * Foca o nó editável correspondente ao CampoEditavel e grava o texto (substitui).
     */
    private fun escreverNoCampo(campo: CampoEditavel, texto: String): Boolean {
        val raiz = rootInActiveWindow ?: return false
        val no = encontrarNoEditavel(raiz, campo) ?: return false
        return try {
            // 1) trazer foco / toque no elemento real da árvore (não coordenada fixa)
            if (no.isFocusable) {
                no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            }
            if (no.isClickable || no.isEditable) {
                no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            // 2) gravar texto via acessibilidade
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    texto
                )
            }
            val ok = no.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (ok) return true
            // 3) retry após re-localizar o nó (alguns apps recriam a view no clique)
            val raiz2 = rootInActiveWindow ?: return false
            val no2 = encontrarNoEditavel(raiz2, campo) ?: return false
            no2.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            no2.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } catch (e: Exception) {
            aviso("Erro ao digitar: ${e.message}")
            false
        }
    }

    private fun encontrarNoEditavel(
        raiz: AccessibilityNodeInfo,
        campo: CampoEditavel
    ): AccessibilityNodeInfo? {
        val lista = mutableListOf<AccessibilityNodeInfo>()
        fun coletar(n: AccessibilityNodeInfo?, prof: Int) {
            if (n == null || prof > 50) return
            if (n.isVisibleToUser && !n.isPassword && n.isEnabled) {
                val cls = (n.className?.toString() ?: "").lowercase()
                val desc = (n.contentDescription?.toString() ?: "").lowercase()
                val hint = (n.hintText?.toString() ?: "").lowercase()
                val match =
                    n.isEditable ||
                        cls.contains("edittext") || cls.contains("autocompletetextview") ||
                        cls.contains("searchview") ||
                        (n.isFocusable && (
                            desc.contains("pesquis") || desc.contains("search") ||
                                desc.contains("meta") || desc.contains("mensagem") ||
                                hint.contains("pesquis") || hint.contains("search")
                            ))
                if (match) lista.add(n)
            }
            for (i in 0 until n.childCount) coletar(n.getChild(i), prof + 1)
        }
        coletar(raiz, 0)
        if (lista.isEmpty()) return null
        val cx = (campo.esquerda + campo.direita) / 2
        val cy = (campo.topo + campo.baixo) / 2
        return lista.minByOrNull { n ->
            val r = Rect()
            n.getBoundsInScreen(r)
            val dx = (r.left + r.right) / 2 - cx
            val dy = (r.top + r.bottom) / 2 - cy
            dx.toLong() * dx + dy.toLong() * dy
        }
    }

    private fun abrirAplicativo(pacote: String): Boolean {
        return try {
            val launch = packageManager.getLaunchIntentForPackage(pacote)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                return true
            }
            // Fallback: activity MAIN/LAUNCHER desse pacote
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pacote)
            val ri = packageManager.queryIntentActivities(intent, 0).firstOrNull() ?: return false
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            true
        } catch (e: Exception) {
            aviso("Erro ao abrir app: ${e.message}")
            false
        }
    }


    // Mantém a API antiga usada por Habilidades e Textos (lista vertical)
    private fun mostrarMenu(titulo: String, itens: List<Triple<String, String, () -> Unit>>) {
        fecharMenu()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(6), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        raiz.addView(TextView(this).apply {
            text = titulo
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val conteudo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var i = 0
        while (i < itens.size) {
            val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0 until 2) {
                if (i + j >= itens.size) break
                val (rotulo, cor, acao) = itens[i + j]
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(8)
                }
                linha.addView(botaoTexto(rotulo, cor, acao), lp)
            }
            conteudo.addView(linha)
            i += 2
        }
        val rolagem = rolagemLimitada(0.55)
        rolagem.addView(conteudo)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        menu = raiz
        botao?.estado = OlhoView.Estado.ABERTO
    }

    private fun fecharMenu() {
        animHolograma?.cancel()
        animHolograma = null
        hologramaView = null
        menu?.let { v ->
            try {
                v.animate().alpha(0f).setDuration(180).withEndAction {
                    try { wm.removeView(v) } catch (_: Exception) {}
                }.start()
            } catch (_: Exception) {
                try { wm.removeView(v) } catch (_: Exception) {}
            }
        }
        menu = null
        // Restaura posição do núcleo
        botaoLp?.let { lp ->
            lp.x = posBotaoAntesMenuX
            lp.y = posBotaoAntesMenuY
            botao?.let { b ->
                try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
            }
        }
        botao?.estado = when {
            executando -> OlhoView.Estado.EXECUTANDO
            ensinando -> OlhoView.Estado.ENSINANDO
            else -> OlhoView.Estado.NORMAL
        }
        if (executando) mostrarHaloExecucao() else removerHaloExecucao()
    }

    /** Halo desativado a pedido do usuário. */
    private fun mostrarHaloExecucao() {
        // não mostra borda/moldura
    }

    private fun removerHaloExecucao() {
        haloExecucao?.let { v ->
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        haloExecucao = null
    }


    private fun iniciarEnsino() {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Ensinar Lua"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "Dê um nome para a habilidade. Depois faça a tarefa normalmente. A Lua vai registrar cliques e campos de texto."
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(10))
        })

        val campo = EditText(this).apply {
            hint = "Ex.: enviar mensagem"
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            setBackgroundColor(Color.parseColor("#0F1A20"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        raiz.addView(campo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnCancelar = botaoTexto("Cancelar", "#28404B") {
            fecharPainel()
        }
        val btnComecar = botaoTexto("Começar", "#1B6E8A") {
            val nome = campo.text.toString().trim()
            if (nome.isEmpty()) {
                aviso("Dê um nome para a habilidade.")
            } else {
                nomeHabilidade = nome
                passosAprendidos.clear()
                ultimoEvento = ""
                ensinando = true
                botao?.estado = OlhoView.Estado.ENSINANDO
                fecharPainel()
                aviso("Ensino iniciado. Faça a tarefa normalmente.")
            }
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnCancelar, pesoLp())
        linha.addView(btnComecar, pesoLp())
        raiz.addView(linha)

        // FLAG_NOT_TOUCH_MODAL permite digitação; removemos FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(raiz, lp)
        painel = raiz
        campo.requestFocus()
    }

    private fun pararEnsino() {
        fecharMenu()
        fecharPainel()
        ensinando = false
        ultimoEvento = ""
        val passos = passosAprendidos.toList()
        passosAprendidos.clear()

        if (passos.isEmpty()) {
            aviso("A Lua não registrou nenhuma ação.")
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            return
        }

        val nomeAtual = nomeHabilidade

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Salvar habilidade?"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "A Lua registrou ${passos.size} passos em \"$nomeAtual\".\nDeseja salvar para reutilizar depois?"
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(12))
        })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnDescartar = botaoTexto("Descartar", "#28404B") {
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            fecharPainel()
            aviso("Habilidade descartada")
        }
        val btnSalvar = botaoTexto("Salvar", "#1B6E8A") {
            Habilidades.adicionar(this@TelaService, Habilidades.Habilidade(nomeAtual, passos))
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            fecharPainel()
            aviso("Habilidade aprendida ✓")
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnDescartar, pesoLp())
        linha.addView(btnSalvar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
    }

    private fun abrirHabilidades() {
        val lista = Habilidades.ler(this)
        val itens = mutableListOf<Triple<String, String, () -> Unit>>()
        if (lista.isEmpty()) {
            itens.add(Triple("Nenhuma habilidade ainda", "#5A6D77") { abrirMenu() })
        } else {
            lista.forEach { h ->
                // Ação principal: executar
                itens.add(Triple("▶ ${h.nome} (${h.passos.size} passos)", "#1B6E8A") {
                    iniciarExecucao(h)
                })
                // Detalhes (opcional)
                itens.add(Triple("   ver passos de ${h.nome}", "#5A6D77") {
                    mostrarHabilidade(h)
                })
            }
            itens.add(Triple("◀ Menu", "#5A6D77") { abrirMenu() })
        }
        mostrarMenu("Habilidades aprendidas", itens)
    }

    private fun mostrarHabilidade(h: Habilidades.Habilidade) {
        val resumo = buildString {
            append(h.nome).append("\n\n")
            h.passos.forEachIndexed { i, p ->
                val alvo = p.texto.ifEmpty { p.descricao.ifEmpty { p.classe } }
                append(i + 1).append(". ").append(p.acao)
                if (alvo.isNotEmpty()) append(" → ").append(alvo)
                append("\n")
            }
        }
        fecharMenu()
        abrirPainel(resumo.trim())
    }

    // ---------- Executor de habilidades (local, sem IA) ----------

    private fun iniciarExecucao(h: Habilidades.Habilidade) {
        if (executando || ensinando) {
            aviso("Aguarde a operação atual terminar.")
            return
        }
        if (h.passos.isEmpty()) {
            aviso("Essa habilidade não tem passos.")
            return
        }
        fecharMenu()
        fecharPainel()
        executando = true
        execucaoCancelada = false
        passosEmExecucao = h.passos
        indiceExecucao = 0
        botao?.estado = OlhoView.Estado.EXECUTANDO
        mostrarHaloExecucao()
        aviso("Executando: ${h.nome}")
        // Pequeno atraso para o menu sumir e a tela estabilizar
        main.postDelayed({ executarProximoPasso() }, 600)
    }

    private fun pararExecucao(motivo: String = "Execução interrompida") {
        executando = false
        execucaoCancelada = true
        passosEmExecucao = emptyList()
        indiceExecucao = 0
        botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
        removerHaloExecucao()
        aviso(motivo)
    }

    private fun executarProximoPasso() {
        if (!executando || execucaoCancelada) return

        if (indiceExecucao >= passosEmExecucao.size) {
            executando = false
            botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
            removerHaloExecucao()
            aviso("Habilidade concluída ✓")
            return
        }

        val passo = passosEmExecucao[indiceExecucao]
        val ok = executarPasso(passo)
        indiceExecucao++

        if (!ok) {
            // Continua mesmo assim (versão 1 é tolerante). Depois podemos parar em falha.
        }

        // Próximo passo após um intervalo
        main.postDelayed({ executarProximoPasso() }, 900)
    }

    private fun executarPasso(passo: Habilidades.Passo): Boolean {
        return when (passo.acao) {
            "tap" -> {
                val no = encontrarNo(passo)
                if (no != null) {
                    val r = Rect()
                    no.getBoundsInScreen(r)
                    // Tenta performAction primeiro; se falhar, tenta clique por gesto simples via centro
                    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        true
                    } else {
                        // fallback: alguns nós não respondem a ACTION_CLICK
                        no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                        false
                    }
                } else {
                    aviso("Não encontrei o alvo do toque")
                    false
                }
            }
            "long_press" -> {
                val no = encontrarNo(passo)
                if (no != null && no.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                    true
                } else {
                    aviso("Não encontrei o alvo do toque longo")
                    false
                }
            }
            "type" -> {
                // Por enquanto o texto gravado está vazio (decisão de privacidade).
                // Apenas tenta focar um campo editável.
                val no = encontrarNoEditavel(passo)
                if (no != null) {
                    no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    true
                } else {
                    false
                }
            }
            else -> false
        }
    }

    /** Procura um nó que combine com o passo gravado. */
    private fun encontrarNo(passo: Habilidades.Passo): AccessibilityNodeInfo? {
        val raiz = rootInActiveWindow ?: return null
        val candidatos = mutableListOf<AccessibilityNodeInfo>()
        coletarNos(raiz, candidatos, 0)

        // 1) Texto exato (se houver)
        if (passo.texto.isNotEmpty()) {
            candidatos.firstOrNull {
                it.isVisibleToUser && (it.text?.toString()?.trim() == passo.texto)
            }?.let { return it }
        }

        // 2) Content description
        if (passo.descricao.isNotEmpty()) {
            candidatos.firstOrNull {
                it.isVisibleToUser && (it.contentDescription?.toString()?.trim() == passo.descricao)
            }?.let { return it }
        }

        // 3) Classe + bounds aproximados
        if (passo.classe.isNotEmpty()) {
            val centroX = (passo.esquerda + passo.direita) / 2
            val centroY = (passo.topo + passo.baixo) / 2
            candidatos
                .filter { it.isVisibleToUser && it.className?.toString() == passo.classe }
                .minByOrNull {
                    val r = Rect()
                    it.getBoundsInScreen(r)
                    val cx = (r.left + r.right) / 2
                    val cy = (r.top + r.bottom) / 2
                    (cx - centroX).toLong() * (cx - centroX) + (cy - centroY).toLong() * (cy - centroY)
                }?.let { return it }
        }

        // 4) Qualquer nó clicável com texto/descrição parecidos
        return candidatos.firstOrNull {
            it.isVisibleToUser && it.isClickable &&
                (passo.texto.isNotEmpty() && it.text?.toString()?.contains(passo.texto) == true ||
                 passo.descricao.isNotEmpty() && it.contentDescription?.toString()?.contains(passo.descricao) == true)
        }
    }

    private fun encontrarNoEditavel(passo: Habilidades.Passo): AccessibilityNodeInfo? {
        val raiz = rootInActiveWindow ?: return null
        val candidatos = mutableListOf<AccessibilityNodeInfo>()
        coletarNos(raiz, candidatos, 0)

        // Preferência: campo já focado
        candidatos.firstOrNull { it.isFocused && it.isEditable && it.isVisibleToUser }?.let { return it }

        // Depois: qualquer EditText visível
        return candidatos.firstOrNull {
            it.isVisibleToUser && it.isEditable &&
                (it.className?.toString()?.contains("EditText") == true ||
                 it.className?.toString()?.contains("TextField") == true)
        }
    }

    private fun coletarNos(n: AccessibilityNodeInfo?, saida: MutableList<AccessibilityNodeInfo>, prof: Int) {
        if (n == null || prof > 45) return
        saida.add(n)
        for (i in 0 until n.childCount) {
            coletarNos(n.getChild(i), saida, prof + 1)
        }
    }

    private fun abrirTextos() {
        val lista = Textos.ler(this)
        val itens = mutableListOf<Triple<String, String, () -> Unit>>()
        lista.forEach { t ->
            val rotulo = if (t.length > 28) t.take(28).replace('\n', ' ') + "…" else t.replace('\n', ' ')
            itens.add(Triple(rotulo, "#1B6E8A") { digitar(t) })
        }
        itens.add(Triple("◀ Menu", "#5A6D77") { abrirMenu() })
        val titulo = if (lista.isEmpty()) "Nenhum texto salvo. Adicione no app." else "Toque num texto para digitar"
        mostrarMenu(titulo, itens)
    }

    // ---------- Ações ----------

    private fun global(acao: Int) {
        fecharMenu()
        main.postDelayed({ performGlobalAction(acao) }, 200)
    }

    private fun tirarPrint() {
        fecharMenu()
        botao?.visibility = View.INVISIBLE
        main.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            main.postDelayed({ botao?.visibility = View.VISIBLE }, 1500)
        }, 300)
    }

    private fun rolar(frente: Boolean) {
        fecharMenu()
        val raiz = rootInActiveWindow
        if (raiz == null) {
            aviso("Não consegui ler a tela.")
            return
        }
        val rolaveis = mutableListOf<AccessibilityNodeInfo>()
        acharRolaveis(raiz, rolaveis, 0)
        val alvo = rolaveis.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height().toLong()
        }
        val acao = if (frente) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (alvo == null || !alvo.performAction(acao)) aviso("Não há nada para rolar aqui.")
    }

    private fun acharRolaveis(n: AccessibilityNodeInfo?, saida: MutableList<AccessibilityNodeInfo>, prof: Int) {
        if (n == null || prof > 40) return
        if (n.isScrollable && n.isVisibleToUser) saida.add(n)
        for (i in 0 until n.childCount) acharRolaveis(n.getChild(i), saida, prof + 1)
    }

    private fun digitar(texto: String) {
        fecharMenu()
        val campo = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (campo == null || !campo.isEditable) {
            aviso("Toque primeiro num campo de texto e abra o menu de novo.")
            return
        }
        if (campo.isPassword) {
            aviso("Por segurança, não digito em campos de senha.")
            return
        }
        // Substitui o conteúdo atual (não concatena)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, texto)
        }
        if (!campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            aviso("Esse campo não aceitou o texto.")
        }
    }

    private fun aviso(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- Traduzir a tela ----------

    private fun aoTraduzir() {
        fecharMenu()
        if (ocupado) return
        ocupado = true
        abrirPainel("Lendo a tela…")

        val texto = lerArvore()
        if (texto.length >= 20) {
            processar(texto)
        } else {
            capturarEOcr()
        }
    }

    private fun lerArvore(): String {
        val raiz = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        percorrer(raiz, sb, 0)
        return sb.toString().trim()
    }

    private fun percorrer(n: AccessibilityNodeInfo?, sb: StringBuilder, prof: Int) {
        if (n == null || prof > 40 || sb.length > 6000) return
        if (n.isVisibleToUser && !n.isPassword) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append('\n')
        }
        for (i in 0 until n.childCount) percorrer(n.getChild(i), sb, prof + 1)
    }

    private fun capturarEOcr() {
        atualizarPainel("Lendo a imagem da tela…")
        botao?.visibility = View.INVISIBLE
        painel?.visibility = View.INVISIBLE
        main.postDelayed({
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                ContextCompat.getMainExecutor(this),
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val buffer = r.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, r.colorSpace)
                            ?.copy(Bitmap.Config.ARGB_8888, false)
                        buffer.close()
                        mostrarTudo()
                        if (bmp == null) {
                            falha("Não consegui capturar a tela.")
                        } else {
                            ocr(bmp)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        mostrarTudo()
                        falha("A captura de tela falhou (código $errorCode). Alguns apps bloqueiam captura.")
                    }
                }
            )
        }, 250)
    }

    private fun ocr(bmp: Bitmap) {
        val reconhecedor = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        reconhecedor.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val t = r.text.trim()
                if (t.isEmpty()) falha("Não encontrei texto na tela.") else processar(t)
            }
            .addOnFailureListener { falha("Erro ao ler a imagem.") }
    }

    private fun processar(texto: String) {
        atualizarPainel("Detectando o idioma…")
        LanguageIdentification.getClient().identifyLanguage(texto.take(500))
            .addOnSuccessListener { codigo ->
                if (codigo == "und") {
                    mostrarResultado(texto, "Não identifiquei o idioma. Texto lido:")
                } else if (codigo == "pt") {
                    mostrarResultado(texto, "Já está em português:")
                } else {
                    val origem = TranslateLanguage.fromLanguageTag(codigo)
                    if (origem == null) {
                        mostrarResultado(texto, "Idioma ($codigo) sem tradução offline. Texto lido:")
                    } else {
                        traduzir(texto, origem)
                    }
                }
            }
            .addOnFailureListener { falha("Erro ao detectar o idioma.") }
    }

    private fun traduzir(texto: String, origem: String) {
        atualizarPainel("Baixando o idioma (só na primeira vez)…")
        val tradutor = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(origem)
                .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                .build()
        )
        tradutor.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                atualizarPainel("Traduzindo…")
                val saida = StringBuilder()
                traduzirPartes(tradutor, dividir(texto), 0, saida) {
                    tradutor.close()
                    mostrarResultado(saida.toString().trim(), "Tradução:")
                }
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Não consegui baixar o idioma. Verifique a internet.")
            }
    }

    private fun dividir(texto: String): List<String> {
        val partes = mutableListOf<String>()
        var atual = StringBuilder()
        for (linha in texto.lines()) {
            if (atual.isNotEmpty() && atual.length + linha.length > 900) {
                partes.add(atual.toString())
                atual = StringBuilder()
            }
            atual.append(linha).append('\n')
        }
        if (atual.isNotEmpty()) partes.add(atual.toString())
        return partes
    }

    private fun traduzirPartes(
        tradutor: Translator,
        partes: List<String>,
        i: Int,
        saida: StringBuilder,
        fim: () -> Unit
    ) {
        if (i >= partes.size) {
            fim()
            return
        }
        tradutor.translate(partes[i])
            .addOnSuccessListener {
                saida.append(it).append('\n')
                traduzirPartes(tradutor, partes, i + 1, saida, fim)
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Erro ao traduzir.")
            }
    }

    // ---------- Painel de resultado ----------

    private fun abrirPainel(msg: String) {
        if (painel != null) {
            atualizarPainel(msg)
            painel?.visibility = View.VISIBLE
            return
        }
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        val texto = TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
        }
        val rolagem = rolagemLimitada(0.45)
        rolagem.addView(texto)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val copiar = botaoTexto("Copiar", "#1B6E8A") { copiarResultado() }
        val fechar = botaoTexto("Fechar", "#28404B") { fecharPainel() }
        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                topMargin = dp(12); marginEnd = dp(8)
            }
        }
        linha.addView(copiar, pesoLp())
        linha.addView(fechar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
        painelTexto = texto
    }

    private fun rolagemLimitada(fracao: Double): ScrollView {
        val limite = (resources.displayMetrics.heightPixels * fracao).toInt()
        return object : ScrollView(this@TelaService) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(limite, View.MeasureSpec.AT_MOST))
            }
        }
    }

    private fun botaoTexto(rotulo: String, cor: String, acao: () -> Unit): TextView {
        return TextView(this).apply {
            text = rotulo
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            maxLines = 2
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor(cor))
            }
            setOnClickListener { acao() }
        }
    }

    private fun atualizarPainel(msg: String) {
        painelTexto?.text = msg
    }

    private fun mostrarResultado(texto: String, titulo: String) {
        ultimoResultado = texto
        atualizarPainel("$titulo\n\n$texto")
        ocupado = false
    }

    private fun falha(msg: String) {
        atualizarPainel(msg)
        ocupado = false
    }

    private fun copiarResultado() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("tela", ultimoResultado))
        aviso("Copiado")
    }

    private fun fecharPainel() {
        painel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        painel = null
        painelTexto = null
        ocupado = false
    }

    private fun mostrarTudo() {
        botao?.visibility = View.VISIBLE
        painel?.visibility = View.VISIBLE
    }

    private fun removerTudo() {
        fecharMenu()
        fecharPainel()
        botao?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        botao = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
