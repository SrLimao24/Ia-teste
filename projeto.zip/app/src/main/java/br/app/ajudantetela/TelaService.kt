package br.app.ajudantetela

import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * Etapa 1: botão flutuante que lê o texto da tela e traduz para português.
 * 1) Tenta ler o texto direto da estrutura da tela (rápido e exato).
 * 2) Se achar pouco texto, tira um print e usa OCR.
 * Tudo roda no aparelho (ML Kit).
 */
class TelaService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var botao: TextView? = null
    private var painel: LinearLayout? = null
    private var painelTexto: TextView? = null
    private var ultimoResultado = ""
    private var ocupado = false

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        criarBotao()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        removerTudo()
        super.onDestroy()
    }

    // ---------- Botão flutuante ----------

    private fun criarBotao() {
        if (botao != null) return
        val b = TextView(this).apply {
            text = "✦"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1B6E8A"))
            }
        }
        val lp = WindowManager.LayoutParams(
            dp(56), dp(56),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(300)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moveu = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moveu = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moveu = true
                    if (moveu) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        wm.updateViewLayout(b, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moveu) aoToque()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, lp)
        botao = b
    }

    private fun aoToque() {
        if (ocupado) return
        ocupado = true
        abrirPainel("Lendo a tela…")

        val texto = lerArvore()
        if (texto.length >= 20) {
            processar(texto)
        } else {
            capturarEOcr()
        }
    }

    // ---------- Leitura da tela ----------

    private fun lerArvore(): String {
        val raiz = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        percorrer(raiz, sb, 0)
        return sb.toString().trim()
    }

    private fun percorrer(n: AccessibilityNodeInfo?, sb: StringBuilder, prof: Int) {
        if (n == null || prof > 40 || sb.length > 6000) return
        if (n.isVisibleToUser && !n.isPassword) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append('\n')
        }
        for (i in 0 until n.childCount) percorrer(n.getChild(i), sb, prof + 1)
    }

    private fun capturarEOcr() {
        atualizarPainel("Lendo a imagem da tela…")
        botao?.visibility = View.INVISIBLE
        painel?.visibility = View.INVISIBLE
        main.postDelayed({
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                ContextCompat.getMainExecutor(this),
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val buffer = r.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, r.colorSpace)
                            ?.copy(Bitmap.Config.ARGB_8888, false)
                        buffer.close()
                        mostrarTudo()
                        if (bmp == null) {
                            falha("Não consegui capturar a tela.")
                        } else {
                            ocr(bmp)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        mostrarTudo()
                        falha("A captura de tela falhou (código $errorCode). Alguns apps bloqueiam captura.")
                    }
                }
            )
        }, 250)
    }

    private fun ocr(bmp: Bitmap) {
        val reconhecedor = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        reconhecedor.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val t = r.text.trim()
                if (t.isEmpty()) falha("Não encontrei texto na tela.") else processar(t)
            }
            .addOnFailureListener { falha("Erro ao ler a imagem.") }
    }

    // ---------- Idioma e tradução ----------

    private fun processar(texto: String) {
        atualizarPainel("Detectando o idioma…")
        LanguageIdentification.getClient().identifyLanguage(texto.take(500))
            .addOnSuccessListener { codigo ->
                if (codigo == "und") {
                    mostrarResultado(texto, "Não identifiquei o idioma. Texto lido:")
                } else if (codigo == "pt") {
                    mostrarResultado(texto, "Já está em português:")
                } else {
                    val origem = TranslateLanguage.fromLanguageTag(codigo)
                    if (origem == null) {
                        mostrarResultado(texto, "Idioma ($codigo) sem tradução offline. Texto lido:")
                    } else {
                        traduzir(texto, origem)
                    }
                }
            }
            .addOnFailureListener { falha("Erro ao detectar o idioma.") }
    }

    private fun traduzir(texto: String, origem: String) {
        atualizarPainel("Baixando o idioma (só na primeira vez)…")
        val tradutor = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(origem)
                .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                .build()
        )
        tradutor.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                atualizarPainel("Traduzindo…")
                val saida = StringBuilder()
                traduzirPartes(tradutor, dividir(texto), 0, saida) {
                    tradutor.close()
                    mostrarResultado(saida.toString().trim(), "Tradução:")
                }
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Não consegui baixar o idioma. Verifique a internet.")
            }
    }

    private fun dividir(texto: String): List<String> {
        val partes = mutableListOf<String>()
        var atual = StringBuilder()
        for (linha in texto.lines()) {
            if (atual.isNotEmpty() && atual.length + linha.length > 900) {
                partes.add(atual.toString())
                atual = StringBuilder()
            }
            atual.append(linha).append('\n')
        }
        if (atual.isNotEmpty()) partes.add(atual.toString())
        return partes
    }

    private fun traduzirPartes(
        tradutor: Translator,
        partes: List<String>,
        i: Int,
        saida: StringBuilder,
        fim: () -> Unit
    ) {
        if (i >= partes.size) {
            fim()
            return
        }
        tradutor.translate(partes[i])
            .addOnSuccessListener {
                saida.append(it).append('\n')
                traduzirPartes(tradutor, partes, i + 1, saida, fim)
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Erro ao traduzir.")
            }
    }

    // ---------- Painel de resultado ----------

    private fun abrirPainel(msg: String) {
        if (painel != null) {
            atualizarPainel(msg)
            painel?.visibility = View.VISIBLE
            return
        }
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        val texto = TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
        }
        val limite = (resources.displayMetrics.heightPixels * 0.45).toInt()
        val rolagem = object : ScrollView(this@TelaService) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(limite, View.MeasureSpec.AT_MOST))
            }
        }
        rolagem.addView(texto)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val copiar = botaoTexto("Copiar", "#1B6E8A") { copiarResultado() }
        val fechar = botaoTexto("Fechar", "#28404B") { fecharPainel() }
        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                topMargin = dp(12); marginEnd = dp(8)
            }
        }
        linha.addView(copiar, pesoLp())
        linha.addView(fechar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
        painelTexto = texto
    }

    private fun botaoTexto(rotulo: String, cor: String, acao: () -> Unit): TextView {
        return TextView(this).apply {
            text = rotulo
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor(cor))
            }
            setOnClickListener { acao() }
        }
    }

    private fun atualizarPainel(msg: String) {
        painelTexto?.text = msg
    }

    private fun mostrarResultado(texto: String, titulo: String) {
        ultimoResultado = texto
        atualizarPainel("$titulo\n\n$texto")
        ocupado = false
    }

    private fun falha(msg: String) {
        atualizarPainel(msg)
        ocupado = false
    }

    private fun copiarResultado() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("tela", ultimoResultado))
        Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
    }

    private fun fecharPainel() {
        painel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        painel = null
        painelTexto = null
        ocupado = false
    }

    private fun mostrarTudo() {
        botao?.visibility = View.VISIBLE
        painel?.visibility = View.VISIBLE
    }

    private fun removerTudo() {
        fecharPainel()
        botao?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        botao = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
