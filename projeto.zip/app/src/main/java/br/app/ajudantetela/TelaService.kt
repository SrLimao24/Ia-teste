package br.app.ajudantetela

import android.content.ComponentName
import android.animation.ValueAnimator
import android.accessibilityservice.AccessibilityService
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.animation.LinearInterpolator
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

/**
 * Botão flutuante (✦) com menu de ações:
 * traduzir a tela, voltar/início/recentes/notificações, rolar, print e digitar textos salvos.
 * Tudo roda no aparelho.
 */
class TelaService : AccessibilityService() {

    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())

    private var botao: OlhoView? = null
    private var menu: View? = null          // pode ser LinearLayout ou FrameLayout radial
    private var painel: LinearLayout? = null
    private var painelTexto: TextView? = null
    private var ultimoResultado = ""
    private var ocupado = false
    private var botaoLp: WindowManager.LayoutParams? = null
    private var posBotaoAntesMenuX = 0
    private var posBotaoAntesMenuY = 0
    private var haloExecucao: View? = null
    private var animHolograma: ValueAnimator? = null
    private var hologramaView: ImageView? = null

    // ----- Modo Ensinar Lua -----
    private var ensinando = false
    private var nomeHabilidade = ""
    private val passosAprendidos = mutableListOf<Habilidades.Passo>()
    private var ultimoEvento = ""

    // ----- Execução de habilidades -----
    private var executando = false
    private var execucaoCancelada = false
    private var passosEmExecucao: List<Habilidades.Passo> = emptyList()
    private var indiceExecucao = 0

    override fun onServiceConnected() {
        super.onServiceConnected()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        criarBotao()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!ensinando || event == null) return
        val pacote = event.packageName?.toString() ?: return
        if (pacote == packageName) return

        val fonte = event.source ?: return
        if (!fonte.isVisibleToUser || fonte.isPassword) return

        val tipo = when (event.eventType) {
            AccessibilityEvent.TYPE_VIEW_CLICKED -> "tap"
            AccessibilityEvent.TYPE_VIEW_LONG_CLICKED -> "long_press"
            AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED -> "type"
            else -> return
        }

        val r = Rect()
        fonte.getBoundsInScreen(r)
        val texto = fonte.text?.toString()?.trim().orEmpty()
        val descricao = fonte.contentDescription?.toString()?.trim().orEmpty()
        val classe = fonte.className?.toString().orEmpty()
        val assinatura = "$tipo|$pacote|$texto|$descricao|$classe|${r.left},${r.top},${r.right},${r.bottom}"
        if (assinatura == ultimoEvento) return
        ultimoEvento = assinatura

        // Em texto digitado, não guardamos o conteúdo real. A habilidade
        // futura poderá tratar o campo como variável {texto}.
        passosAprendidos.add(
            Habilidades.Passo(
                acao = tipo,
                app = pacote,
                texto = if (tipo == "type") "" else texto,
                descricao = descricao,
                classe = classe,
                esquerda = r.left, topo = r.top,
                direita = r.right, baixo = r.bottom
            )
        )
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        removerTudo()
        super.onDestroy()
    }

    // ---------- Botão flutuante (Olho da Lua) ----------

    private fun criarBotao() {
        if (botao != null) return
        val b = OlhoView(this).apply {
            estado = OlhoView.Estado.NORMAL
        }
        val tamanho = dp(64)
        val lp = WindowManager.LayoutParams(
            tamanho, tamanho,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(16)
            y = dp(280)
        }
        botaoLp = lp

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        var moveu = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY
                    startX = lp.x; startY = lp.y
                    moveu = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX
                    val dy = e.rawY - downY
                    if (abs(dx) > dp(8) || abs(dy) > dp(8)) moveu = true
                    if (moveu && menu == null) {
                        lp.x = startX + dx.toInt()
                        lp.y = startY + dy.toInt()
                        try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moveu) aoToque()
                    true
                }
                else -> false
            }
        }
        wm.addView(b, lp)
        botao = b
    }

    private fun aoToque() {
        if (executando) {
            pararExecucao("Execução interrompida pelo usuário")
            return
        }
        if (menu != null) fecharMenu() else abrirMenu()
    }

    // ---------- Menu Radial (Prime Lua) ----------

    private fun abrirMenu() {
        if (menu != null) return
        val comandos = listOf(
            Triple("Traduzir", "#00E5FF") { aoTraduzir() },
            Triple(if (ensinando) "Parar" else "Ensinar", "#7B5CFF") {
                if (ensinando) pararEnsino() else iniciarEnsino()
            },
            Triple("Habilidades", "#FF8A00") { abrirHabilidades() },
            Triple("Textos", "#1B6E8A") { abrirTextos() },
            Triple("IA", "#FF2A4A") { abrirConfigIA() },
            Triple("Voltar", "#28404B") { global(GLOBAL_ACTION_BACK) },
            Triple("Início", "#28404B") { global(GLOBAL_ACTION_HOME) },
            Triple("Recentes", "#28404B") { global(GLOBAL_ACTION_RECENTS) },
            Triple("Notif.", "#28404B") { global(GLOBAL_ACTION_NOTIFICATIONS) },
            Triple("Subir", "#28404B") { rolar(false) },
            Triple("Descer", "#28404B") { rolar(true) },
            Triple("Print", "#28404B") { tirarPrint() }
        )
        mostrarMenuRadial(comandos)
    }

    private fun mostrarMenuRadial(itens: List<Triple<String, String, () -> Unit>>) {
        fecharMenu()
        val b = botao ?: return
        val lpBotao = botaoLp ?: return

        // Tela do menu: holograma grande + órbita BEM aberta
        val largura = dp(340)
        val altura = dp(460)
        val diametro = dp(300)
        val raio = diametro / 2f
        val itemSize = dp(52)
        // Órbita externa: botões longe do centro (não colados)
        val fatorOrbita = 0.82f

        val container = FrameLayout(this)

        // Campo de comando no topo
        val barraComando = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(8), dp(10), dp(8))
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#F0180C2E"))
                setStroke(dp(1), Color.parseColor("#99C77DFF"))
            }
        }
        val campoComando = EditText(this).apply {
            hint = "O que você quer que eu faça?"
            textSize = 14f
            setTextColor(Color.parseColor("#F5EDFF"))
            setHintTextColor(Color.parseColor("#9B8AB8"))
            setBackgroundColor(Color.parseColor("#1A0A2E"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
            maxLines = 3
            isFocusable = true
            isFocusableInTouchMode = true
        }
        val btnExecutar = TextView(this).apply {
            text = "✦  Executar"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#7B5CFF"))
            }
            setOnClickListener {
                val cmd = campoComando.text?.toString()?.trim().orEmpty()
                if (cmd.isEmpty()) {
                    aviso("Digite um comando primeiro.")
                    return@setOnClickListener
                }
                confirmarEExecutarComando(cmd)
            }
        }
        barraComando.addView(
            campoComando,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        )
        barraComando.addView(
            btnExecutar,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        )
        container.addView(
            barraComando,
            FrameLayout.LayoutParams(
                largura - dp(20),
                FrameLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                topMargin = dp(6)
            }
        )

        // Órbita ampla — anel fino + botões espaçados
        val radial = FrameLayout(this)
        val anel = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#220A0618"))
                setStroke(dp(1), Color.parseColor("#55E9D5FF"))
            }
        }
        radial.addView(anel, FrameLayout.LayoutParams(diametro, diametro))

        val n = itens.size.coerceAtLeast(1)
        val anguloInicial = -90.0
        for (i in itens.indices) {
            val (rotulo, _, acao) = itens[i]
            val angulo = Math.toRadians(anguloInicial + i * (360.0 / n))
            val cx = raio + (raio * fatorOrbita * kotlin.math.cos(angulo)).toFloat() - itemSize / 2
            val cy = raio + (raio * fatorOrbita * kotlin.math.sin(angulo)).toFloat() - itemSize / 2

            val item = TextView(this).apply {
                text = rotulo
                textSize = 10f
                setTextColor(Color.parseColor("#F8F0FF"))
                gravity = Gravity.CENTER
                maxLines = 2
                setPadding(dp(3), dp(3), dp(3), dp(3))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.parseColor("#F01A0A30"))
                    setStroke(dp(2), Color.parseColor("#C4B5FD"))
                }
                alpha = 0f
                scaleX = 0.2f
                scaleY = 0.2f
                setOnClickListener {
                    fecharMenu()
                    acao()
                }
            }
            radial.addView(
                item,
                FrameLayout.LayoutParams(itemSize, itemSize).apply {
                    leftMargin = cx.toInt()
                    topMargin = cy.toInt()
                }
            )
            item.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setStartDelay((i * 28).toLong())
                .setDuration(240)
                .start()
        }

        container.addView(
            radial,
            FrameLayout.LayoutParams(diametro, diametro).apply {
                gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                bottomMargin = dp(10)
            }
        )

        val lp = WindowManager.LayoutParams(
            largura, altura,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }

        posBotaoAntesMenuX = lpBotao.x
        posBotaoAntesMenuY = lpBotao.y
        val screenW = resources.displayMetrics.widthPixels
        val screenH = resources.displayMetrics.heightPixels
        val bw = botao?.width ?: dp(64)
        val bh = botao?.height ?: dp(64)
        // Núcleo no centro do carrossel (área inferior)
        lpBotao.x = (screenW - bw) / 2
        lpBotao.y = (screenH - bh) / 2 + dp(48)
        try { wm.updateViewLayout(b, lpBotao) } catch (_: Exception) {}

        botao?.estado = OlhoView.Estado.ABERTO
        wm.addView(container, lp)
        menu = container

        main.postDelayed({
            try { campoComando.requestFocus() } catch (_: Exception) {}
        }, 200)
    }

    /** Confirmação obrigatória antes de processar o comando do usuário. */
    private fun confirmarEExecutarComando(comando: String) {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#FF6A1A"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Confirmar comando"
            textSize = 15f
            setTextColor(Color.parseColor("#FF8A00"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "« $comando »"
            textSize = 14f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(12))
        })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnCancelar = botaoTexto("Cancelar", "#28404B") {
            fecharPainel()
        }
        val btnConfirmar = botaoTexto("Confirmar", "#FF6A1A") {
            fecharPainel()
            processarComandoUsuario(comando)
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnCancelar, pesoLp())
        linha.addView(btnConfirmar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(32),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        wm.addView(raiz, lp)
        painel = raiz
    }

    /**
     * Entrada do ciclo futuro de IA.
     * Por enquanto apenas registra o comando e avisa — a integração com
     * Claude/OpenAI/Grok será o próximo passo.
     */
    // ---------- Configuração de IA ----------

    private fun abrirConfigIA() {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#FF2A4A"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "🌙 Inteligência Artificial"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(8))
        })

        raiz.addView(TextView(this).apply {
            text = "Provedor"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val provedorAtual = ConfigIA.provedor(this)
        raiz.addView(TextView(this).apply {
            text = ConfigIA.nomeProvedor(provedorAtual)
            textSize = 14f
            setTextColor(Color.parseColor("#FF8A00"))
            setPadding(0, dp(2), 0, dp(4))
        })

        val modeloSalvo = ConfigIA.modelo(this, provedorAtual)
        val labelModelo = TextView(this).apply {
            text = if (modeloSalvo.isNotEmpty()) "Modelo: $modeloSalvo"
            else "Modelo: (teste a conexão para detectar)"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(6))
        }
        raiz.addView(labelModelo)

        // Troca de provedor
        val linhaProv = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun botaoProv(id: String, rotulo: String): TextView {
            val ativo = ConfigIA.provedor(this@TelaService) == id
            return botaoTexto(rotulo, if (ativo) "#FF6A1A" else "#28404B") {
                ConfigIA.salvarProvedor(this@TelaService, id)
                fecharPainel()
                abrirConfigIA()
            }
        }
        val pesoP = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
        }
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_GEMINI, "Gemini"), pesoP())
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_GROK, "Grok"), pesoP())
        linhaProv.addView(botaoProv(ConfigIA.PROVEDOR_OPENAI, "OpenAI"), pesoP())
        raiz.addView(linhaProv, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) })

        // Chave
        raiz.addView(TextView(this).apply {
            text = "Chave da API (${ConfigIA.nomeProvedor(ConfigIA.provedor(this@TelaService))})"
            textSize = 12f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val campoKey = EditText(this).apply {
            hint = "Cole a chave deste provedor (só no aparelho)"
            textSize = 13f
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            setBackgroundColor(Color.parseColor("#0F1A20"))
            setPadding(dp(10), dp(8), dp(10), dp(8))
            setSingleLine(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
            val salva = ConfigIA.apiKey(this@TelaService)
            if (salva.isNotEmpty()) setText(salva)
        }
        raiz.addView(
            campoKey,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8); topMargin = dp(4) }
        )

        // Lista de modelos (preenchida após listar/testar)
        val areaModelos = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = if (provedorAtual == ConfigIA.PROVEDOR_GEMINI) android.view.View.VISIBLE
            else android.view.View.GONE
        }
        raiz.addView(areaModelos)

        val statusTxt = TextView(this).apply {
            text = "Status: ${ConfigIA.ultimoStatus(this@TelaService)}"
            textSize = 13f
            setTextColor(
                if (ConfigIA.ultimoStatus(this@TelaService).startsWith("Conectado"))
                    Color.parseColor("#4CAF50")
                else Color.parseColor("#97AAB3")
            )
            setPadding(0, dp(4), 0, dp(10))
        }
        raiz.addView(statusTxt)

        fun preencherModelos(lista: List<String>, selecionado: String) {
            areaModelos.removeAllViews()
            if (lista.isEmpty()) return
            areaModelos.addView(TextView(this@TelaService).apply {
                text = "Modelos (toque para escolher)"
                textSize = 12f
                setTextColor(Color.parseColor("#97AAB3"))
                setPadding(0, 0, 0, dp(4))
            })
            // Mostra até 8 melhores
            lista.take(8).forEach { nomeMod ->
                val ativo = nomeMod == selecionado
                val btn = botaoTexto(
                    if (ativo) "● $nomeMod" else nomeMod,
                    if (ativo) "#FF6A1A" else "#28404B"
                ) {
                    ConfigIA.salvarModelo(this@TelaService, ConfigIA.PROVEDOR_GEMINI, nomeMod)
                    labelModelo.text = "Modelo: $nomeMod"
                    // re-destaca
                    preencherModelos(lista, nomeMod)
                    aviso("Modelo selecionado: $nomeMod")
                }
                areaModelos.addView(
                    btn,
                    LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply { bottomMargin = dp(4) }
                )
            }
        }

        val linha1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val btnSalvar = botaoTexto("Salvar chave", "#1B6E8A") {
            val k = campoKey.text?.toString()?.trim().orEmpty()
            val p = ConfigIA.provedor(this@TelaService)
            ConfigIA.salvarApiKey(this@TelaService, p, k)
            aviso(if (k.isEmpty()) "Chave removida" else "Chave salva para ${ConfigIA.nomeProvedor(p)}")
        }
        val btnTestar = botaoTexto("Testar conexão", "#FF6A1A") {
            val k = campoKey.text?.toString()?.trim().orEmpty()
            if (k.isEmpty()) {
                aviso("Cole a chave deste provedor primeiro.")
                return@botaoTexto
            }
            val p = ConfigIA.provedor(this@TelaService)
            ConfigIA.salvarApiKey(this@TelaService, p, k)
            statusTxt.text = "Status: testando ${ConfigIA.nomeProvedor(p)}…"
            statusTxt.setTextColor(Color.parseColor("#FF8A00"))

            val modeloIA = FabricaIA.criar(p)
            // Se Gemini e usuário já escolheu um modelo, testa só ele primeiro
            if (modeloIA is GeminiProvedor) {
                val escolhidoUi = ConfigIA.modelo(this@TelaService, p)
                if (escolhidoUi.isNotEmpty()) {
                    modeloIA.definirModelo(escolhidoUi)
                }
            }
            modeloIA.testarConexao(k) { r ->
                ConfigIA.salvarStatus(
                    this@TelaService,
                    if (r.ok) "Conectado" else "Não conectado"
                )
                if (modeloIA is GeminiProvedor) {
                    if (modeloIA.modeloSelecionado.isNotEmpty()) {
                        ConfigIA.salvarModelo(this@TelaService, p, modeloIA.modeloSelecionado)
                        labelModelo.text = "Modelo: ${modeloIA.modeloSelecionado}"
                    }
                    if (modeloIA.modelosDisponiveis.isNotEmpty()) {
                        preencherModelos(
                            modeloIA.modelosDisponiveis,
                            modeloIA.modeloSelecionado.ifEmpty { ConfigIA.modelo(this@TelaService, p) }
                        )
                    }
                }
                statusTxt.text = "Status: ${r.mensagem}"
                statusTxt.setTextColor(
                    if (r.ok) Color.parseColor("#4CAF50") else Color.parseColor("#FF2A4A")
                )
                aviso(r.mensagem.take(80))
            }
        }
        val peso = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha1.addView(btnSalvar, peso())
        linha1.addView(btnTestar, peso())
        raiz.addView(linha1)

        raiz.addView(botaoTexto("Fechar", "#28404B") { fecharMenu() }.apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        })

        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(raiz)
        }
        val scroll = rolagemLimitada(0.75)
        scroll.addView(outer)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(28),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(scroll, lp)
        menu = scroll
        painel = null
        main.postDelayed({ campoKey.requestFocus() }, 200)
    }

    private fun processarComandoUsuario(comando: String) {
        if (executando || ensinando) {
            aviso("Aguarde a operação atual terminar.")
            return
        }

        // Digitar isolado (só se não for objetivo composto tipo "abra e escreva")
        if (pareceComandoEscrever(comando) && !pareceObjetivoComposto(comando)) {
            val texto = extrairTextoParaEscrever(comando)
            executarDigitarAutonomo(texto, comando)
            return
        }

        if (!ConfigIA.temChave(this)) {
            aviso("Configure a chave da IA primeiro (menu → IA).")
            abrirConfigIA()
            return
        }

        // Loop contínuo: observar → decidir → agir → observar…
        // abrir_app / clicar / digitar NÃO encerram a missão sozinhos.
        executarCicloMissao(comando)
    }

    private val MENSAGEM_PADRAO_MISSAO = "TESTE, LUA ESTEVE AQUI"
    private val MAX_PASSOS_MISSAO = 16

    private fun pareceComandoMissao(comando: String): Boolean = pareceObjetivoComposto(comando)

    /** Objetivos com mais de uma etapa implícita (abrir + pesquisar, mensagem, etc.). */
    private fun pareceObjetivoComposto(comando: String): Boolean {
        val c = comando.lowercase()
        val verbos = listOf(
            "abra", "abrir", "vá", "va ", "pesquise", "pesquisar", "procure", "buscar",
            "envie", "enviar", "mande", "mandar", "digite", "escreva", "clique", "toque",
            "abra o", "abra a"
        )
        val nVerbos = verbos.count { c.contains(it) }
        if (nVerbos >= 2) return true
        if (c.contains(" e ") && nVerbos >= 1) return true
        if (c.contains("mensagem") || c.contains("pesquise") || c.contains("pesquisar")) return true
        return false
    }

    /** Contato: "envie mensagem para Heitor" → Heitor */
    private fun extrairContatoDaMissao(comando: String): String {
        val re = Regex(
            """(?i)(?:para|pro|pra|ao|à)\s+([A-Za-zÀ-ú][A-Za-zÀ-ú0-9 ]{1,40}?)(?:\s*$|\s+no\s|\s+pelo\s|\s+via\s)"""
        )
        re.find(comando.trim())?.groupValues?.getOrNull(1)?.trim()?.let {
            val limpo = it.replace(Regex("""(?i)\s*(uma\s+)?mensagem.*"""), "").trim()
            if (limpo.isNotEmpty() && limpo.length < 40) return limpo
        }
        // "mensagem para X"
        Regex("""(?i)mensagem\s+para\s+([A-Za-zÀ-ú][A-Za-zÀ-ú0-9 ]+)""")
            .find(comando)?.groupValues?.getOrNull(1)?.trim()?.let { return it }
        return ""
    }

    private fun extrairAppDaMissao(comando: String): String {
        val c = comando.trim()
        val re = Regex(
            """(?i)(?:vá\s+até|va\s+até|vá\s+ate|va\s+ate|abra(?:\s+o)?|abrir(?:\s+o)?)\s+([A-Za-zÀ-ú0-9 ]+?)(?:\s+e\s+|\s+para\s+|\s*$)"""
        )
        re.find(c)?.groupValues?.getOrNull(1)?.trim()?.let {
            if (it.isNotEmpty() && !it.equals("o", true)) return it
        }
        for (nome in listOf("WhatsApp", "Telegram", "Instagram", "Messenger", "Messages")) {
            if (c.contains(nome, ignoreCase = true)) return nome
        }
        return "WhatsApp"
    }

    /**
     * Ciclo orientado a OBJETIVO:
     * observar → "qual ação me aproxima do objetivo?" → uma ação → observar de novo.
     * Sem "primeiro campo = digitar mensagem".
     */
    private fun executarCicloMissao(comandoOriginal: String) {
        if (!ConfigIA.temChave(this)) {
            aviso("Configure a chave da IA (menu → IA) para missões.")
            abrirConfigIA()
            return
        }
        val appAlvo = extrairAppDaMissao(comandoOriginal)
        val contato = extrairContatoDaMissao(comandoOriginal)
        val mensagem = MENSAGEM_PADRAO_MISSAO

        fecharMenu()
        botao?.estado = OlhoView.Estado.EXECUTANDO
        executando = true
        // v1.2.1 (0.5a): provedor criado UMA vez por missão e reutilizado em todos os passos
        val provedorMissao = FabricaIA.criar(ConfigIA.provedor(this))
        if (provedorMissao is GeminiProvedor) {
            val salvo = ConfigIA.modelo(this, ConfigIA.provedor(this))
            if (salvo.isNotEmpty()) provedorMissao.definirModelo(salvo)
        }
        val titulo = if (contato.isNotEmpty()) "$appAlvo → $contato" else appAlvo
        aviso("Missão: $titulo")

        val historico = mutableListOf<String>()
        var passo = 0
        var consultasIa = 0
        val errosRecuperacoes = mutableListOf<String>()
        var ultimaAcaoChave = ""
        var cliquesSemEfeito = 0
        var avisoIaEfeito = ""

        fun snapshotTela(): String {
            val raiz = rootInActiveWindow
            val pkg = raiz?.packageName?.toString() ?: ""
            val campos = InterpreteAcao.listarCamposEditaveis(raiz).size
            val elems = InterpreteAcao.listarElementosInterativos(raiz, 20)
            val sig = elems.take(10).joinToString("|") {
                (it.texto.ifEmpty { it.descricao }).take(24)
            }
            return "$pkg#$campos#$sig"
        }

        fun chaveAcao(acao: AcaoIA): String =
            "${acao.tipo}|${acao.alvo}|${acao.texto}|${acao.app}"

        fun finalizar(ok: Boolean, motivo: String) {
            executando = false
            botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
            val relatorio = montarRelatorioMissao(
                ok = ok,
                objetivo = comandoOriginal,
                app = appAlvo,
                contato = contato,
                motivo = motivo,
                historico = historico.toList(),
                consultasIa = consultasIa,
                erros = errosRecuperacoes.toList(),
                aprendizado = ""
            )
            abrirRelatorioMissao(relatorio)
        }
        fun observarEstruturado(): String {
            val raiz = rootInActiveWindow
            val pkg = raiz?.packageName?.toString() ?: "(desconhecido)"
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            val elems = InterpreteAcao.listarElementosInterativos(raiz, 40)
            return buildString {
                append("PACOTE_ATUAL: $pkg\n")
                append("APP_ALVO: $appAlvo\n")
                if (contato.isNotEmpty()) append("CONTATO_ALVO: $contato\n")
                append("MENSAGEM_A_ENVIAR: $mensagem\n")
                append("CAMPOS_CANDIDATOS (${campos.size}):\n")
                if (campos.isEmpty()) append("  (nenhum)\n")
                else campos.take(10).forEach { append("  ").append(it.resumo()).append('\n') }
                append("ELEMENTOS_NA_TELA (${elems.size}):\n")
                if (elems.isEmpty()) append("  (nenhum)\n")
                else elems.take(25).forEach { append("  ").append(it.resumo()).append('\n') }
            }
        }

        fun executarUma(acao: AcaoIA): String {
            return when (acao.tipo) {
                "abrir_app", "open_app", "abrir", "open" -> {
                    val alvo = acao.app.ifEmpty { acao.pacote }.ifEmpty { appAlvo }
                    val app = InterpreteAcao.resolverNoDispositivo(this, alvo)
                    if (app == null) "falha: app $alvo não encontrado"
                    else if (abrirAplicativo(app.pacote)) "abriu ${app.rotulo}"
                    else "falha ao abrir ${app.rotulo}"
                }
                "home", "inicio", "início" -> {
                    performGlobalAction(GLOBAL_ACTION_HOME)
                    "HOME"
                }
                "voltar", "back" -> {
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    "VOLTAR"
                }
                "digitar", "escrever", "type", "input" -> {
                    val txt = acao.texto.ifEmpty { mensagem }
                    val campos = InterpreteAcao.listarCamposEditaveis(rootInActiveWindow)
                    val campo = InterpreteAcao.escolherCampo(campos, acao.alvo)
                        ?: return "falha: nenhum campo para digitar"
                    if (escreverNoCampo(campo, txt)) "digitou \"$txt\" em ${campo.resumo()}"
                    else "falha ao digitar"
                }
                "clicar", "tocar", "click", "tap" -> {
                    val alvo = acao.alvo.ifEmpty { acao.texto }
                    if (alvo.isEmpty()) return "falha: clicar sem alvo"
                    val ok = clicarPorTextoOuDesc(alvo)
                    if (ok) "clicou \"$alvo\"" else "falha ao clicar \"$alvo\""
                }
                "concluir", "ok", "done", "sucesso" -> "CONCLUIDO"
                "esperar", "wait" -> "esperou"
                "erro", "error" -> "erro: ${acao.motivo}"
                else -> "desconhecida: ${acao.tipo}"
            }
        }

        fun promptProximoPasso(contexto: String): String {
            return buildString {
                appendLine("Você é o cérebro da Lua, agente Android genérico.")
                appendLine("Use OBJETIVO + elementos da tela. Sem coordenadas. Uma ação por vez.")
                appendLine()
                appendLine("REGRAS:")
                appendLine("0) abrir_app, clicar e digitar são etapas INTERMEDIÁRIAS.")
                appendLine("   NÃO use concluir só porque abriu um app ou digitou algo.")
                appendLine("   Só concluir quando o OBJETIVO COMPLETO estiver cumprido.")
                appendLine("1) Estou no lugar certo para o objetivo?")
                appendLine("2) Se não: uma ação que aproxime.")
                appendLine("3) Se sim: uma ação que avance.")
                appendLine("4) Se a última ação gerou tela inesperada, observe o novo estado e corrija o rumo.")
                appendLine()
                appendLine("OBJETIVO:")
                appendLine(comandoOriginal)
                appendLine()
                appendLine("DETALHES:")
                appendLine("- App preferido (se houver): $appAlvo")
                if (contato.isNotEmpty()) {
                    appendLine("- Destinatário: $contato")
                    appendLine("- Mensagem final só no contexto da conversa com $contato: $mensagem")
                    appendLine("- Na busca, digitar o NOME ($contato) é válido; a mensagem final é outra coisa.")
                } else {
                    appendLine("- Se o objetivo incluir texto a pesquisar/escrever, use digitar com esse texto.")
                    appendLine("- Mensagem padrão se for envio de mensagem: $mensagem")
                }
                appendLine()
                appendLine("ESTADO ATUAL DA TELA:")
                appendLine(contexto)
                appendLine()
                appendLine("HISTÓRICO:")
                historico.takeLast(8).forEach { appendLine("- $it") }
                if (avisoIaEfeito.isNotEmpty()) {
                    appendLine()
                    appendLine("AVISO IMPORTANTE: $avisoIaEfeito")
                }
                appendLine()
                appendLine("Responda SOMENTE JSON de UMA ação:")
                appendLine("""{"acao":"abrir_app|home|voltar|clicar|digitar|concluir|erro","alvo":"...","texto":"...","app":"...","motivo":"estou no lugar certo? e por que esta ação aproxima"}""")
                appendLine("motivo obrigatório.")
            }
        }

        fun proximoPasso() {
            if (!executando) return
            passo++
            if (passo > MAX_PASSOS_MISSAO) {
                finalizar(false, "Limite de $MAX_PASSOS_MISSAO passos. Objetivo não concluído.")
                return
            }
            aviso("Missão $passo/$MAX_PASSOS_MISSAO — raciocinando…")
            val contexto = observarEstruturado()
            historico.add("[$passo] observou")
            aviso("[$passo] observou")

            val chave = ConfigIA.apiKey(this)
            val pedido = promptProximoPasso(contexto)

            consultasIa++
            provedorMissao.pedirAcao(chave, pedido, contexto) { res ->
                if (!executando) return@pedirAcao
                if (!res.ok) {
                    historico.add("[$passo] IA falhou: ${res.erro}")
                    errosRecuperacoes.add("IA: " + (res.erro))
                    if (passo >= 3) {
                        finalizar(false, "IA indisponível: ${res.erro}")
                    } else {
                        main.postDelayed({ proximoPasso() }, 1000)
                    }
                    return@pedirAcao
                }
                val acao = InterpreteAcao.parse(res.texto)
                if (acao == null) {
                    historico.add("[$passo] resposta inválida: ${res.texto.take(100)}")
                    main.postDelayed({ proximoPasso() }, 900)
                    return@pedirAcao
                }
                val motivo = acao.motivo.ifEmpty { "-" }
                historico.add("[$passo] decidiu ${acao.tipo}: $motivo")
                aviso("[$passo] decidiu ${acao.tipo}")

                when (acao.tipo) {
                    "concluir", "ok", "done", "sucesso" -> {
                        finalizar(true, motivo.ifEmpty { "IA marcou como concluído." })
                        return@pedirAcao
                    }
                    "erro", "error" -> {
                        finalizar(false, motivo.ifEmpty { "IA reportou erro." })
                        return@pedirAcao
                    }
                }

                val isClick = acao.tipo in listOf("clicar", "tocar", "click", "tap")
                val chave = chaveAcao(acao)

                val antes = snapshotTela()
                val resultado = executarUma(acao)
                historico.add("[$passo] executou ${acao.tipo} → $resultado")
                aviso("[$passo] executou")
                aviso(resultado.take(60))

                if (resultado == "CONCLUIDO") {
                    finalizar(true, "Concluído.")
                    return@pedirAcao
                }

                if (resultado.startsWith("desconhecida:")) {
                    errosRecuperacoes.add(resultado)
                    historico.add("[$passo] acao invalida — encerrando")
                    finalizar(false, "Acao nao suportada: ${acao.tipo}")
                    return@pedirAcao
                }
                if (resultado.startsWith("erro:")) {
                    errosRecuperacoes.add(resultado)
                    finalizar(false, resultado)
                    return@pedirAcao
                }

                val delay = when (acao.tipo) {
                    "abrir_app", "open_app", "abrir" -> 2000L
                    "home", "voltar", "back" -> 1000L
                    "digitar", "escrever" -> 900L
                    "clicar", "tocar", "click", "tap" -> 900L
                    else -> 800L
                }

                main.postDelayed({
                    if (!executando) return@postDelayed
                    val depois = snapshotTela()
                    val mudou = antes != depois

                    if (isClick && !resultado.startsWith("falha") && !mudou) {
                        if (chave == ultimaAcaoChave) cliquesSemEfeito++
                        else {
                            ultimaAcaoChave = chave
                            cliquesSemEfeito = 1
                        }
                        val msg = "Clique sem efeito em \"" + acao.alvo + "\" (tentativa " + cliquesSemEfeito + ")"
                        historico.add("[$passo] $msg")
                        errosRecuperacoes.add(msg)

                        if (cliquesSemEfeito >= 2) {
                            finalizar(
                                false,
                                "Missao interrompida: duas tentativas de clique em \"" + acao.alvo + "\" sem mudanca na tela."
                            )
                            return@postDelayed
                        }

                        avisoIaEfeito =
                            "O clique em \"" + acao.alvo + "\" NAO mudou a arvore. " +
                            "Proponha OUTRA estrategia (outro elemento, container/pai, pesquisar, voltar). " +
                            "NAO repita o mesmo clique no mesmo alvo."
                        main.postDelayed({ proximoPasso() }, 400L)
                        return@postDelayed
                    }

                    if (mudou) {
                        ultimaAcaoChave = ""
                        cliquesSemEfeito = 0
                        avisoIaEfeito = ""
                    }
                    proximoPasso()
                }, delay)
            }
        }

        main.postDelayed({ proximoPasso() }, 400)
    }

    private fun clicarPorTextoOuDesc(alvo: String): Boolean {
        val raiz = rootInActiveWindow ?: return false
        val low = alvo.lowercase().trim()
        if (low.isEmpty()) return false
        fun buscar(n: AccessibilityNodeInfo?, prof: Int): AccessibilityNodeInfo? {
            if (n == null || prof > 50) return null
            if (n.isVisibleToUser && n.isEnabled) {
                val t = n.text?.toString()?.lowercase().orEmpty()
                val d = n.contentDescription?.toString()?.lowercase().orEmpty()
                if ((t.contains(low) || d.contains(low) || t == low || d == low) &&
                    (n.isClickable || n.isFocusable || n.isEditable)
                ) return n
            }
            for (i in 0 until n.childCount) {
                buscar(n.getChild(i), prof + 1)?.let { return it }
            }
            return null
        }
        val no = buscar(raiz, 0) ?: return false
        if (no.isClickable) return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        if (no.isEditable || no.isFocusable) {
            no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        var p = no.parent
        var hops = 0
        while (p != null && hops < 6) {
            if (p.isClickable) return p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            p = p.parent
            hops++
        }
        return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun clicarNoBounds(el: ElementoUI): Boolean {
        val raiz = rootInActiveWindow ?: return false
        val cx = (el.esquerda + el.direita) / 2
        val cy = (el.topo + el.baixo) / 2
        fun buscar(n: AccessibilityNodeInfo?, prof: Int): AccessibilityNodeInfo? {
            if (n == null || prof > 50) return null
            if (n.isVisibleToUser && n.isClickable) {
                val r = Rect()
                n.getBoundsInScreen(r)
                if (r.contains(cx, cy)) return n
            }
            for (i in 0 until n.childCount) {
                buscar(n.getChild(i), prof + 1)?.let { return it }
            }
            return null
        }
        val no = buscar(raiz, 0) ?: return false
        return no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }


    private fun montarRelatorioMissao(
        ok: Boolean,
        objetivo: String,
        app: String,
        contato: String,
        motivo: String,
        historico: List<String>,
        consultasIa: Int,
        erros: List<String>,
        aprendizado: String
    ): String = buildString {
        appendLine("MISSAO")
        appendLine("Objetivo: $objetivo")
        appendLine("Aplicativo: $app")
        if (contato.isNotEmpty()) appendLine("Contato: $contato")
        appendLine("Resultado: ${if (ok) "SUCESSO" else "FALHA"}")
        appendLine()
        appendLine("RESUMO")
        appendLine("- Etapas registradas: ${historico.size}")
        appendLine("- Consultas a IA: $consultasIa")
        appendLine("- Erros/recuperacoes: ${erros.size}")
        appendLine("- $motivo")
        appendLine()
        appendLine("PASSOS")
        if (historico.isEmpty()) appendLine("- (nenhum)")
        else historico.forEachIndexed { i, h -> appendLine("${i + 1}. $h") }
        appendLine()
        appendLine("ERROS / RECUPERACOES")
        if (erros.isEmpty()) appendLine("- Nenhum")
        else erros.forEach { appendLine("- $it") }
        appendLine()
        appendLine("APRENDIZADO")
        appendLine(if (aprendizado.isNotEmpty()) "- $aprendizado" else "- Nenhum nesta missao")
    }

    private fun abrirRelatorioMissao(relatorio: String) {
        fecharPainel()
        fecharMenu()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#140C22"))
                setStroke(dp(1), Color.parseColor("#7B5CFF"))
            }
        }
        raiz.addView(TextView(this).apply {
            text = "Relatorio da missao"
            textSize = 16f
            setTextColor(Color.parseColor("#E9D5FF"))
            setPadding(0, 0, 0, dp(8))
        })
        val scroll = ScrollView(this)
        scroll.addView(TextView(this).apply {
            text = relatorio
            textSize = 12f
            setTextColor(Color.parseColor("#D4C4F0"))
            setTextIsSelectable(true)
        })
        raiz.addView(
            scroll,
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dp(320)
            )
        )
        val linha = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dp(10), 0, 0)
        }
        val btnCopiar = TextView(this).apply {
            text = "Copiar relatorio"
            textSize = 14f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#7B5CFF"))
            }
            setOnClickListener {
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("missao_lua", relatorio))
                aviso("Relatorio copiado")
            }
        }
        val btnFechar = TextView(this).apply {
            text = "Fechar"
            textSize = 14f
            setTextColor(Color.parseColor("#E9D5FF"))
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(12), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(12).toFloat()
                setColor(Color.parseColor("#2E2040"))
            }
            setOnClickListener { fecharPainel() }
        }
        linha.addView(
            btnCopiar,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(6)
            }
        )
        linha.addView(
            btnFechar,
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dp(6)
            }
        )
        raiz.addView(linha)
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92f).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        try {
            wm.addView(raiz, lp)
            painel = raiz
        } catch (_: Exception) {
            aviso(relatorio.take(120))
        }
    }

    private fun pareceComandoEscrever(comando: String): Boolean {
        val c = comando.lowercase()
        return c.contains("escreva") || c.contains("escrever") ||
            c.contains("digite") || c.contains("digitar") ||
            c.contains("type ") || c.startsWith("type")
    }

    /**
     * Extrai o texto a digitar do comando do usuário.
     * Ex.: "escreva TESTE 123 neste campo" → "TESTE 123"
     * Se não houver texto explícito → padrão do laboratório.
     */
    private fun extrairTextoParaEscrever(comando: String): String {
        val padrao = "TESTE, LUA ESTEVE AQUI"
        val c = comando.trim()
        // aspas
        val aspas = Regex("[\"“”']([^\"“”']+)[\"“”']").find(c)
        if (aspas != null) {
            val t = aspas.groupValues[1].trim()
            if (t.isNotEmpty()) return t
        }
        // escreva|digite <texto> [neste campo|aqui|...]
        val re = Regex(
            """(?i)(?:escreva|escrever|digite|digitar|type)\s+(.+?)(?:\s+(?:neste|nesse|no)\s+campo|\s+aqui)?\s*$"""
        )
        val m = re.find(c)
        if (m != null) {
            var t = m.groupValues[1].trim()
                .removePrefix("o texto").trim()
                .removePrefix(":").trim()
            // remove "neste campo" residual
            t = t.replace(Regex("""(?i)\s*(neste|nesse)\s+campo\s*$"""), "").trim()
            if (t.isNotEmpty() &&
                !t.equals("neste campo", true) &&
                !t.equals("nesse campo", true) &&
                !t.equals("aqui", true)
            ) return t
        }
        return padrao
    }

    /**
     * Observa a árvore → escolhe EditText → clique/foco → SET_TEXT.
     * Sem coordenadas fixas; sem depender da IA.
     */
    private fun executarDigitarAutonomo(texto: String, comandoOriginal: String) {
        botao?.estado = OlhoView.Estado.EXECUTANDO
        aviso("Observando a tela…")
        fecharMenu()

        main.post {
            val raiz = rootInActiveWindow
            val campos = InterpreteAcao.listarCamposEditaveis(raiz)
            if (campos.isEmpty()) {
                botao?.estado = OlhoView.Estado.NORMAL
                val diag = InterpreteAcao.diagnosticoArvore(raiz)
                abrirPainel(
                    "Não encontrei campo de texto na tela.\n\n" +
                    "Texto que seria escrito:\n$texto\n\n" +
                    "—— Diagnóstico (o que a Lua viu) ——\n$diag"
                )
                return@post
            }
            val escolhido = InterpreteAcao.escolherCampo(campos, "")
            if (escolhido == null) {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel("Campos encontrados (${campos.size}), mas nenhum utilizável.")
                return@post
            }
            aviso("Campo encontrado — digitando…")
            // Pequeno atraso para o usuário ver o estado + garantir árvore estável
            main.postDelayed({
                val ok = escreverNoCampo(escolhido, texto)
                botao?.estado = OlhoView.Estado.NORMAL
                if (ok) {
                    aviso("Pronto")
                    abrirPainel(
                        "✓ Laboratório de digitação\n\n" +
                        "Comando: $comandoOriginal\n" +
                        "Texto: $texto\n" +
                        "Campo: ${escolhido.resumo()}\n\n" +
                        "Fluxo: observar → identificar → clicar → digitar"
                    )
                } else {
                    abrirPainel(
                        "Encontrei o campo, mas falhei ao digitar.\n\n" +
                        "Campo: ${escolhido.resumo()}\n" +
                        "Texto: $texto"
                    )
                }
            }, 250)
        }
    }

    private fun executarAcaoIA(acao: AcaoIA, comandoOriginal: String, bruto: String) {
        removerHaloExecucao()
        when (acao.tipo) {
            "abrir_app", "open_app", "abrir", "open" -> {
                val alvo = acao.app.ifEmpty { acao.pacote }
                if (alvo.isBlank()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("A IA não informou qual app abrir.\n\n$bruto")
                    return
                }
                val encontrado = InterpreteAcao.resolverNoDispositivo(this, alvo)
                    ?: InterpreteAcao.resolverNoDispositivo(this, acao.pacote)
                botao?.estado = OlhoView.Estado.NORMAL
                if (encontrado == null) {
                    abrirPainel(
                        "Não encontrei o app \"$alvo\" entre os instalados.\n\n" +
                        "Sugestão da IA: ${acao.pacote.ifEmpty { "(nenhuma)" }}\n\n" +
                        "Confira o nome e tente de novo."
                    )
                    return
                }
                val ok = abrirAplicativo(encontrado.pacote)
                if (ok) {
                    aviso("Abrindo ${encontrado.rotulo}…")
                    main.postDelayed({
                        abrirPainel(
                            "Comando: $comandoOriginal\n\n" +
                            "Ação: abrir_app\n" +
                            "App: ${encontrado.rotulo}\n" +
                            "Pacote: ${encontrado.pacote}\n\n" +
                            "✓ Executado"
                        )
                    }, 600)
                } else {
                    abrirPainel(
                        "Encontrei o app, mas não consegui abrir.\n" +
                        "App: ${encontrado.rotulo}\n" +
                        "Pacote: ${encontrado.pacote}"
                    )
                }
            }
            "digitar", "escrever", "type", "input" -> {
                val texto = acao.texto
                if (texto.isEmpty()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("A IA pediu digitar, mas não enviou o texto.\n\n$bruto")
                    return
                }
                val campos = InterpreteAcao.listarCamposEditaveis(rootInActiveWindow)
                if (campos.isEmpty()) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel(
                        "Não há campo de texto editável visível na tela.\n" +
                        "Abra uma tela com um campo (ex.: busca) e tente de novo.\n\n" +
                        "Texto que seria escrito: $texto"
                    )
                    return
                }
                val escolhido = InterpreteAcao.escolherCampo(campos, acao.alvo)
                if (escolhido == null) {
                    botao?.estado = OlhoView.Estado.NORMAL
                    abrirPainel("Não consegui escolher um campo.\nCampos: ${campos.size}")
                    return
                }
                val ok = escreverNoCampo(escolhido, texto)
                botao?.estado = OlhoView.Estado.NORMAL
                if (ok) {
                    aviso("Texto inserido")
                    main.postDelayed({
                        abrirPainel(
                            "Comando: $comandoOriginal\n\n" +
                            "Ação: digitar\n" +
                            "Texto: $texto\n" +
                            "Campo: ${escolhido.resumo()}\n\n" +
                            "✓ Executado"
                        )
                    }, 400)
                } else {
                    abrirPainel(
                        "Falha ao escrever no campo.\n" +
                        "Campo: ${escolhido.resumo()}\n" +
                        "Texto: $texto"
                    )
                }
            }
            "dizer", "falar", "info", "mensagem" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel(acao.texto.ifEmpty { acao.motivo }.ifEmpty { bruto })
            }
            "concluir", "ok", "done" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                aviso(acao.motivo.ifEmpty { "Concluído" })
            }
            "erro", "error" -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel("A IA reportou erro:\n\n${acao.motivo.ifEmpty { bruto }}")
            }
            else -> {
                botao?.estado = OlhoView.Estado.NORMAL
                abrirPainel(
                    "Ação ainda não suportada: ${acao.tipo}\n\n" +
                    "Resposta da IA:\n${bruto.take(400)}\n\n" +
                    "Ações deste ciclo: abrir_app, digitar."
                )
            }
        }
    }

    /**
     * Foca o nó editável correspondente ao CampoEditavel e grava o texto (substitui).
     */
    private fun escreverNoCampo(campo: CampoEditavel, texto: String): Boolean {
        val raiz = rootInActiveWindow ?: return false
        val no = encontrarNoEditavel(raiz, campo) ?: return false
        return try {
            // 1) trazer foco / toque no elemento real da árvore (não coordenada fixa)
            if (no.isFocusable) {
                no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            }
            if (no.isClickable || no.isEditable) {
                no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            // 2) gravar texto via acessibilidade
            val args = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    texto
                )
            }
            val ok = no.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
            if (ok) return true
            // 3) retry após re-localizar o nó (alguns apps recriam a view no clique)
            val raiz2 = rootInActiveWindow ?: return false
            val no2 = encontrarNoEditavel(raiz2, campo) ?: return false
            no2.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            no2.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        } catch (e: Exception) {
            aviso("Erro ao digitar: ${e.message}")
            false
        }
    }

    private fun encontrarNoEditavel(
        raiz: AccessibilityNodeInfo,
        campo: CampoEditavel
    ): AccessibilityNodeInfo? {
        val lista = mutableListOf<AccessibilityNodeInfo>()
        fun coletar(n: AccessibilityNodeInfo?, prof: Int) {
            if (n == null || prof > 50) return
            if (n.isVisibleToUser && !n.isPassword && n.isEnabled) {
                val cls = (n.className?.toString() ?: "").lowercase()
                val desc = (n.contentDescription?.toString() ?: "").lowercase()
                val hint = (n.hintText?.toString() ?: "").lowercase()
                val match =
                    n.isEditable ||
                        cls.contains("edittext") || cls.contains("autocompletetextview") ||
                        cls.contains("searchview") ||
                        (n.isFocusable && (
                            desc.contains("pesquis") || desc.contains("search") ||
                                desc.contains("meta") || desc.contains("mensagem") ||
                                hint.contains("pesquis") || hint.contains("search")
                            ))
                if (match) lista.add(n)
            }
            for (i in 0 until n.childCount) coletar(n.getChild(i), prof + 1)
        }
        coletar(raiz, 0)
        if (lista.isEmpty()) return null
        val cx = (campo.esquerda + campo.direita) / 2
        val cy = (campo.topo + campo.baixo) / 2
        return lista.minByOrNull { n ->
            val r = Rect()
            n.getBoundsInScreen(r)
            val dx = (r.left + r.right) / 2 - cx
            val dy = (r.top + r.bottom) / 2 - cy
            dx.toLong() * dx + dy.toLong() * dy
        }
    }

    private fun abrirAplicativo(pacote: String): Boolean {
        return try {
            val launch = packageManager.getLaunchIntentForPackage(pacote)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launch)
                return true
            }
            // Fallback: activity MAIN/LAUNCHER desse pacote
            val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage(pacote)
            val ri = packageManager.queryIntentActivities(intent, 0).firstOrNull() ?: return false
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClassName(ri.activityInfo.packageName, ri.activityInfo.name)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(i)
            true
        } catch (e: Exception) {
            aviso("Erro ao abrir app: ${e.message}")
            false
        }
    }


    // Mantém a API antiga usada por Habilidades e Textos (lista vertical)
    private fun mostrarMenu(titulo: String, itens: List<Triple<String, String, () -> Unit>>) {
        fecharMenu()
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(6), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        raiz.addView(TextView(this).apply {
            text = titulo
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
        })

        val conteudo = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var i = 0
        while (i < itens.size) {
            val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in 0 until 2) {
                if (i + j >= itens.size) break
                val (rotulo, cor, acao) = itens[i + j]
                val lp = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginEnd = dp(8)
                }
                linha.addView(botaoTexto(rotulo, cor, acao), lp)
            }
            conteudo.addView(linha)
            i += 2
        }
        val rolagem = rolagemLimitada(0.55)
        rolagem.addView(conteudo)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        menu = raiz
        botao?.estado = OlhoView.Estado.ABERTO
    }

    private fun fecharMenu() {
        animHolograma?.cancel()
        animHolograma = null
        hologramaView = null
        menu?.let { v ->
            try {
                v.animate().alpha(0f).setDuration(180).withEndAction {
                    try { wm.removeView(v) } catch (_: Exception) {}
                }.start()
            } catch (_: Exception) {
                try { wm.removeView(v) } catch (_: Exception) {}
            }
        }
        menu = null
        // Restaura posição do núcleo
        botaoLp?.let { lp ->
            lp.x = posBotaoAntesMenuX
            lp.y = posBotaoAntesMenuY
            botao?.let { b ->
                try { wm.updateViewLayout(b, lp) } catch (_: Exception) {}
            }
        }
        botao?.estado = when {
            executando -> OlhoView.Estado.EXECUTANDO
            ensinando -> OlhoView.Estado.ENSINANDO
            else -> OlhoView.Estado.NORMAL
        }
        if (executando) mostrarHaloExecucao() else removerHaloExecucao()
    }

    /** Halo desativado a pedido do usuário. */
    private fun mostrarHaloExecucao() {
        // não mostra borda/moldura
    }

    private fun removerHaloExecucao() {
        haloExecucao?.let { v ->
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        haloExecucao = null
    }


    private fun iniciarEnsino() {
        fecharMenu()
        fecharPainel()

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Ensinar Lua"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "Dê um nome para a habilidade. Depois faça a tarefa normalmente. A Lua vai registrar cliques e campos de texto."
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(10))
        })

        val campo = EditText(this).apply {
            hint = "Ex.: enviar mensagem"
            textSize = 16f
            setSingleLine(true)
            setTextColor(Color.parseColor("#E6EEF1"))
            setHintTextColor(Color.parseColor("#5A6D77"))
            setBackgroundColor(Color.parseColor("#0F1A20"))
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        raiz.addView(campo, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(12) })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnCancelar = botaoTexto("Cancelar", "#28404B") {
            fecharPainel()
        }
        val btnComecar = botaoTexto("Começar", "#1B6E8A") {
            val nome = campo.text.toString().trim()
            if (nome.isEmpty()) {
                aviso("Dê um nome para a habilidade.")
            } else {
                nomeHabilidade = nome
                passosAprendidos.clear()
                ultimoEvento = ""
                ensinando = true
                botao?.estado = OlhoView.Estado.ENSINANDO
                fecharPainel()
                aviso("Ensino iniciado. Faça a tarefa normalmente.")
            }
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnCancelar, pesoLp())
        linha.addView(btnComecar, pesoLp())
        raiz.addView(linha)

        // FLAG_NOT_TOUCH_MODAL permite digitação; removemos FLAG_NOT_FOCUSABLE
        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE
        }
        wm.addView(raiz, lp)
        painel = raiz
        campo.requestFocus()
    }

    private fun pararEnsino() {
        fecharMenu()
        fecharPainel()
        ensinando = false
        ultimoEvento = ""
        val passos = passosAprendidos.toList()
        passosAprendidos.clear()

        if (passos.isEmpty()) {
            aviso("A Lua não registrou nenhuma ação.")
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            return
        }

        val nomeAtual = nomeHabilidade

        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }

        raiz.addView(TextView(this).apply {
            text = "Salvar habilidade?"
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
            setPadding(0, 0, 0, dp(6))
        })

        raiz.addView(TextView(this).apply {
            text = "A Lua registrou ${passos.size} passos em \"$nomeAtual\".\nDeseja salvar para reutilizar depois?"
            textSize = 13f
            setTextColor(Color.parseColor("#97AAB3"))
            setPadding(0, 0, 0, dp(12))
        })

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }

        val btnDescartar = botaoTexto("Descartar", "#28404B") {
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            fecharPainel()
            aviso("Habilidade descartada")
        }
        val btnSalvar = botaoTexto("Salvar", "#1B6E8A") {
            Habilidades.adicionar(this@TelaService, Habilidades.Habilidade(nomeAtual, passos))
            nomeHabilidade = ""
            botao?.estado = OlhoView.Estado.NORMAL
            fecharPainel()
            aviso("Habilidade aprendida ✓")
        }

        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(8)
            }
        }
        linha.addView(btnDescartar, pesoLp())
        linha.addView(btnSalvar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
    }

    private fun abrirHabilidades() {
        val lista = Habilidades.ler(this)
        val itens = mutableListOf<Triple<String, String, () -> Unit>>()
        if (lista.isEmpty()) {
            itens.add(Triple("Nenhuma habilidade ainda", "#5A6D77") { abrirMenu() })
        } else {
            lista.forEach { h ->
                // Ação principal: executar
                itens.add(Triple("▶ ${h.nome} (${h.passos.size} passos)", "#1B6E8A") {
                    iniciarExecucao(h)
                })
                // Detalhes (opcional)
                itens.add(Triple("   ver passos de ${h.nome}", "#5A6D77") {
                    mostrarHabilidade(h)
                })
            }
            itens.add(Triple("◀ Menu", "#5A6D77") { abrirMenu() })
        }
        mostrarMenu("Habilidades aprendidas", itens)
    }

    private fun mostrarHabilidade(h: Habilidades.Habilidade) {
        val resumo = buildString {
            append(h.nome).append("\n\n")
            h.passos.forEachIndexed { i, p ->
                val alvo = p.texto.ifEmpty { p.descricao.ifEmpty { p.classe } }
                append(i + 1).append(". ").append(p.acao)
                if (alvo.isNotEmpty()) append(" → ").append(alvo)
                append("\n")
            }
        }
        fecharMenu()
        abrirPainel(resumo.trim())
    }

    // ---------- Executor de habilidades (local, sem IA) ----------

    private fun iniciarExecucao(h: Habilidades.Habilidade) {
        if (executando || ensinando) {
            aviso("Aguarde a operação atual terminar.")
            return
        }
        if (h.passos.isEmpty()) {
            aviso("Essa habilidade não tem passos.")
            return
        }
        fecharMenu()
        fecharPainel()
        executando = true
        execucaoCancelada = false
        passosEmExecucao = h.passos
        indiceExecucao = 0
        botao?.estado = OlhoView.Estado.EXECUTANDO
        mostrarHaloExecucao()
        aviso("Executando: ${h.nome}")
        // Pequeno atraso para o menu sumir e a tela estabilizar
        main.postDelayed({ executarProximoPasso() }, 600)
    }

    private fun pararExecucao(motivo: String = "Execução interrompida") {
        executando = false
        execucaoCancelada = true
        passosEmExecucao = emptyList()
        indiceExecucao = 0
        botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
        removerHaloExecucao()
        aviso(motivo)
    }

    private fun executarProximoPasso() {
        if (!executando || execucaoCancelada) return

        if (indiceExecucao >= passosEmExecucao.size) {
            executando = false
            botao?.estado = if (ensinando) OlhoView.Estado.ENSINANDO else OlhoView.Estado.NORMAL
            removerHaloExecucao()
            aviso("Habilidade concluída ✓")
            return
        }

        val passo = passosEmExecucao[indiceExecucao]
        val ok = executarPasso(passo)
        indiceExecucao++

        if (!ok) {
            // Continua mesmo assim (versão 1 é tolerante). Depois podemos parar em falha.
        }

        // Próximo passo após um intervalo
        main.postDelayed({ executarProximoPasso() }, 900)
    }

    private fun executarPasso(passo: Habilidades.Passo): Boolean {
        return when (passo.acao) {
            "tap" -> {
                val no = encontrarNo(passo)
                if (no != null) {
                    val r = Rect()
                    no.getBoundsInScreen(r)
                    // Tenta performAction primeiro; se falhar, tenta clique por gesto simples via centro
                    if (no.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                        true
                    } else {
                        // fallback: alguns nós não respondem a ACTION_CLICK
                        no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                        false
                    }
                } else {
                    aviso("Não encontrei o alvo do toque")
                    false
                }
            }
            "long_press" -> {
                val no = encontrarNo(passo)
                if (no != null && no.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK)) {
                    true
                } else {
                    aviso("Não encontrei o alvo do toque longo")
                    false
                }
            }
            "type" -> {
                // Por enquanto o texto gravado está vazio (decisão de privacidade).
                // Apenas tenta focar um campo editável.
                val no = encontrarNoEditavel(passo)
                if (no != null) {
                    no.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                    no.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    true
                } else {
                    false
                }
            }
            else -> false
        }
    }

    /** Procura um nó que combine com o passo gravado. */
    private fun encontrarNo(passo: Habilidades.Passo): AccessibilityNodeInfo? {
        val raiz = rootInActiveWindow ?: return null
        val candidatos = mutableListOf<AccessibilityNodeInfo>()
        coletarNos(raiz, candidatos, 0)

        // 1) Texto exato (se houver)
        if (passo.texto.isNotEmpty()) {
            candidatos.firstOrNull {
                it.isVisibleToUser && (it.text?.toString()?.trim() == passo.texto)
            }?.let { return it }
        }

        // 2) Content description
        if (passo.descricao.isNotEmpty()) {
            candidatos.firstOrNull {
                it.isVisibleToUser && (it.contentDescription?.toString()?.trim() == passo.descricao)
            }?.let { return it }
        }

        // 3) Classe + bounds aproximados
        if (passo.classe.isNotEmpty()) {
            val centroX = (passo.esquerda + passo.direita) / 2
            val centroY = (passo.topo + passo.baixo) / 2
            candidatos
                .filter { it.isVisibleToUser && it.className?.toString() == passo.classe }
                .minByOrNull {
                    val r = Rect()
                    it.getBoundsInScreen(r)
                    val cx = (r.left + r.right) / 2
                    val cy = (r.top + r.bottom) / 2
                    (cx - centroX).toLong() * (cx - centroX) + (cy - centroY).toLong() * (cy - centroY)
                }?.let { return it }
        }

        // 4) Qualquer nó clicável com texto/descrição parecidos
        return candidatos.firstOrNull {
            it.isVisibleToUser && it.isClickable &&
                (passo.texto.isNotEmpty() && it.text?.toString()?.contains(passo.texto) == true ||
                 passo.descricao.isNotEmpty() && it.contentDescription?.toString()?.contains(passo.descricao) == true)
        }
    }

    private fun encontrarNoEditavel(passo: Habilidades.Passo): AccessibilityNodeInfo? {
        val raiz = rootInActiveWindow ?: return null
        val candidatos = mutableListOf<AccessibilityNodeInfo>()
        coletarNos(raiz, candidatos, 0)

        // Preferência: campo já focado
        candidatos.firstOrNull { it.isFocused && it.isEditable && it.isVisibleToUser }?.let { return it }

        // Depois: qualquer EditText visível
        return candidatos.firstOrNull {
            it.isVisibleToUser && it.isEditable &&
                (it.className?.toString()?.contains("EditText") == true ||
                 it.className?.toString()?.contains("TextField") == true)
        }
    }

    private fun coletarNos(n: AccessibilityNodeInfo?, saida: MutableList<AccessibilityNodeInfo>, prof: Int) {
        if (n == null || prof > 45) return
        saida.add(n)
        for (i in 0 until n.childCount) {
            coletarNos(n.getChild(i), saida, prof + 1)
        }
    }

    private fun abrirTextos() {
        val lista = Textos.ler(this)
        val itens = mutableListOf<Triple<String, String, () -> Unit>>()
        lista.forEach { t ->
            val rotulo = if (t.length > 28) t.take(28).replace('\n', ' ') + "…" else t.replace('\n', ' ')
            itens.add(Triple(rotulo, "#1B6E8A") { digitar(t) })
        }
        itens.add(Triple("◀ Menu", "#5A6D77") { abrirMenu() })
        val titulo = if (lista.isEmpty()) "Nenhum texto salvo. Adicione no app." else "Toque num texto para digitar"
        mostrarMenu(titulo, itens)
    }

    // ---------- Ações ----------

    private fun global(acao: Int) {
        fecharMenu()
        main.postDelayed({ performGlobalAction(acao) }, 200)
    }

    private fun tirarPrint() {
        fecharMenu()
        botao?.visibility = View.INVISIBLE
        main.postDelayed({
            performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            main.postDelayed({ botao?.visibility = View.VISIBLE }, 1500)
        }, 300)
    }

    private fun rolar(frente: Boolean) {
        fecharMenu()
        val raiz = rootInActiveWindow
        if (raiz == null) {
            aviso("Não consegui ler a tela.")
            return
        }
        val rolaveis = mutableListOf<AccessibilityNodeInfo>()
        acharRolaveis(raiz, rolaveis, 0)
        val alvo = rolaveis.maxByOrNull {
            val r = Rect()
            it.getBoundsInScreen(r)
            r.width().toLong() * r.height().toLong()
        }
        val acao = if (frente) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD
        if (alvo == null || !alvo.performAction(acao)) aviso("Não há nada para rolar aqui.")
    }

    private fun acharRolaveis(n: AccessibilityNodeInfo?, saida: MutableList<AccessibilityNodeInfo>, prof: Int) {
        if (n == null || prof > 40) return
        if (n.isScrollable && n.isVisibleToUser) saida.add(n)
        for (i in 0 until n.childCount) acharRolaveis(n.getChild(i), saida, prof + 1)
    }

    private fun digitar(texto: String) {
        fecharMenu()
        val campo = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (campo == null || !campo.isEditable) {
            aviso("Toque primeiro num campo de texto e abra o menu de novo.")
            return
        }
        if (campo.isPassword) {
            aviso("Por segurança, não digito em campos de senha.")
            return
        }
        // Substitui o conteúdo atual (não concatena)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, texto)
        }
        if (!campo.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            aviso("Esse campo não aceitou o texto.")
        }
    }

    private fun aviso(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    // ---------- Traduzir a tela ----------

    private fun aoTraduzir() {
        fecharMenu()
        if (ocupado) return
        ocupado = true
        abrirPainel("Lendo a tela…")

        val texto = lerArvore()
        if (texto.length >= 20) {
            processar(texto)
        } else {
            capturarEOcr()
        }
    }

    private fun lerArvore(): String {
        val raiz = rootInActiveWindow ?: return ""
        val sb = StringBuilder()
        percorrer(raiz, sb, 0)
        return sb.toString().trim()
    }

    private fun percorrer(n: AccessibilityNodeInfo?, sb: StringBuilder, prof: Int) {
        if (n == null || prof > 40 || sb.length > 6000) return
        if (n.isVisibleToUser && !n.isPassword) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim()
            if (!t.isNullOrEmpty()) sb.append(t).append('\n')
        }
        for (i in 0 until n.childCount) percorrer(n.getChild(i), sb, prof + 1)
    }

    private fun capturarEOcr() {
        atualizarPainel("Lendo a imagem da tela…")
        botao?.visibility = View.INVISIBLE
        painel?.visibility = View.INVISIBLE
        main.postDelayed({
            takeScreenshot(
                Display.DEFAULT_DISPLAY,
                ContextCompat.getMainExecutor(this),
                object : AccessibilityService.TakeScreenshotCallback {
                    override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                        val buffer = r.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(buffer, r.colorSpace)
                            ?.copy(Bitmap.Config.ARGB_8888, false)
                        buffer.close()
                        mostrarTudo()
                        if (bmp == null) {
                            falha("Não consegui capturar a tela.")
                        } else {
                            ocr(bmp)
                        }
                    }

                    override fun onFailure(errorCode: Int) {
                        mostrarTudo()
                        falha("A captura de tela falhou (código $errorCode). Alguns apps bloqueiam captura.")
                    }
                }
            )
        }, 250)
    }

    private fun ocr(bmp: Bitmap) {
        val reconhecedor = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        reconhecedor.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val t = r.text.trim()
                if (t.isEmpty()) falha("Não encontrei texto na tela.") else processar(t)
            }
            .addOnFailureListener { falha("Erro ao ler a imagem.") }
    }

    private fun processar(texto: String) {
        atualizarPainel("Detectando o idioma…")
        LanguageIdentification.getClient().identifyLanguage(texto.take(500))
            .addOnSuccessListener { codigo ->
                if (codigo == "und") {
                    mostrarResultado(texto, "Não identifiquei o idioma. Texto lido:")
                } else if (codigo == "pt") {
                    mostrarResultado(texto, "Já está em português:")
                } else {
                    val origem = TranslateLanguage.fromLanguageTag(codigo)
                    if (origem == null) {
                        mostrarResultado(texto, "Idioma ($codigo) sem tradução offline. Texto lido:")
                    } else {
                        traduzir(texto, origem)
                    }
                }
            }
            .addOnFailureListener { falha("Erro ao detectar o idioma.") }
    }

    private fun traduzir(texto: String, origem: String) {
        atualizarPainel("Baixando o idioma (só na primeira vez)…")
        val tradutor = Translation.getClient(
            TranslatorOptions.Builder()
                .setSourceLanguage(origem)
                .setTargetLanguage(TranslateLanguage.PORTUGUESE)
                .build()
        )
        tradutor.downloadModelIfNeeded(DownloadConditions.Builder().build())
            .addOnSuccessListener {
                atualizarPainel("Traduzindo…")
                val saida = StringBuilder()
                traduzirPartes(tradutor, dividir(texto), 0, saida) {
                    tradutor.close()
                    mostrarResultado(saida.toString().trim(), "Tradução:")
                }
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Não consegui baixar o idioma. Verifique a internet.")
            }
    }

    private fun dividir(texto: String): List<String> {
        val partes = mutableListOf<String>()
        var atual = StringBuilder()
        for (linha in texto.lines()) {
            if (atual.isNotEmpty() && atual.length + linha.length > 900) {
                partes.add(atual.toString())
                atual = StringBuilder()
            }
            atual.append(linha).append('\n')
        }
        if (atual.isNotEmpty()) partes.add(atual.toString())
        return partes
    }

    private fun traduzirPartes(
        tradutor: Translator,
        partes: List<String>,
        i: Int,
        saida: StringBuilder,
        fim: () -> Unit
    ) {
        if (i >= partes.size) {
            fim()
            return
        }
        tradutor.translate(partes[i])
            .addOnSuccessListener {
                saida.append(it).append('\n')
                traduzirPartes(tradutor, partes, i + 1, saida, fim)
            }
            .addOnFailureListener {
                tradutor.close()
                falha("Erro ao traduzir.")
            }
    }

    // ---------- Painel de resultado ----------

    private fun abrirPainel(msg: String) {
        if (painel != null) {
            atualizarPainel(msg)
            painel?.visibility = View.VISIBLE
            return
        }
        val raiz = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(12))
            background = GradientDrawable().apply {
                cornerRadius = dp(16).toFloat()
                setColor(Color.parseColor("#16252D"))
                setStroke(dp(1), Color.parseColor("#28404B"))
            }
        }
        val texto = TextView(this).apply {
            text = msg
            textSize = 16f
            setTextColor(Color.parseColor("#E6EEF1"))
        }
        val rolagem = rolagemLimitada(0.45)
        rolagem.addView(texto)
        raiz.addView(
            rolagem,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        )

        val linha = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val copiar = botaoTexto("Copiar", "#1B6E8A") { copiarResultado() }
        val fechar = botaoTexto("Fechar", "#28404B") { fecharPainel() }
        val pesoLp = {
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                topMargin = dp(12); marginEnd = dp(8)
            }
        }
        linha.addView(copiar, pesoLp())
        linha.addView(fechar, pesoLp())
        raiz.addView(linha)

        val lp = WindowManager.LayoutParams(
            resources.displayMetrics.widthPixels - dp(24),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(24)
        }
        wm.addView(raiz, lp)
        painel = raiz
        painelTexto = texto
    }

    private fun rolagemLimitada(fracao: Double): ScrollView {
        val limite = (resources.displayMetrics.heightPixels * fracao).toInt()
        return object : ScrollView(this@TelaService) {
            override fun onMeasure(w: Int, h: Int) {
                super.onMeasure(w, View.MeasureSpec.makeMeasureSpec(limite, View.MeasureSpec.AT_MOST))
            }
        }
    }

    private fun botaoTexto(rotulo: String, cor: String, acao: () -> Unit): TextView {
        return TextView(this).apply {
            text = rotulo
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            maxLines = 2
            background = GradientDrawable().apply {
                cornerRadius = dp(10).toFloat()
                setColor(Color.parseColor(cor))
            }
            setOnClickListener { acao() }
        }
    }

    private fun atualizarPainel(msg: String) {
        painelTexto?.text = msg
    }

    private fun mostrarResultado(texto: String, titulo: String) {
        ultimoResultado = texto
        atualizarPainel("$titulo\n\n$texto")
        ocupado = false
    }

    private fun falha(msg: String) {
        atualizarPainel(msg)
        ocupado = false
    }

    private fun copiarResultado() {
        val cb = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cb.setPrimaryClip(ClipData.newPlainText("tela", ultimoResultado))
        aviso("Copiado")
    }

    private fun fecharPainel() {
        painel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        painel = null
        painelTexto = null
        ocupado = false
    }

    private fun mostrarTudo() {
        botao?.visibility = View.VISIBLE
        painel?.visibility = View.VISIBLE
    }

    private fun removerTudo() {
        fecharMenu()
        fecharPainel()
        botao?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        botao = null
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
