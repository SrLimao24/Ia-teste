package br.app.ajudantetela

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Persistência local da missão ativa (sobrevive a espera 429 / processo morto).
 */
object EstadoMissao {
    private const val PREFS = "lua_estado_missao"
    private const val CHAVE = "missao_ativa"

    fun salvar(
        ctx: Context,
        objetivo: String,
        appAlvo: String,
        contato: String,
        passo: Int,
        ultimaAcao: String,
        ultimoMotivo: String,
        contextoObservado: String,
        historico: List<String>,
        consultasIa: Int,
        motivoEspera: String = "",
        retrySegundos: Long = 0L
    ) {
        val o = JSONObject()
            .put("objetivo", objetivo)
            .put("appAlvo", appAlvo)
            .put("contato", contato)
            .put("passo", passo)
            .put("ultimaAcao", ultimaAcao)
            .put("ultimoMotivo", ultimoMotivo)
            .put("contextoObservado", contextoObservado.take(4000))
            .put("historico", JSONArray(historico.takeLast(30)))
            .put("consultasIa", consultasIa)
            .put("motivoEspera", motivoEspera)
            .put("retrySegundos", retrySegundos)
            .put("salvoEm", System.currentTimeMillis())
        prefs(ctx).edit().putString(CHAVE, o.toString()).apply()
    }

    fun limpar(ctx: Context) {
        prefs(ctx).edit().remove(CHAVE).apply()
    }

    fun carregar(ctx: Context): JSONObject? {
        val raw = prefs(ctx).getString(CHAVE, null) ?: return null
        return try {
            JSONObject(raw)
        } catch (_: Exception) {
            null
        }
    }

    fun temMissaoPendente(ctx: Context): Boolean = carregar(ctx) != null

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
