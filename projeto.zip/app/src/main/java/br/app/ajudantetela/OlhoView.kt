package br.app.ajudantetela

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Núcleo da Lua — símbolo cósmico/lunar (roxo, violeta, branco luminoso).
 * Modular: estados visuais sem lógica de negócio.
 */
class OlhoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Estado { NORMAL, ENSINANDO, EXECUTANDO, ABERTO }

    var estado: Estado = Estado.NORMAL
        set(value) {
            field = value
            atualizarCores()
            ajustarPulso()
            invalidate()
        }

    private val paintGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        maskFilter = BlurMaskFilter(22f, BlurMaskFilter.Blur.NORMAL)
    }
    private val paintAnel = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val paintFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val paintIris = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val paintStar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val paintCore = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    private var corPrimaria = Color.parseColor("#C77DFF")
    private var corSecundaria = Color.parseColor("#7B5CFF")
    private var corBrilho = Color.parseColor("#F0E6FF")
    private var corNucleo = Color.parseColor("#1A0A2E")
    private var pulso = 0f
    private var rotacao = 0f

    private var animPulso: ValueAnimator? = null
    private var animRot: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        iniciarAnimacoes()
    }

    private fun atualizarCores() {
        when (estado) {
            Estado.NORMAL -> {
                corPrimaria = Color.parseColor("#C77DFF")
                corSecundaria = Color.parseColor("#7B5CFF")
                corBrilho = Color.parseColor("#E8D5FF")
            }
            Estado.ENSINANDO -> {
                corPrimaria = Color.parseColor("#9B8CFF")
                corSecundaria = Color.parseColor("#5E9BFF")
                corBrilho = Color.parseColor("#D0E8FF")
            }
            Estado.EXECUTANDO -> {
                corPrimaria = Color.parseColor("#FF6B9D")
                corSecundaria = Color.parseColor("#C77DFF")
                corBrilho = Color.parseColor("#FFE0F0")
            }
            Estado.ABERTO -> {
                corPrimaria = Color.parseColor("#E0B0FF")
                corSecundaria = Color.parseColor("#A78BFA")
                corBrilho = Color.parseColor("#FFFFFF")
            }
        }
    }

    private fun ajustarPulso() {
        animPulso?.duration = when (estado) {
            Estado.EXECUTANDO -> 900
            Estado.ABERTO -> 1600
            Estado.ENSINANDO -> 1400
            else -> 2400
        }
    }

    private fun iniciarAnimacoes() {
        animPulso?.cancel()
        animPulso = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2400
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                pulso = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        animRot?.cancel()
        animRot = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 18000
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                rotacao = it.animatedValue as Float
                if (estado == Estado.EXECUTANDO || estado == Estado.ABERTO) invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val raio = min(width, height) / 2f * 0.78f

        // Halo externo
        val glowA = (50 + 40 * pulso).toInt().coerceIn(0, 255)
        paintGlow.color = Color.argb(glowA, Color.red(corPrimaria), Color.green(corPrimaria), Color.blue(corPrimaria))
        paintGlow.strokeWidth = 16f + 6f * pulso
        canvas.drawCircle(cx, cy, raio + 6f + 5f * pulso, paintGlow)

        // Disco de fundo
        paintFill.color = Color.argb(220, 12, 6, 28)
        canvas.drawCircle(cx, cy, raio, paintFill)

        // Anel externo luminoso
        paintAnel.color = corPrimaria
        paintAnel.strokeWidth = 3.5f + pulso
        canvas.drawCircle(cx, cy, raio - 2f, paintAnel)

        // Anel interno
        paintAnel.color = Color.argb(160, Color.red(corSecundaria), Color.green(corSecundaria), Color.blue(corSecundaria))
        paintAnel.strokeWidth = 1.8f
        canvas.drawCircle(cx, cy, raio * 0.72f, paintAnel)

        // Estrela/órbita (inspirada no símbolo)
        canvas.save()
        canvas.rotate(rotacao * 0.15f, cx, cy)
        desenharOrbitaEstelar(canvas, cx, cy, raio * 0.88f)
        canvas.restore()

        // Íris do olho
        paintIris.color = corPrimaria
        paintIris.strokeWidth = 2.5f
        canvas.drawCircle(cx, cy, raio * 0.42f, paintIris)
        paintIris.color = Color.argb(120, Color.red(corBrilho), Color.green(corBrilho), Color.blue(corBrilho))
        paintIris.strokeWidth = 1.2f
        canvas.drawCircle(cx, cy, raio * 0.28f, paintIris)

        // Núcleo (pupila espiralada simplificada)
        paintCore.color = corNucleo
        canvas.drawCircle(cx, cy, raio * 0.18f, paintCore)
        paintCore.color = Color.argb((90 + 50 * pulso).toInt(), Color.red(corBrilho), Color.green(corBrilho), Color.blue(corBrilho))
        canvas.drawCircle(cx - raio * 0.04f, cy - raio * 0.05f, raio * 0.06f, paintCore)

        // Pontos de energia
        paintCore.color = Color.argb(200, Color.red(corBrilho), Color.green(corBrilho), Color.blue(corBrilho))
        for (i in 0 until 6) {
            val ang = Math.toRadians((i * 60.0) + rotacao * 0.4)
            val px = cx + cos(ang).toFloat() * (raio * 0.95f)
            val py = cy + sin(ang).toFloat() * (raio * 0.95f)
            canvas.drawCircle(px, py, 1.8f + pulso, paintCore)
        }
    }

    private fun desenharOrbitaEstelar(canvas: Canvas, cx: Float, cy: Float, r: Float) {
        paintStar.color = Color.argb(180, Color.red(corPrimaria), Color.green(corPrimaria), Color.blue(corPrimaria))
        paintStar.strokeWidth = 1.6f
        val path = Path()
        val pontas = 8
        for (i in 0 until pontas * 2) {
            val ang = Math.toRadians(-90.0 + i * (180.0 / pontas))
            val rad = if (i % 2 == 0) r else r * 0.62f
            val x = cx + cos(ang).toFloat() * rad
            val y = cy + sin(ang).toFloat() * rad
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        canvas.drawPath(path, paintStar)
    }

    override fun onDetachedFromWindow() {
        animPulso?.cancel()
        animRot?.cancel()
        super.onDetachedFromWindow()
    }
}
