package br.app.ajudantetela

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * Núcleo da Lua — reprodução do símbolo: olho com espiral + estrela geométrica
 * em brilho violeta/branco sobre fundo escuro (referência visual do usuário).
 */
class OlhoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Estado { NORMAL, ENSINANDO, EXECUTANDO, ABERTO }

    var estado: Estado = Estado.NORMAL
        set(value) {
            field = value
            invalidate()
        }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pulso = 0f
    private var rotOrnamento = 0f

    private var animPulso: ValueAnimator? = null
    private var animRot: ValueAnimator? = null

    // Paleta da referência
    private val violeta = Color.parseColor("#B794F6")
    private val violetaClaro = Color.parseColor("#E9D5FF")
    private val branco = Color.parseColor("#F8F0FF")
    private val fundo = Color.parseColor("#05030A")

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        animPulso = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                pulso = it.animatedValue as Float
                invalidate()
            }
            start()
        }
        animRot = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 40000
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener {
                rotOrnamento = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun corEstado(): Int = when (estado) {
        Estado.EXECUTANDO -> Color.parseColor("#F0ABFC")
        Estado.ENSINANDO -> Color.parseColor("#A5B4FC")
        Estado.ABERTO -> Color.parseColor("#DDD6FE")
        else -> violeta
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val R = min(width, height) / 2f * 0.92f
        val accent = corEstado()

        // Glow externo (como o halo da foto)
        p.reset()
        p.isAntiAlias = true
        p.style = Paint.Style.STROKE
        p.strokeWidth = 14f + 8f * pulso
        p.color = Color.argb((55 + 35 * pulso).toInt(), Color.red(accent), Color.green(accent), Color.blue(accent))
        p.maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawCircle(cx, cy, R * 0.78f, p)
        p.maskFilter = null

        // Disco preto de fundo
        p.style = Paint.Style.FILL
        p.color = fundo
        canvas.drawCircle(cx, cy, R * 0.82f, p)

        // Anel circular externo fino
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.5f
        p.color = Color.argb(180, Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawCircle(cx, cy, R * 0.80f, p)

        // Ornamentos internos (anel com traços, girando bem lento)
        canvas.save()
        canvas.rotate(rotOrnamento * 0.25f, cx, cy)
        desenharOrnamentos(canvas, cx, cy, R * 0.74f, accent)
        canvas.restore()

        // ESTRELA de 8 pontas (forma principal da referência)
        canvas.save()
        // leve escala com pulso
        val scale = 1f + 0.02f * pulso
        canvas.scale(scale, scale, cx, cy)
        desenharEstrelaOlho(canvas, cx, cy, R * 0.72f, accent)
        canvas.restore()
    }

    /** Círculo com marcas e diamantes pequenos — anel místico. */
    private fun desenharOrnamentos(canvas: Canvas, cx: Float, cy: Float, r: Float, accent: Int) {
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        p.color = Color.argb(100, Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawCircle(cx, cy, r, p)

        p.strokeWidth = 1f
        for (i in 0 until 16) {
            val a = Math.toRadians(i * 22.5)
            val x1 = cx + cos(a).toFloat() * (r - 4f)
            val y1 = cy + sin(a).toFloat() * (r - 4f)
            val x2 = cx + cos(a).toFloat() * (r + 2f)
            val y2 = cy + sin(a).toFloat() * (r + 2f)
            p.color = Color.argb(if (i % 2 == 0) 160 else 70, Color.red(branco), Color.green(branco), Color.blue(branco))
            canvas.drawLine(x1, y1, x2, y2, p)
        }
    }

    /**
     * Estrela geométrica + olho central com espiral —
     * composição próxima da imagem de referência.
     */
    private fun desenharEstrelaOlho(canvas: Canvas, cx: Float, cy: Float, r: Float, accent: Int) {
        // Contorno da estrela (8 pontas, estilo “sol místico”)
        val pathEstrela = Path()
        val pontas = 8
        for (i in 0 until pontas * 2) {
            val ang = Math.toRadians(-90.0 + i * (180.0 / pontas))
            // pontas longas + reentrâncias
            val rad = if (i % 2 == 0) r else r * 0.48f
            val x = cx + cos(ang).toFloat() * rad
            val y = cy + sin(ang).toFloat() * rad
            if (i == 0) pathEstrela.moveTo(x, y) else pathEstrela.lineTo(x, y)
        }
        pathEstrela.close()

        // Preenchimento suave da estrela
        p.style = Paint.Style.FILL
        p.color = Color.argb(30, Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawPath(pathEstrela, p)

        // Traço luminoso da estrela
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.4f
        p.strokeJoin = Paint.Join.ROUND
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.argb(230, Color.red(branco), Color.green(branco), Color.blue(branco))
        canvas.drawPath(pathEstrela, p)

        // Segundo traço (violeta por baixo)
        p.strokeWidth = 4.5f
        p.color = Color.argb(70, Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawPath(pathEstrela, p)

        // Pontas extras / “chamas” curtas entre as pontas principais
        p.strokeWidth = 1.6f
        p.color = Color.argb(180, Color.red(branco), Color.green(branco), Color.blue(branco))
        for (i in 0 until pontas) {
            val ang = Math.toRadians(-90.0 + i * (360.0 / pontas) + 22.5)
            val x1 = cx + cos(ang).toFloat() * (r * 0.52f)
            val y1 = cy + sin(ang).toFloat() * (r * 0.52f)
            val x2 = cx + cos(ang).toFloat() * (r * 0.68f)
            val y2 = cy + sin(ang).toFloat() * (r * 0.68f)
            canvas.drawLine(x1, y1, x2, y2, p)
        }

        // —— OLHO no centro ——
        // Forma de olho (losango arredondado horizontal)
        val olhoW = r * 0.55f
        val olhoH = r * 0.28f
        val pathOlho = Path()
        pathOlho.moveTo(cx - olhoW, cy)
        pathOlho.quadTo(cx, cy - olhoH * 1.35f, cx + olhoW, cy)
        pathOlho.quadTo(cx, cy + olhoH * 1.35f, cx - olhoW, cy)
        pathOlho.close()

        p.style = Paint.Style.FILL
        p.color = Color.argb(40, Color.red(accent), Color.green(accent), Color.blue(accent))
        canvas.drawPath(pathOlho, p)

        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.2f
        p.color = branco
        canvas.drawPath(pathOlho, p)

        // Iris circular
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f
        p.color = violetaClaro
        canvas.drawCircle(cx, cy, r * 0.16f, p)

        // Espiral (pupila) — aproximação da referência
        p.strokeWidth = 2f
        p.color = branco
        val espiral = Path()
        val voltas = 2.2f
        val passos = 48
        for (i in 0..passos) {
            val t = i / passos.toFloat()
            val ang = t * voltas * 2.0 * Math.PI - Math.PI / 2
            val rad = (r * 0.02f) + t * (r * 0.14f)
            val x = cx + cos(ang).toFloat() * rad
            val y = cy + sin(ang).toFloat() * rad
            if (i == 0) espiral.moveTo(x, y) else espiral.lineTo(x, y)
        }
        canvas.drawPath(espiral, p)

        // Ponto central brilhante
        p.style = Paint.Style.FILL
        p.color = branco
        canvas.drawCircle(cx, cy, 2.2f + pulso, p)

        // Lágrima / gota sob o olho (detalhe da referência)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.8f
        p.color = branco
        val gota = Path()
        gota.moveTo(cx, cy + r * 0.18f)
        gota.quadTo(cx + r * 0.06f, cy + r * 0.30f, cx, cy + r * 0.38f)
        gota.quadTo(cx - r * 0.06f, cy + r * 0.30f, cx, cy + r * 0.18f)
        canvas.drawPath(gota, p)
        p.style = Paint.Style.FILL
        p.color = Color.argb(200, Color.red(branco), Color.green(branco), Color.blue(branco))
        canvas.drawCircle(cx, cy + r * 0.34f, 2f, p)

        // Diamantes pequenos acima do olho
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.4f
        p.color = branco
        desenharDiamante(canvas, cx, cy - r * 0.22f, r * 0.05f)
        desenharDiamante(canvas, cx - r * 0.12f, cy - r * 0.12f, r * 0.035f)
        desenharDiamante(canvas, cx + r * 0.12f, cy - r * 0.12f, r * 0.035f)
    }

    private fun desenharDiamante(canvas: Canvas, cx: Float, cy: Float, s: Float) {
        val path = Path()
        path.moveTo(cx, cy - s)
        path.lineTo(cx + s, cy)
        path.lineTo(cx, cy + s)
        path.lineTo(cx - s, cy)
        path.close()
        canvas.drawPath(path, p)
    }

    override fun onDetachedFromWindow() {
        animPulso?.cancel()
        animRot?.cancel()
        super.onDetachedFromWindow()
    }
}
