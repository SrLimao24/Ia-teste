package br.app.ajudantetela

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import kotlin.math.cos
import kotlin.math.sin

/**
 * O olho da Lua — botão flutuante místico/cyber.
 * Estados: NORMAL, ENSINANDO, EXECUTANDO, ABERTO
 */
class OlhoView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class Estado { NORMAL, ENSINANDO, EXECUTANDO, ABERTO }

    var estado: Estado = Estado.NORMAL
        set(value) {
            field = value
            atualizarCores()
            invalidate()
        }

    private val paintAnel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 6f
    }
    private val paintAnelExterno = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }
    private val paintPupila = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val paintBrilho = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }
    private val paintGlow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 14f
        maskFilter = BlurMaskFilter(18f, BlurMaskFilter.Blur.NORMAL)
    }

    private var corPrincipal = Color.parseColor("#FF6A1A")
    private var corSecundaria = Color.parseColor("#00E5FF")
    private var corCentro = Color.parseColor("#0A0A0F")
    private var pulso = 0f

    private var animator: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null) // para BlurMaskFilter
        iniciarPulso()
    }

    private fun atualizarCores() {
        when (estado) {
            Estado.NORMAL -> {
                corPrincipal = Color.parseColor("#FF6A1A")
                corSecundaria = Color.parseColor("#00E5FF")
            }
            Estado.ENSINANDO -> {
                corPrincipal = Color.parseColor("#00E5FF")
                corSecundaria = Color.parseColor("#7B5CFF")
            }
            Estado.EXECUTANDO -> {
                corPrincipal = Color.parseColor("#FF2A4A")
                corSecundaria = Color.parseColor("#FF8A00")
            }
            Estado.ABERTO -> {
                corPrincipal = Color.parseColor("#FF8A00")
                corSecundaria = Color.parseColor("#00E5FF")
            }
        }
    }

    private fun iniciarPulso() {
        animator?.cancel()
        animator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 2200
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener {
                pulso = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val raio = (minOf(width, height) / 2f) * 0.78f

        // Glow externo
        paintGlow.color = Color.argb((40 + 30 * pulso).toInt(), Color.red(corPrincipal), Color.green(corPrincipal), Color.blue(corPrincipal))
        canvas.drawCircle(cx, cy, raio + 8f + 4f * pulso, paintGlow)

        // Anel externo fino (cyan)
        paintAnelExterno.color = Color.argb(180, Color.red(corSecundaria), Color.green(corSecundaria), Color.blue(corSecundaria))
        canvas.drawCircle(cx, cy, raio + 3f, paintAnelExterno)

        // Anel principal (laranja/vermelho)
        paintAnel.color = corPrincipal
        paintAnel.strokeWidth = 5.5f + 1.5f * pulso
        canvas.drawCircle(cx, cy, raio - 2f, paintAnel)

        // Anel interno mais fino
        paintAnel.color = Color.argb(120, Color.red(corPrincipal), Color.green(corPrincipal), Color.blue(corPrincipal))
        paintAnel.strokeWidth = 2f
        canvas.drawCircle(cx, cy, raio * 0.72f, paintAnel)

        // Pupila / centro escuro
        paintPupila.color = corCentro
        canvas.drawCircle(cx, cy, raio * 0.48f, paintPupila)

        // Brilho interno (pequeno reflexo)
        paintBrilho.color = Color.argb((50 + 40 * pulso).toInt(), 255, 180, 80)
        canvas.drawCircle(cx - raio * 0.12f, cy - raio * 0.15f, raio * 0.12f, paintBrilho)

        // Pontos de energia (pequenos) ao redor
        paintBrilho.color = Color.argb(160, Color.red(corSecundaria), Color.green(corSecundaria), Color.blue(corSecundaria))
        for (i in 0 until 4) {
            val ang = Math.toRadians((i * 90.0) + pulso * 15)
            val px = cx + cos(ang).toFloat() * (raio * 0.92f)
            val py = cy + sin(ang).toFloat() * (raio * 0.92f)
            canvas.drawCircle(px, py, 2.2f, paintBrilho)
        }
    }

    override fun onDetachedFromWindow() {
        animator?.cancel()
        super.onDetachedFromWindow()
    }
}
