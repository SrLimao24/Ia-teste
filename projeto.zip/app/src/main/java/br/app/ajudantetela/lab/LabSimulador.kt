package br.app.ajudantetela.lab

/**
 * Simulador controlado do Lab (sem tocar no app real).
 * Estados simbolicos para treinar/avaliar fluxos como WhatsApp mensagem.
 */
object LabSimulador {

    enum class EstadoSim {
        TELA_INICIAL,
        PESQUISA,
        RESULTADOS,
        PERFIL,
        CONVERSA,
        MENSAGEM_DIGITADA,
        MENSAGEM_ENVIADA,
        FALHA_SEM_PROGRESSO,
        CONTATO_INEXISTENTE
    }

    data class Cenario(
        val id: String,
        val nome: String,
        val estados: List<EstadoSim>,
        val objetivo: String
    )

    data class PassoSim(
        val acao: String,
        val alvo: String,
        val de: EstadoSim,
        val para: EstadoSim?,
        val progresso: Boolean,
        val detalhe: String
    )

    fun cenarioWhatsAppMensagem(): Cenario = Cenario(
        id = "sim_wa_msg",
        nome = "WhatsApp — enviar mensagem",
        objetivo = "Chegar a MENSAGEM_ENVIADA a partir de TELA_INICIAL",
        estados = EstadoSim.values().toList()
    )

    /**
     * Transicoes deterministicas do simulador (experimentos baratos).
     */
    fun aplicarAcao(estado: EstadoSim, acao: String, alvo: String): PassoSim {
        val a = acao.lowercase()
        val t = alvo.lowercase()
        return when (estado) {
            EstadoSim.TELA_INICIAL -> {
                if (a.contains("abrir") || t.contains("whatsapp"))
                    passo(a, alvo, estado, EstadoSim.PESQUISA, true, "app aberto / busca")
                else
                    passo(a, alvo, estado, null, false, "acao nao leva a pesquisa")
            }
            EstadoSim.PESQUISA -> {
                if (a.contains("digitar") || a.contains("type"))
                    passo(a, alvo, estado, EstadoSim.RESULTADOS, true, "termo pesquisado")
                else
                    passo(a, alvo, estado, null, false, "esperado digitar termo")
            }
            EstadoSim.RESULTADOS -> {
                when {
                    t.contains("viewgroup") || t.contains("relative") || t.contains("linear") ->
                        passo(a, alvo, estado, EstadoSim.FALHA_SEM_PROGRESSO, false, "layout generico sem clique util")
                    a.contains("clicar") && t.isNotBlank() ->
                        passo(a, alvo, estado, EstadoSim.PERFIL, true, "item da lista / perfil")
                    else ->
                        passo(a, alvo, estado, null, false, "clique sem alvo util")
                }
            }
            EstadoSim.PERFIL -> {
                if (a.contains("clicar") && (t.contains("mensagem") || t.contains("convers") || t.contains("chat")))
                    passo(a, alvo, estado, EstadoSim.CONVERSA, true, "abriu conversa")
                else if (a.contains("clicar"))
                    passo(a, alvo, estado, EstadoSim.CONVERSA, true, "acao no perfil → conversa (sim)")
                else
                    passo(a, alvo, estado, null, false, "precisa acao para conversar")
            }
            EstadoSim.CONVERSA -> {
                if (a.contains("digitar"))
                    passo(a, alvo, estado, EstadoSim.MENSAGEM_DIGITADA, true, "texto no campo")
                else
                    passo(a, alvo, estado, null, false, "esperado digitar mensagem")
            }
            EstadoSim.MENSAGEM_DIGITADA -> {
                if (a.contains("clicar") && (t.contains("enviar") || t.contains("send")))
                    passo(a, alvo, estado, EstadoSim.MENSAGEM_ENVIADA, true, "envio confirmado no simulador")
                else
                    passo(a, alvo, estado, null, false, "esperado clicar Enviar")
            }
            EstadoSim.MENSAGEM_ENVIADA ->
                passo(a, alvo, estado, estado, true, "objetivo ja cumprido no sim")
            EstadoSim.FALHA_SEM_PROGRESSO ->
                passo(a, alvo, estado, EstadoSim.RESULTADOS, false, "recuperar: voltar aos resultados")
            EstadoSim.CONTATO_INEXISTENTE ->
                passo(a, alvo, estado, null, false, "contato inexistente")
        }
    }

    private fun passo(
        acao: String, alvo: String, de: EstadoSim, para: EstadoSim?, prog: Boolean, det: String
    ) = PassoSim(acao, alvo, de, para, prog, det)

    fun avaliarTrajetoria(passos: List<PassoSim>): String {
        val chegou = passos.any { it.para == EstadoSim.MENSAGEM_ENVIADA }
        val falhas = passos.count { !it.progresso }
        return buildString {
            appendLine("Simulacao: ${passos.size} passos, falhas=$falhas")
            appendLine(if (chegou) "RESULTADO: objetivo simulado ALCANCADO" else "RESULTADO: objetivo NAO alcancado")
            passos.forEachIndexed { i, p ->
                appendLine("${i + 1}. ${p.acao}/${p.alvo}: ${p.de} -> ${p.para} prog=${p.progresso} (${p.detalhe})")
            }
        }
    }
}
