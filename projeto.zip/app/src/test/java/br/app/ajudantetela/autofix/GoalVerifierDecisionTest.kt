package br.app.ajudantetela.autofix

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test

class GoalVerifierDecisionTest {

    @Test
    fun countIncreaseIsSuccess() {
        val before = VerificationEvidence(
            source = "test",
            messageCountBefore = 1,
            inputTextBefore = "TESTE",
            sendButtonPresentBefore = true
        )
        val after = VerificationEvidence(
            source = "test",
            messageCountAfter = 2,
            inputTextAfter = "",
            sendButtonPresentAfter = false,
            actionExecuted = true,
            appInForeground = true
        )
        assertEquals(
            VerificationResult.SUCCESS,
            GoalVerifier.verifyMessageSend(before, listOf(after)).result
        )
    }

    @Test
    fun unchangedTreeIsUnknownNotFailure() {
        val before = VerificationEvidence(
            source = "test",
            messageCountBefore = 1,
            inputTextBefore = "TESTE",
            sendButtonPresentBefore = true
        )
        val after = VerificationEvidence(
            source = "test",
            messageCountAfter = 1,
            inputTextAfter = "TESTE",
            sendButtonPresentAfter = true,
            actionExecuted = true,
            appInForeground = true
        )
        assertEquals(
            VerificationResult.UNKNOWN,
            GoalVerifier.verifyMessageSend(before, listOf(after)).result
        )
    }

    @Test
    fun failedActionIsActionFailed() {
        val before = VerificationEvidence(source = "test")
        val after = VerificationEvidence(
            source = "test",
            actionExecuted = false,
            appInForeground = true
        )
        assertEquals(
            VerificationResult.ACTION_FAILED,
            GoalVerifier.verifyMessageSend(before, listOf(after)).result
        )
    }

    @Test
    fun unknownBlocksDuplicableAction() {
        val decision = VerificationPolicy.afterVerification(
            ActionClass.DUPLICABLE,
            VerificationResult.UNKNOWN
        )
        assertFalse(decision.allowAction)
    }

    @Test
    fun emptyInputAfterIsSuccess() {
        val before = VerificationEvidence(
            source = "test",
            messageCountBefore = 3,
            inputTextBefore = "TESTE, LUA ESTEVE AQUI",
            sendButtonPresentBefore = true
        )
        val after = VerificationEvidence(
            source = "test",
            messageCountAfter = 3,
            inputTextAfter = "",
            sendButtonPresentAfter = true,
            actionExecuted = true,
            appInForeground = true
        )
        assertEquals(
            VerificationResult.SUCCESS,
            GoalVerifier.verifyMessageSend(before, listOf(after)).result
        )
    }

    @Test
    fun guardBlocksSecondAttempt() {
        val g = AttemptGuard()
        val k = AttemptKey("enviar_mensagem", "Bela", "TESTE")
        assertEquals(true, g.mayExecuteDuplicateAction(k))
        g.markAttempted(k)
        assertEquals(false, g.mayExecuteDuplicateAction(k))
        g.block(k)
        assertEquals(false, g.mayExecuteDuplicateAction(k))
    }
}
