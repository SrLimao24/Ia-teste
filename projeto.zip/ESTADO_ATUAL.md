# Lua — Estado atual do projeto (v0.9.6)

Repositório: `SrLimao24/Ia-teste`  
App Android com AccessibilityService (overlay flutuante).

## O que a Lua consegue fazer

- Overlay flutuante (núcleo/olho) sobre qualquer app
- Menu orbital com comandos: Traduzir, Textos, Ensinar, Habilidades, IA, Voltar, Início, Recentes, Notificações, Subir, Descer, Print
- Campo de comando em linguagem natural + confirmação antes de executar
- **Abrir apps** por nome (resolve pacote real via apps LAUNCHER no aparelho)
- **Digitar texto** em campos editáveis (`isEditable`) via `ACTION_SET_TEXT`
- **Ensinar Lua**: gravar sequência de gestos/toques e salvar habilidade
- **Executar habilidade** gravada (replay de passos, sem IA)
- Tradução de tela (ML Kit)
- Configuração multi-provedor de IA (Gemini / Grok / OpenAI), chave só local

## Comunicação com Gemini

- `ConfigIA` guarda provedor + API key em SharedPreferences (nunca no APK/Git)
- `FabricaIA` → `GeminiProvedor` (ou Grok/OpenAI)
- Fluxo: comando → `pedirAcao` → prompt pede **JSON** → parse em `InterpreteAcao` → `executarAcaoIA`
- Gemini: lista modelos (`ListModels`), escolhe *flash* free-tier, evita deep-research
- Ações JSON atuais: `abrir_app`, `digitar`, `dizer`, `erro`
- **Ainda não** há loop multi-passo (observar → agir → reobservar até concluir tarefa complexa)

## Digitação

- `InterpreteAcao.listarCamposEditaveis(root)` percorre árvore de acessibilidade
- Escolhe campo: focado → único → match por hint/alvo → primeiro habilitado
- `escreverNoCampo`: FOCUS + CLICK + `ACTION_SET_TEXT`
- Contexto dos campos é enviado à IA no prompt
- Limitação: WebViews e alguns apps não expõem EditText nativo

## AccessibilityService

- Classe principal: `TelaService` (`TYPE_ACCESSIBILITY_OVERLAY`)
- Config em `accessibility_service_config.xml` (eventos de clique/texto)
- Observa eventos para modo Ensino
- `rootInActiveWindow` para ler árvore e executar ações

## Observar a tela

- **Sim**, via árvore de acessibilidade (nós, texto, descrição, classe, bounds, editável, clicável)
- Usado em: tradução, ensino, listagem de campos, contexto para IA
- **Não** há OCR/visão por imagem no ciclo de comando da IA (OCR existe no fluxo de traduzir)

## Clicar / tocar

- **Sim**, no executor de **habilidades** gravadas (replay de taps por match de nó)
- **Não** há ainda ação estruturada genérica `clicar` no ciclo comando→IA→JSON (só `abrir_app` e `digitar`)
- Global actions: voltar, home, recentes, notificações, scroll

## Arquivos principais

| Arquivo | Papel |
|---------|--------|
| `TelaService.kt` | Overlay, menu, ensino, executor, ciclo IA |
| `AcaoIA.kt` | Parse JSON, campos editáveis, resolver apps |
| `GeminiProvedor.kt` / `Grok` / `OpenAI` | Provedores HTTP |
| `ConfigIA.kt` / `FabricaIA.kt` / `ModeloIA.kt` | Config e contrato |
| `Habilidades.kt` | Persistência de macros |
| `OlhoView.kt` | Núcleo visual |
| `MainActivity.kt` | Ativar serviço de acessibilidade |
| `AndroidManifest.xml` | Serviço + `<queries>` launcher |

## Próximo ponto recomendado

Implementar ação **`clicar`** no ciclo IA (encontrar nó por texto/descrição/classe na árvore e `ACTION_CLICK`), depois **loop multi-passo** (observar → uma ação → reobservar) para tarefas como “abra o WhatsApp e mande oi para X”.

Não implementar ainda olhos/mãos 3D — prioridade: controle real da UI.
