# Ajudante de Tela (etapa 2 / 0.3)

App Android com um botão flutuante (✦). Ao tocar, lê o texto da tela atual e traduz para português.

- Lê o texto direto da estrutura da tela; se achar pouco, tira um print e usa OCR.
- Detecta o idioma por trecho e traduz apenas os trechos que não estão em português, inclusive em telas com vários idiomas.
- A internet só é usada para baixar o idioma na primeira vez.
- Precisa do Android 11 ou mais novo.

Próximas etapas: executor de ações em JSON, automação de tarefas e memória de habilidades.
